/**
 * Active-file ALang symbol index shared by Monaco language providers.
 * Static candidates never execute code or imply definite runtime availability.
 * Contract: docs/CONTRACT-EDITOR-SYMBOL-COMPLETION-20261118.md
 */
const _alangSymbolCache = new WeakMap();
const _alangKeywords = new Set([
    'let',
    'fn',
    'if',
    'then',
    'elseif',
    'else',
    'end',
    'while',
    'do',
    'for',
    'return',
    'break',
    'continue',
    'and',
    'or',
    'not',
    'true',
    'false',
    'nil',
]);

/** Tokenize incomplete buffers, keeping text inside strings/comments opaque. */
function _alangTokens(text) {
    const tokens = [];
    const hidden = [];
    const identifierPattern = /[a-zA-Z_]\w*/y;
    let offset = 0;
    while (offset < text.length) {
        const start = offset;
        const ch = text[offset];
        if (/\s/.test(ch)) {
            offset++;
            continue;
        }
        if (text.startsWith('--[[', offset)) {
            const close = text.indexOf(']]', offset + 4);
            offset = close < 0 ? text.length : close + 2;
            hidden.push({ start, end: offset, open: close < 0 });
            continue;
        }
        if (ch === '#' || text.startsWith('--', offset)) {
            const close = text.indexOf('\n', offset);
            offset = close < 0 ? text.length : close;
            hidden.push({ start, end: offset, open: true });
            continue;
        }
        if (ch === '"' || ch === "'") {
            offset++;
            let closed = false;
            while (offset < text.length) {
                const current = text[offset++];
                if (current === '\\') {
                    offset = Math.min(offset + 1, text.length);
                } else if (current === ch) {
                    closed = true;
                    break;
                }
            }
            hidden.push({ start, end: offset, open: !closed });
            tokens.push({ value: '', kind: 'literal', start, end: offset });
            continue;
        }
        identifierPattern.lastIndex = offset;
        const identifier = identifierPattern.exec(text);
        if (identifier) {
            offset += identifier[0].length;
            tokens.push({ value: identifier[0], kind: 'name', start, end: offset });
            continue;
        }
        const pair = text.slice(offset, offset + 2);
        const value = ['==', '!=', '<=', '>=', '..'].includes(pair) ? pair : ch;
        offset += value.length;
        tokens.push({ value, kind: 'punctuation', start, end: offset });
    }
    return { tokens, hidden };
}

/** Read adjacent ALang line comments without treating quoted text as docs. */
function _alangFunctionDoc(text, start) {
    const lineStart = text.lastIndexOf('\n', start - 1) + 1;
    const lines = text.slice(0, lineStart).trimEnd().split('\n');
    const docs = [];
    for (let i = lines.length - 1; i >= 0; i--) {
        const match = /^\s*(?:--(?!\[\[)|#)\s?(.*)$/.exec(lines[i]);
        if (!match) {
            break;
        }
        docs.unshift(match[1]);
    }
    return docs.join('\n') || 'User-defined function (static declaration)';
}

/**
 * Index declarations in function scopes; if/loop blocks do not create scopes
 * in ScriptRuntime.m. Partial definitions extend to EOF until their end exists.
 */
function _alangBuildSymbols(text) {
    const { tokens, hidden } = _alangTokens(text);
    const root = { start: 0, end: text.length + 1, parent: null };
    const scopes = [root];
    const functions = [];
    const variables = [];
    const blocks = [];
    let scope = root;
    let depth = 0;
    const isName = (token) => token?.kind === 'name' && !_alangKeywords.has(token.value);
    const addVariable = (token, kind) => {
        if (isName(token) && token.value !== '_') {
            variables.push({ name: token.value, start: token.start, scope, kind });
        }
    };

    for (let i = 0; i < tokens.length; i++) {
        const token = tokens[i];
        const value = token.value;
        if ('([{'.includes(value) && value) {
            depth++;
            continue;
        }
        if (')]}'.includes(value) && value) {
            depth = Math.max(0, depth - 1);
            continue;
        }
        if (depth !== 0 || token.kind !== 'name') {
            continue;
        }
        if (value === 'fn' && isName(tokens[i + 1]) && tokens[i + 2]?.value === '(') {
            const name = tokens[i + 1];
            const params = [];
            let cursor = i + 3;
            while (isName(tokens[cursor])) {
                params.push(tokens[cursor]);
                cursor++;
                if (tokens[cursor]?.value !== ',') {
                    break;
                }
                cursor++;
            }
            const parent = scope;
            scope = { start: token.start, end: text.length + 1, parent };
            scopes.push(scope);
            blocks.push({ kind: 'fn', scope });
            functions.push({
                name: name.value,
                start: name.start,
                params: params.map((param) => param.value),
                doc: _alangFunctionDoc(text, token.start),
                scope,
            });
            params.forEach((param) => addVariable(param, 'parameter'));
            i = tokens[cursor]?.value === ')' ? cursor : cursor - 1;
            continue;
        }
        if (value === 'end') {
            const block = blocks.pop();
            if (block?.kind === 'fn') {
                block.scope.end = token.end;
                scope = block.scope.parent;
            }
            continue;
        }
        if (['if', 'while', 'for'].includes(value)) {
            blocks.push({ kind: value });
            if (value === 'for' && tokens[i + 2]?.value === '=') {
                addVariable(tokens[i + 1], 'loop variable');
                i++;
            }
            continue;
        }
        if (value === 'let') {
            const declarations = [];
            let cursor = i + 1;
            while (isName(tokens[cursor])) {
                declarations.push(tokens[cursor]);
                cursor++;
                if (tokens[cursor]?.value !== ',') {
                    break;
                }
                cursor++;
            }
            if (tokens[cursor]?.value === '=') {
                declarations.forEach((declaration) => addVariable(declaration, 'variable'));
                i = cursor;
            }
            continue;
        }
        if (tokens[i + 1]?.value === '=' && !['.', ':'].includes(tokens[i - 1]?.value)) {
            addVariable(token, 'variable');
        }
    }
    return { text, tokens, hidden, scopes, functions, variables, root };
}

/** Keep cached indexes isolated by Monaco model, including unsaved edits. */
function _alangSymbols(model) {
    const version = model.getVersionId();
    let cached = _alangSymbolCache.get(model);
    if (!cached || cached.version !== version) {
        cached = { version, index: _alangBuildSymbols(model.getValue()) };
        _alangSymbolCache.set(model, cached);
    }
    return cached.index;
}

/** No declarations from another function or tab become local candidates. */
function _alangVisibleSymbols(model, position) {
    const index = _alangSymbols(model);
    const offset = model.getOffsetAt(position);
    const scope = index.scopes.findLast((item) => item.start <= offset && offset < item.end);
    const chain = [];
    for (let current = scope; current; current = current.parent) {
        chain.unshift(current);
    }
    const visible = new Map();
    index.functions.forEach((fn) => visible.set(fn.name, { ...fn, kind: 'function' }));
    chain.forEach((owner) => {
        index.variables.forEach((variable) => {
            if (
                variable.scope === owner &&
                (variable.start < offset || (owner === index.root && scope !== index.root))
            ) {
                visible.set(variable.name, variable);
            }
        });
    });
    return Array.from(visible.values());
}

/** Suppress language assistance inside literal/comment contents. */
function _alangInText(model, position) {
    const offset = model.getOffsetAt(position);
    return _alangSymbols(model).hidden.some(
        (item) => item.start < offset && (offset < item.end || (item.open && offset === item.end)),
    );
}

/** Resolve a custom function from this buffer; runtime call dispatch is global. */
function _alangFunction(model, name) {
    return _alangSymbols(model).functions.findLast((fn) => fn.name === name);
}

/** Find multiline calls while ignoring commas in nested arrays/dicts/strings. */
function _alangActiveCall(model, position) {
    const offset = model.getOffsetAt(position);
    const tokens = _alangSymbols(model).tokens;
    const stack = [];
    for (let i = 0; i < tokens.length && tokens[i].start < offset; i++) {
        const value = tokens[i].value;
        if (value && '([{'.includes(value)) {
            let name = null;
            if (value === '(' && tokens[i - 1]?.kind === 'name') {
                name = tokens[i - 1].value;
                if (tokens[i - 2]?.value === 'fn') {
                    name = null;
                } else if (tokens[i - 2]?.value === '.') {
                    name = tokens[i - 3]?.value + '.' + name;
                } else if (tokens[i - 2]?.value === ':') {
                    name = null;
                }
            }
            stack.push({ name, index: 0 });
        } else if (value && ')]}'.includes(value)) {
            stack.pop();
        } else if (value === ',' && stack.length) {
            stack[stack.length - 1].index++;
        }
    }
    return stack.findLast((frame) => frame.name) || null;
}
