/**
 * @file editor.language.js — Monaco editor themes (`iosauto-dark`, `iosauto-light`),
 * ALang Monarch syntax tokenizer, code snippet templates, and IntelliSense
 * completion, hover, and signature-help providers.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Code Snippet Templates
// -----------------------------------------------------------------------------

/** Built-in ALang automation snippet templates offered in completion results. */
const _MONACO_SNIPPET_TEMPLATES = [
    {
        label: '⚡ while true loop',
        insert: 'while true do\n    sleep(${1:1})\nend',
        detail: 'Vòng lặp vô hạn',
        doc: 'Lặp mãi với sleep.',
    },
    {
        label: '⚡ for loop',
        insert: 'for ${1:i} = 1, ${2:10} do\n    print(${1:i})\n    sleep(${3:0.5})\nend',
        detail: 'Lặp từ 1 → N',
        doc: 'Numeric for loop.',
    },
    {
        label: '⚡ find and tap',
        insert: 'let rect = image_match("${1:btn.png}")\nif rect then\n    tap(rect["x"], rect["y"])\n    print("Tapped!")\nelse\n    print("Not found")\nend',
        detail: 'Find → tap',
        doc: 'Find image and tap.',
    },
    {
        label: '⚡ wait and tap',
        insert: 'let rect = wait_for_image("${1:btn.png}", 0.9, ${2:30})\nif rect then\n    tap(rect["x"], rect["y"])\n    print("OK")\nelse\n    print("Timeout")\nend',
        detail: 'Wait → tap',
        doc: 'Wait for image then tap.',
    },
    {
        label: '⚡ color check',
        insert: 'while true do\n    let c = pick_color(${1:100}, ${2:200})\n    if c and c["red"] == ${3:255} then\n        tap(${1:100}, ${2:200})\n        break\n    end\n    sleep(0.5)\nend',
        detail: 'Color check',
        doc: 'Wait for color match.',
    },
    {
        label: '⚡ app launch',
        insert: 'switch_to_app("${1:com.apple.mobilesafari}")\nsleep(2)\nprint("App:", get_front_app())',
        detail: 'Launch app',
        doc: 'Launch and verify.',
    },
    {
        label: '⚡ if / else',
        insert: 'if ${1:cond} then\n    ${2:}\nelse\n    ${3:}\nend',
        detail: 'If/else',
        doc: 'Conditional.',
    },
    {
        label: '⚡ function',
        insert: 'fn ${1:my_func}(${2:})\n    ${3:}\nend',
        detail: 'Function',
        doc: 'Function definition.',
    },
    {
        label: '⚡ HTTP + JSON',
        insert: 'let resp = http_get("${1:https://api.example.com}")\nprint(resp)',
        detail: 'HTTP + JSON',
        doc: 'GET and parse JSON.',
    },
    {
        label: '⚡ scroll down',
        insert: 'for i = 1, ${1:3} do\n    swipe(207, 600, 207, 300, 0.3)\n    sleep(0.5)\nend',
        detail: 'Scroll down',
        doc: 'Swipe up to scroll.',
    },
    {
        label: '⚡ multi-step',
        insert: 'switch_to_app("${1:com.apple.mobilesafari}")\nsleep(2)\n\ntap(${2:207}, ${3:400})\nsleep(1)\n\ninsert_text("${4:hello}", ${5:0.1})\n\nprint("Done!")',
        detail: 'Multi-step',
        doc: 'Multi-step automation template.',
    },
];

// -----------------------------------------------------------------------------
// Monaco Editor Themes
// -----------------------------------------------------------------------------

/**
 * Register the custom `iosauto-dark` (neutral slate + `#818CF8` indigo accent) and
 * `iosauto-light` color themes with the Monaco editor instance.
 */
function _defineMonacoTheme(monaco) {
    monaco.editor.defineTheme('iosauto-dark', {
        base: 'vs-dark',
        inherit: true,
        rules: [
            { token: 'comment', foreground: '64748B', fontStyle: 'italic' },
            { token: 'keyword', foreground: '818CF8' },
            { token: 'string', foreground: '6EE7B7' },
            { token: 'number', foreground: 'FCD34D' },
            { token: 'type', foreground: '67E8F9' },
            { token: 'identifier', foreground: 'E2E8F0' },
            { token: 'delimiter', foreground: '94A3B8' },
        ],
        colors: {
            'editor.background': '#161B22',
            'editor.foreground': '#F1F5F9',
            'editor.lineHighlightBackground': '#1F2631',
            'editor.selectionBackground': '#818CF838',
            'editorLineNumber.foreground': '#606F85',
            'editorLineNumber.activeForeground': '#818CF8',
            'editor.inactiveSelectionBackground': '#818CF81F',
            'editorCursor.foreground': '#818CF8',
            'editorIndentGuide.background': '#28313F',
            'editorIndentGuide.activeBackground': '#818CF855',
            'editorWidget.background': '#1E242E',
            'editorWidget.border': '#333D4D',
            'editorSuggestWidget.background': '#1E242E',
            'editorSuggestWidget.border': '#333D4D',
            'editorSuggestWidget.selectedBackground': '#818CF82E',
            'minimap.background': '#161B22',
            'scrollbar.shadow': '#00000000',
            'scrollbarSlider.background': '#818CF824',
            'scrollbarSlider.hoverBackground': '#818CF842',
            'scrollbarSlider.activeBackground': '#818CF866',
        },
    });

    monaco.editor.defineTheme('iosauto-light', {
        base: 'vs',
        inherit: true,
        rules: [
            { token: 'comment', foreground: '94A3B8', fontStyle: 'italic' },
            { token: 'keyword', foreground: '6366F1' },
            { token: 'string', foreground: '059669' },
            { token: 'number', foreground: 'D97706' },
            { token: 'type', foreground: '0284C7' },
            { token: 'identifier', foreground: '0F172A' },
            { token: 'delimiter', foreground: '475569' },
        ],
        colors: {
            'editor.background': '#F8FAFC',
            'editor.foreground': '#0F172A',
            'editor.lineHighlightBackground': '#F1F5F9',
            'editor.selectionBackground': '#818CF833',
            'editorLineNumber.foreground': '#94A3B8',
            'editorLineNumber.activeForeground': '#6366F1',
            'editor.inactiveSelectionBackground': '#818CF81A',
            'editorCursor.foreground': '#6366F1',
            'editorIndentGuide.background': '#E2E8F0',
            'editorIndentGuide.activeBackground': '#818CF866',
            'editorWidget.background': '#FFFFFF',
            'editorWidget.border': '#CBD5E1',
            'editorSuggestWidget.background': '#FFFFFF',
            'editorSuggestWidget.border': '#CBD5E1',
            'editorSuggestWidget.selectedBackground': '#818CF824',
            'minimap.background': '#F8FAFC',
            'scrollbar.shadow': '#00000000',
            'scrollbarSlider.background': '#818CF82E',
            'scrollbarSlider.hoverBackground': '#818CF84D',
            'scrollbarSlider.activeBackground': '#818CF873',
        },
    });
}

// -----------------------------------------------------------------------------
// ALang Monarch Tokenizer & Language Configuration
// -----------------------------------------------------------------------------

/**
 * Register the `alang` language identifier (`.a` script files), Monarch lexical
 * tokenizer rules, comment markers (`--` / `--[[ ]]`), and bracket pairs.
 */
function _registerALangLanguage(monaco) {
    if (monaco.languages.getLanguages().find((l) => l.id === 'alang')) {
        return;
    }

    monaco.languages.register({ id: 'alang', extensions: ['.a'], aliases: ['a', 'alang'] });

    monaco.languages.setMonarchTokensProvider('alang', {
        keywords: [
            'let',
            'fn',
            'end',
            'if',
            'then',
            'else',
            'elseif',
            'for',
            'in',
            'do',
            'while',
            'repeat',
            'until',
            'return',
            'break',
            'continue',
            'true',
            'false',
            'nil',
            'and',
            'or',
            'not',
        ],
        operators: [
            '+',
            '-',
            '*',
            '/',
            '%',
            '^',
            '==',
            '!=',
            '<',
            '>',
            '<=',
            '>=',
            '=',
            '+=',
            '-=',
            '*=',
            '/=',
            '..',
        ],
        tokenizer: {
            root: [
                [/--\[\[/, 'comment', '@blockcomment'],
                [/--.*$/, 'comment'],
                [/[a-zA-Z_]\w*/, { cases: { '@keywords': 'keyword', '@default': 'identifier' } }],
                [/\d+\.\d+([eE][+\-]?\d+)?/, 'number.float'],
                [/0[xX][0-9a-fA-F]+/, 'number.hex'],
                [/\d+/, 'number'],
                [/"([^"\\]|\\.)*"/, 'string'],
                [/'([^'\\]|\\.)*'/, 'string'],
                [/\.\./, 'operator'],
                [/[=!<>+\-*/%^]+/, 'operator'],
                [/[{}()\[\]]/, '@brackets'],
                [/[,.:;]/, 'delimiter'],
                [/\s+/, 'white'],
            ],
            blockcomment: [
                [/]]/, 'comment', '@pop'],
                [/./, 'comment'],
            ],
        },
    });

    monaco.languages.setLanguageConfiguration('alang', {
        comments: { lineComment: '--', blockComment: ['--[[', ']]'] },
        brackets: [
            ['{', '}'],
            ['[', ']'],
            ['(', ')'],
        ],
        autoClosingPairs: [
            { open: '{', close: '}' },
            { open: '[', close: ']' },
            { open: '(', close: ')' },
            { open: '"', close: '"' },
            { open: "'", close: "'" },
        ],
    });
}

// -----------------------------------------------------------------------------
// ALang IntelliSense Providers (Completion, Hover, Signature Help)
// -----------------------------------------------------------------------------

/**
 * Register the ALang completion item provider offering SDK functions, namespace
 * members (`string.*`, `math.*`), snippet templates, hardware key constants,
 * and user-defined functions/variables discovered in the active buffer.
 */
function registerAlangCompletionItems(monaco) {
    monaco.languages.registerCompletionItemProvider('alang', {
        triggerCharacters: ['.', '(', '"', "'"],
        provideCompletionItems: function (model, position) {
            const word = model.getWordUntilPosition(position);
            const range = {
                startLineNumber: position.lineNumber,
                endLineNumber: position.lineNumber,
                startColumn: word.startColumn,
                endColumn: word.endColumn,
            };

            const suggestions = [];

            const linePrefix = model.getValueInRange({
                startLineNumber: position.lineNumber,
                startColumn: 1,
                endLineNumber: position.lineNumber,
                endColumn: position.column,
            });
            const libHit = linePrefix.match(/\b(string|math)\.(\w*)$/);
            const LIB_MEMBERS = {
                string: [
                    'upper',
                    'lower',
                    'trim',
                    'split',
                    'join',
                    'replace',
                    'contains',
                    'starts_with',
                    'ends_with',
                    'len',
                ],
                math: ['abs', 'floor', 'ceil', 'round', 'sqrt', 'pow', 'min', 'max', 'random'],
            };

            const sdk = window._sdkMethods || [];
            const sdkSeen = new Set();
            sdk.forEach((fn, i) => {
                if (sdkSeen.has(fn.name)) {
                    return;
                }
                sdkSeen.add(fn.name);

                let insertName = fn.name;
                if (libHit) {
                    const members = LIB_MEMBERS[libHit[1]] || [];
                    const bare = fn.name.replace(/^(string|math)\./, '');
                    if (members.indexOf(bare) < 0) {
                        return;
                    }
                    if (fn.name.indexOf('.') >= 0 && fn.name !== libHit[1] + '.' + bare) {
                        return;
                    }
                    insertName = bare;
                }

                const sig = (fn.sig || '()').replace(/^\(|\)$/g, '');
                const args = sig
                    .split(',')
                    .map((a) => a.trim())
                    .filter((a) => a && a !== 'self');
                const positional = args.filter((a) => !a.includes('='));
                const snippetArgs = positional.map((a, idx) => {
                    const display = a.includes(':') ? a.split(':')[0].trim() : a;
                    return '${' + (idx + 1) + ':' + display + '}';
                });
                const callSnippet = `${insertName}(${snippetArgs.join(', ')})`;
                const rawDocOne = (fn.doc || '').split('\n')[0].slice(0, 80);
                const docOne = _sdkDoc(fn.name, rawDocOne);

                suggestions.push({
                    label: { label: insertName, detail: '(' + sig + ')', description: docOne },
                    filterText: insertName,
                    kind: monaco.languages.CompletionItemKind.Function,
                    insertText: callSnippet,
                    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                    detail: docOne,
                    documentation: {
                        value: '```a\n' + fn.name + '(' + sig + ')\n```\n\n' + docOne,
                    },
                    sortText: '0' + String(i).padStart(3, '0'),
                    range,
                });
            });

            _MONACO_SNIPPET_TEMPLATES.forEach((tpl, i) => {
                const filterText = tpl.label.replace(/^⚡\s*/, '');
                suggestions.push({
                    label: tpl.label,
                    kind: monaco.languages.CompletionItemKind.Snippet,
                    insertText: tpl.insert,
                    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                    detail: tpl.detail,
                    documentation: { value: tpl.doc },
                    filterText: filterText,
                    sortText: '1' + String(i).padStart(3, '0'),
                    range,
                });
            });

            ['KEY_HOME', 'KEY_POWER', 'KEY_VOLUME_UP', 'KEY_VOLUME_DOWN'].forEach((k) => {
                suggestions.push({
                    label: k,
                    kind: monaco.languages.CompletionItemKind.Constant,
                    insertText: k,
                    detail: 'Key constant',
                    sortText: '2' + k,
                    range,
                });
            });

            const fullText = model.getValue();
            const funcRegex = /def\s+([a-zA-Z_]\w*)\s*\(([^)]*)\)/g;
            let match;
            const seen = new Set();
            while ((match = funcRegex.exec(fullText)) !== null) {
                const fname = match[1];
                const params = match[2].trim();
                if (seen.has(fname)) {
                    continue;
                }
                seen.add(fname);
                const beforeFunc = fullText.substring(0, match.index);
                const lines = beforeFunc.split('\n');
                const docLines = [];
                for (let i = lines.length - 1; i >= 0; i--) {
                    const trimmed = lines[i].trim();
                    if (trimmed.startsWith('#')) {
                        docLines.unshift(trimmed.replace(/^#\s?/, ''));
                    } else if (trimmed === '') {
                        if (docLines.length > 0) {
                            break;
                        }
                    } else {
                        break;
                    }
                }
                const doc = docLines.length > 0 ? docLines.join('\n') : 'User-defined function';
                const paramList = params
                    ? params
                          .split(',')
                          .map((p, idx) => `\${${idx + 1}:${p.trim()}}`)
                          .join(', ')
                    : '';
                suggestions.push({
                    label: fname,
                    kind: monaco.languages.CompletionItemKind.Function,
                    insertText: fname + '(' + paramList + ')',
                    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                    detail: `${fname}(${params}) — script`,
                    documentation: {
                        value: '```a\ndef ' + fname + '(' + params + ')\n```\n\n' + doc,
                    },
                    sortText: '00' + fname,
                    range,
                });
            }

            const varRegex = /(?:^|[\n;])\s*([a-zA-Z_]\w*)\s*=/g;
            while ((match = varRegex.exec(fullText)) !== null) {
                const vname = match[1];
                if (
                    seen.has(vname) ||
                    [
                        'if',
                        'else',
                        'elif',
                        'for',
                        'while',
                        'return',
                        'def',
                        'class',
                        'True',
                        'False',
                        'None',
                        'and',
                        'or',
                        'not',
                        'import',
                        'from',
                        'as',
                        'with',
                        'try',
                        'except',
                        'finally',
                        'pass',
                        'break',
                        'continue',
                        'lambda',
                        'yield',
                        'global',
                        'nonlocal',
                    ].includes(vname)
                ) {
                    continue;
                }
                seen.add(vname);
                suggestions.push({
                    label: vname,
                    kind: monaco.languages.CompletionItemKind.Variable,
                    insertText: vname,
                    detail: 'variable',
                    sortText: '01' + vname,
                    range,
                });
            }

            return { suggestions };
        },
    });
}

/**
 * Register the ALang hover documentation provider displaying the method
 * signature and localized description when hovering over an SDK identifier.
 */
function registerAlangHover(monaco) {
    monaco.languages.registerHoverProvider('alang', {
        provideHover: function (model, position) {
            const word = model.getWordAtPosition(position);
            if (!word) {
                return null;
            }
            const sdk = window._sdkMethods || [];
            const fn = sdk.find((f) => f.name === word.word);
            if (!fn) {
                return null;
            }
            const sig = (fn.sig || '()').replace(/^\(|\)$/g, '');
            const hoverDoc = _sdkDoc(fn.name, fn.doc || '');
            return {
                range: new monaco.Range(
                    position.lineNumber,
                    word.startColumn,
                    position.lineNumber,
                    word.endColumn,
                ),
                contents: [
                    { value: '```a\nd.' + fn.name + '(' + sig + ')\n```' },
                    { value: hoverDoc },
                ],
            };
        },
    });
}

/**
 * Register the ALang signature-help provider highlighting the active parameter
 * inside function call parentheses `(` and `,`.
 */
function registerAlangSignatureHelp(monaco) {
    monaco.languages.registerSignatureHelpProvider('alang', {
        signatureHelpTriggerCharacters: ['(', ','],
        provideSignatureHelp: function (model, position) {
            const lineContent = model.getLineContent(position.lineNumber);
            const textBefore = lineContent.substring(0, position.column - 1);

            let depth = 0;
            let parenPos = -1;
            for (let i = textBefore.length - 1; i >= 0; i--) {
                if (textBefore[i] === ')') {
                    depth++;
                } else if (textBefore[i] === '(') {
                    if (depth === 0) {
                        parenPos = i;
                        break;
                    }
                    depth--;
                }
            }
            if (parenPos < 0) {
                return null;
            }

            const beforeParen = textBefore.substring(0, parenPos).trimEnd();
            const funcMatch = beforeParen.match(/(\w+)$/);
            if (!funcMatch) {
                return null;
            }

            const sdk = window._sdkMethods || [];
            const fn = sdk.find((f) => f.name === funcMatch[1]);
            if (!fn) {
                return null;
            }
            const sig = (fn.sig || '()').replace(/^\(|\)$/g, '');
            const params = sig
                .split(',')
                .map((a) => a.trim())
                .filter((a) => a && a !== 'self');

            const insideParen = textBefore.substring(parenPos + 1);
            let commaCount = 0;
            let d = 0;
            for (const ch of insideParen) {
                if (ch === '(') {
                    d++;
                } else if (ch === ')') {
                    d--;
                } else if (ch === ',' && d === 0) {
                    commaCount++;
                }
            }

            const sigDoc = _sdkDoc(fn.name, fn.doc || '');
            return {
                value: {
                    signatures: [
                        {
                            label: fn.name + '(' + sig + ')',
                            documentation: sigDoc,
                            parameters: params.map((p) => ({ label: p, documentation: p })),
                        },
                    ],
                    activeSignature: 0,
                    activeParameter: Math.min(commaCount, fn.params.length - 1),
                },
                dispose: () => {},
            };
        },
    });
}

/**
 * Register ALang completion, hover, and signature-help providers in deterministic order.
 */
function _registerALangCompletion(monaco) {
    registerAlangCompletionItems(monaco);
    registerAlangHover(monaco);
    registerAlangSignatureHelp(monaco);
}
