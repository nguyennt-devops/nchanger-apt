/**
 * @file image.gallery.js — Image and video gallery tab rendering, Blob video
 * preview hydration, and media upload/import controls (Script folder, Phone
 * Photos, and VCam).
 *
 * Communicates with `GET /api/images`, `POST /api/images`, and
 * `DELETE /api/images/:name`.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Image & Video Gallery Rendering
// -----------------------------------------------------------------------------

/**
 * Fetch the media list from `/api/images`, render image/video cards in
 * `#imagesList`, and hydrate `<video>` previews via Blob URLs so video
 * thumbnails render even when the on-device HTTP server omits `206 Partial Content`.
 */
async function loadImagesTab() {
    const list = document.getElementById('imagesList');
    const count = document.getElementById('imagesCount');
    if (!list) {
        return;
    }
    try {
        const r = await fetch(`${API}/api/images`);
        const d = await r.json();
        const imgs = d.images || [];
        if (count) {
            count.textContent = imgs.length + ' ' + _t('imgCountLabel');
        }
        if (!imgs.length) {
            list.innerHTML = `<div style="grid-column:1/-1; text-align:center; color:var(--text-secondary); padding:30px;">${_t('imgEmpty')}</div>`;
            return;
        }

        if (Array.isArray(window._imageVideoBlobUrls)) {
            window._imageVideoBlobUrls.forEach((u) => {
                try {
                    URL.revokeObjectURL(u);
                } catch (e) {
                    // Ignore already-revoked object URLs.
                }
            });
        }
        window._imageVideoBlobUrls = [];

        list.innerHTML = imgs
            .map((img) => {
                const sz = (img.size / 1024).toFixed(1) + ' KB';
                const nameJS = escJS(img.name);
                const nameHTML = escapeHtml(img.name);
                const isVideo = /\.(mp4|mov|m4v|webm)$/i.test(img.name || '');
                const mediaUrl = `${API}/api/images/${encodeURIComponent(img.name)}?t=${Date.now()}`;
                const previewHTML = isVideo
                    ? `<div style="position:relative; width:100%; height:90px; background:var(--bg-tertiary); border-radius:4px; overflow:hidden; display:flex; align-items:center; justify-content:center;">
          <video data-video-src="${mediaUrl}" data-video-name="${nameHTML}" muted loop playsinline preload="metadata" style="width:100%; height:100%; object-fit:contain; display:block;" onmouseenter="this.play().catch(()=>{})" onmouseleave="this.pause();try{this.currentTime=0.05;}catch(e){}"></video>
          <span style="position:absolute; right:4px; bottom:4px; padding:1px 5px; border-radius:4px; background:rgba(22,27,34,0.82); border:1px solid rgba(129,140,248,0.32); color:var(--accent-hover); font-size:9px; font-weight:700; pointer-events:none;">▶ VIDEO</span>
        </div>`
                    : `<img src="${mediaUrl}" style="width:100%; height:90px; object-fit:contain; background:var(--bg-tertiary); border-radius:4px; display:block;" loading="lazy" />`;
                return `<div style="background:var(--bg-secondary); border:1px solid var(--border-color); border-radius:8px; padding:8px; display:flex; flex-direction:column; gap:6px; height:100%; box-sizing:border-box;">
        ${previewHTML}
        <div style="font-size:11px; color:var(--text-primary); word-break:break-all; line-height:1.2;">${nameHTML}</div>
        <div style="font-size:10px; color:var(--text-secondary);">${sz}</div>
        <div class="hm-row-btns">
          <button type="button" class="hm-btn-copy" onclick="copyImageName('${nameJS}')">${_t('hmBtnCopy')}</button>
          <button type="button" class="btn-danger btn-sm image-delete-button" aria-label="${escapeHtml(_t('imgDeleteLabel'))}" title="${escapeHtml(_t('imgDeleteLabel'))}" onclick="deleteImage('${nameJS}')"><i data-lucide="trash-2" aria-hidden="true"></i></button>
        </div>
      </div>`;
            })
            .join('');

        list.querySelectorAll('video[data-video-src]').forEach(async (vid) => {
            const url = vid.getAttribute('data-video-src');
            const vname = (vid.getAttribute('data-video-name') || '').toLowerCase();
            const mime = vname.endsWith('.mov') ? 'video/quicktime' : 'video/mp4';
            try {
                const resp = await fetch(url);
                if (!resp.ok) {
                    return;
                }
                const buf = await resp.arrayBuffer();
                const blobUrl = URL.createObjectURL(new Blob([buf], { type: mime }));
                window._imageVideoBlobUrls.push(blobUrl);
                vid.onloadeddata = () => {
                    try {
                        vid.currentTime = 0.05;
                    } catch (e) {
                        // Ignore seek errors on unsupported codecs.
                    }
                };
                vid.src = blobUrl;
            } catch (e) {
                // Leave video element empty if preview fetch fails.
            }
        });

        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    } catch (e) {
        list.innerHTML = `<div style="grid-column:1/-1; color:#f44;">${_t('imgLoadErr')}${e.message}</div>`;
    }
}

// -----------------------------------------------------------------------------
// Media Item Actions & Upload Handlers
// -----------------------------------------------------------------------------

/**
 * Copy the media file stem (without image/video extension) to the clipboard
 * for use in ALang image-matching calls.
 */
function copyImageName(name) {
    _hmDoCopy(name.replace(/\.(png|jpg|jpeg|mp4|mov|m4v|heic|webp)$/i, ''));
}

/**
 * Prompt for confirmation and delete `name` from the device's `images/`
 * directory via `DELETE /api/images/:name`.
 */
async function deleteImage(name) {
    if (!confirm(_t('imgDeleteConfirm') + name + '?')) {
        return;
    }
    try {
        const r = await fetch(`${API}/api/images/${encodeURIComponent(name)}`, {
            method: 'DELETE',
        });
        const d = await r.json().catch(() => ({}));
        if (!r.ok || !d.ok) {
            appendLog(_t('imgDeleteFail') + (d.error || 'HTTP ' + r.status), 'error');
            return;
        }
        loadImagesTab();
    } catch (e) {
        appendLog(_t('imgDeleteFail') + e.message, 'error');
    }
}

/**
 * Upload one or more media `files` to the selected destination (`'script'`,
 * `'album'`, or `'vcam'`) via `POST /api/images`.
 */
async function uploadImagesFiles(files, dest) {
    const toAlbum = dest === 'album';
    const toVcam = dest === 'vcam';
    let ok = 0;
    const total = files.length;
    const q = toVcam ? '&dest=vcam' : toAlbum ? '&dest=album' : '';

    for (const f of files) {
        try {
            const buf = await f.arrayBuffer();
            const r = await fetch(`${API}/api/images?name=${encodeURIComponent(f.name)}${q}`, {
                method: 'POST',
                body: buf,
            });
            const d = await r.json();
            if (d.ok) {
                ok++;
                let msg;
                if (toVcam) {
                    msg = _t('vcamImportOk') + (d.name || f.name);
                } else if (toAlbum) {
                    msg = _t('albumImportOk') + (d.name || f.name) + ` (${ok}/${total})`;
                } else {
                    msg = _t('imgUploadOk') + d.name;
                }
                appendLog(msg);
            } else {
                let failPrefix = _t('imgUploadFail');
                if (toVcam) {
                    failPrefix = _t('vcamImportFail');
                } else if (toAlbum) {
                    failPrefix = _t('albumImportFail');
                }
                appendLog(failPrefix + (d.raw || d.error || ''), 'error');
            }
        } catch (e) {
            let failPrefix = _t('imgUploadFail');
            if (toVcam) {
                failPrefix = _t('vcamImportFail');
            } else if (toAlbum) {
                failPrefix = _t('albumImportFail');
            }
            appendLog(failPrefix + e.message, 'error');
        }
    }

    if (toAlbum) {
        if (total > 1) {
            appendLog(_t('albumImportDone') + `${ok}/${total}`);
        }
    } else if (!toVcam) {
        loadImagesTab();
    }
}

/**
 * Bind the Images tab upload buttons (`#uploadImageBtn`, `#importAlbumBtn`,
 * `#importVcamBtn`) and shared hidden file input (`#imageUploadInput`).
 */
function initImageUploadControls() {
    const input = document.getElementById('imageUploadInput');
    if (!input) {
        return;
    }
    let dest = 'script';
    document.getElementById('uploadImageBtn')?.addEventListener('click', () => {
        dest = 'script';
        input.accept = 'image/*';
        input.multiple = true;
        input.click();
    });
    document.getElementById('importAlbumBtn')?.addEventListener('click', () => {
        dest = 'album';
        input.accept = 'image/*,video/mp4,video/quicktime,.mp4,.mov';
        input.multiple = true;
        input.click();
    });
    document.getElementById('importVcamBtn')?.addEventListener('click', () => {
        dest = 'vcam';
        input.accept =
            'image/png,image/jpeg,image/heic,video/mp4,video/quicktime,.mp4,.mov,.png,.jpg,.jpeg,.heic';
        input.multiple = false;
        input.click();
    });
    input.addEventListener('change', (e) => {
        const files = e.target.files?.length ? Array.from(e.target.files) : [];
        e.target.value = '';
        if (files.length) {
            uploadImagesFiles(files, dest);
        }
    });
}

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.copyImageName = copyImageName;
window.deleteImage = deleteImage;
window.loadImagesTab = loadImagesTab;
