/**
 * @file editor.workspace.js — Monaco editor instance creation, keybindings,
 * multi-tab workspace lifecycle, unsaved-changes guard, and code insertion.
 *
 * Owns `state.editor`, `state.openTabs`, `state.activeTabId`, and the
 * `#editorTabBar` tab strip.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Monaco Editor Instance & Toolbar Action Bindings
// -----------------------------------------------------------------------------

/**
 * Instantiate the Monaco code editor inside `#codeEditor` with ALang syntax
 * highlighting and the active IDE theme.
 */
function _createMonacoEditor(monaco, defaultCode) {
    state.editor = monaco.editor.create(document.getElementById('codeEditor'), {
        value: defaultCode,
        language: 'alang',
        theme: ideTheme === 'dark' ? 'iosauto-dark' : 'iosauto-light',
        fontSize: 13,
        fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Consolas', monospace",
        fontLigatures: true,
        lineNumbers: 'on',
        minimap: { enabled: true, scale: 1, size: 'proportional' },
        scrollBeyondLastLine: false,
        automaticLayout: true,
        tabSize: 4,
        insertSpaces: true,
        wordWrap: 'off',
        renderWhitespace: 'selection',
        bracketPairColorization: { enabled: true },
        guides: { bracketPairs: true, indentation: true },
        suggestOnTriggerCharacters: true,
        quickSuggestions: { other: 'on', comments: false, strings: false },
        quickSuggestionsDelay: 10,
        wordBasedSuggestions: 'off',
        suggest: {
            filterGraceful: true,
            snippetsPreventQuickSuggestions: false,
            localityBonus: true,
            shareSuggestSelections: true,
        },
        acceptSuggestionOnCommitCharacter: true,
        autoClosingBrackets: 'always',
        autoClosingQuotes: 'always',
        autoIndent: 'full',
        formatOnPaste: true,
        formatOnType: true,
        smoothScrolling: true,
        cursorBlinking: 'smooth',
        cursorSmoothCaretAnimation: 'on',
        padding: { top: 12, bottom: 12 },
        roundedSelection: true,
        renderLineHighlight: 'all',
        occurrencesHighlight: 'singleFile',
        folding: true,
        foldingHighlight: true,
        showFoldingControls: 'mouseover',
        matchBrackets: 'always',
        contextmenu: true,
        mouseWheelZoom: true,
    });
}

/**
 * Bind Monaco editor keybindings (`Ctrl/Cmd+Enter` to run/stop, `Ctrl/Cmd+S`
 * to save), auto-suggest triggers, dirty-state tracking, and toolbar buttons.
 */
function _bindMonacoActions(monaco) {
    state.editor.addAction({
        id: 'run-script',
        label: 'Run Script',
        keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter],
        run: () => {
            if (state.runningTaskId) {
                stopScript();
            } else {
                runScript();
            }
        },
    });

    let suggestTimer = null;
    state.editor.onDidChangeModelContent((e) => {
        if (suggestTimer) {
            clearTimeout(suggestTimer);
        }
        if (e.changes.some((c) => c.text.length > 0 && /[a-zA-Z_]/.test(c.text))) {
            suggestTimer = setTimeout(() => {
                state.editor.trigger('auto', 'editor.action.triggerSuggest', {});
            }, 50);
        }
    });

    state.editor.addAction({
        id: 'save-script',
        label: 'Save Script',
        keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS],
        run: () => {
            if (state.currentFileName) {
                saveScriptAs(state.currentFileName);
                return;
            }
            document.getElementById('saveModal').classList.add('visible');
            const inp = document.getElementById('scriptNameInput');
            if (!inp.value) {
                inp.value = generateScriptName();
            }
            setTimeout(() => {
                inp.focus();
                inp.select();
            }, 100);
        },
    });

    document.getElementById('runBtn')?.addEventListener('click', runScript);
    document.getElementById('stopBtn')?.addEventListener('click', stopScript);
    document.getElementById('newScriptBtn')?.addEventListener('click', () => {
        const defaultCode =
            document.getElementById('defaultCode')?.textContent?.trim() || '-- New script\n';
        const autoName = generateScriptName() + '.a';
        if (!openTab(autoName, defaultCode)) {
            return;
        }
        state._dirty = true;
        const newTab = state.openTabs.find((t) => t.id === state.activeTabId);
        if (newTab) {
            newTab.dirty = true;
        }
        renderEditorTabs();
        document.getElementById('scriptNameInput').value = autoName;
        document.querySelector('.tab[data-tab="editor"]')?.click();
        appendLog(_l('📝 New script created', '📝 Đã tạo script mới'));
    });

    document.getElementById('newFolderBtn')?.addEventListener('click', () => {
        if (typeof createFolder === 'function') {
            createFolder();
        }
    });

    document.getElementById('saveBtn')?.addEventListener('click', () => {
        document.getElementById('saveModal').classList.add('visible');
        const inp = document.getElementById('scriptNameInput');
        if (!inp.value) {
            inp.value = generateScriptName();
        }
        setTimeout(() => {
            inp.focus();
            inp.select();
        }, 100);
    });

    state._dirty = false;
    state._initDone = true;
    state.editor.onDidChangeModelContent(() => {
        if (state._initDone) {
            state._dirty = true;
        }
    });
}

/**
 * Load the Monaco AMD bundle from `/static/monaco/vs` and initialize the
 * ALang language, themes, editor instance, and action bindings.
 */
function initMonacoEditor() {
    require.config({
        paths: { vs: '/static/monaco/vs' },
    });

    require(['vs/editor/editor.main'], function () {
        _defineMonacoTheme(monaco);
        const defaultCode =
            document.getElementById('defaultCode')?.textContent?.trim() ||
            '-- Write your script here\n';
        _registerALangCompletion(monaco);
        _registerALangLanguage(monaco);
        _createMonacoEditor(monaco, defaultCode);
        _bindMonacoActions(monaco);
    });
}

/** Return the full text content of the active Monaco editor model. */
function getEditorValue() {
    if (state.editor) {
        return state.editor.getValue();
    }
    return '';
}

/** Replace the active Monaco editor model content and clear the dirty flag. */
function setEditorValue(code) {
    if (state.editor) {
        state.editor.setValue(code);
        state._dirty = false;
    }
}

/**
 * Insert `text` at the current cursor position in the active Monaco editor,
 * falling back to clipboard copy when the editor is not yet mounted.
 */
function insertEditorText(text) {
    const s = text == null ? '' : String(text);
    if (!s) {
        return;
    }
    if (!state.editor) {
        _hmDoCopy(s);
        return;
    }
    const pos = state.editor.getPosition();
    state.editor.executeEdits('', [
        {
            range: {
                startLineNumber: pos.lineNumber,
                startColumn: pos.column,
                endLineNumber: pos.lineNumber,
                endColumn: pos.column,
            },
            text: s,
        },
    ]);
    appendLog(_t('insertLog') + s.split('\n')[0], 'success');
}

// -----------------------------------------------------------------------------
// Unsaved-Changes Guard
// -----------------------------------------------------------------------------

/** Generate a unique tab identifier for an open editor tab. */
function generateTabId() {
    return 'tab_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
}

/** Return `true` if `tab` currently holds unsaved modifications. */
function _tabHasUnsavedChanges(tab) {
    return !!tab && (tab.id === state.activeTabId ? !!state._dirty : !!tab.dirty);
}

/**
 * Prompt the user before discarding unsaved edits on `tab` during a reload or
 * close operation. Returns `true` if the operation may proceed.
 */
function _confirmDiscardTab(tab, action) {
    if (!_tabHasUnsavedChanges(tab)) {
        return true;
    }
    return window.confirm(
        _l(
            `Unsaved changes in "${tab.name}". ${action} and discard them?`,
            `Có thay đổi chưa lưu trong "${tab.name}". ${action} và bỏ thay đổi?`,
        ),
    );
}

/** Return `true` if the active editor or any background tab has unsaved edits. */
function _hasUnsavedChanges() {
    return !!state._dirty || state.openTabs.some((tab) => _tabHasUnsavedChanges(tab));
}

window.addEventListener('beforeunload', (event) => {
    if (!_hasUnsavedChanges()) {
        return;
    }
    event.preventDefault();
    event.returnValue = '';
});

// -----------------------------------------------------------------------------
// Multi-Tab Workspace Lifecycle
// -----------------------------------------------------------------------------

/**
 * Open a script file in a new editor tab, or reload and focus its existing tab
 * if already open. Encrypted `.aios` files are opened in read-only mode.
 */
function openTab(name, code, encrypted = false) {
    const readOnly = !!encrypted || /\.aios$/i.test(name || '');
    const existing = state.openTabs.find((t) => t.name === name);
    if (existing) {
        // Reload fresh content from disk/API rather than retaining stale buffer text.
        if (typeof code === 'string' && existing.model) {
            if (!_confirmDiscardTab(existing, _l('Reload', 'Tải lại'))) {
                return false;
            }
            existing.model.setValue(code);
            existing.code = code;
            existing.dirty = false;
            if (existing.id === state.activeTabId) {
                state._dirty = false;
            }
        }
        existing.readOnly = readOnly;
        switchTab(existing.id);
        state.editor?.updateOptions?.({ readOnly });
        return true;
    }

    saveCurrentTabState();
    const model = monaco.editor.createModel(code, 'alang');
    const tab = {
        id: generateTabId(),
        name,
        code,
        dirty: false,
        viewState: null,
        model,
        readOnly,
    };
    state.openTabs.push(tab);
    state.activeTabId = tab.id;
    state.currentFileName = name;
    if (state.editor) {
        state.editor.setModel(model);
        state.editor.updateOptions({ readOnly });
    }
    state._dirty = false;
    renderEditorTabs();
    return true;
}

/**
 * Switch the active editor view to `tabId`, saving the previous tab's cursor
 * and scroll state first.
 */
function switchTab(tabId) {
    if (state.activeTabId === tabId) {
        return;
    }
    saveCurrentTabState();
    const tab = state.openTabs.find((t) => t.id === tabId);
    if (!tab) {
        return;
    }
    state.activeTabId = tabId;
    state.currentFileName = tab.name;
    if (state.editor) {
        state.editor.setModel(tab.model);
        state.editor.updateOptions({ readOnly: !!tab.readOnly });
        if (tab.viewState) {
            state.editor.restoreViewState(tab.viewState);
        }
        state.editor.focus();
    }
    state._dirty = tab.dirty;
    document.getElementById('scriptNameInput').value = tab.name || '';
    renderEditorTabs();
}

/**
 * Close the editor tab identified by `tabId` after confirming any unsaved
 * changes, dispose its Monaco model, and activate the nearest remaining tab.
 */
function closeTab(tabId, evt) {
    if (evt) {
        evt.stopPropagation();
    }
    const idx = state.openTabs.findIndex((t) => t.id === tabId);
    if (idx === -1) {
        return false;
    }
    if (!_confirmDiscardTab(state.openTabs[idx], _l('Close', 'Đóng'))) {
        return false;
    }
    if (state.activeTabId === tabId) {
        saveCurrentTabState();
    }
    const closedTab = state.openTabs[idx];
    if (closedTab.model) {
        closedTab.model.dispose();
    }
    state.openTabs.splice(idx, 1);

    if (state.activeTabId === tabId) {
        if (state.openTabs.length > 0) {
            const newIdx = Math.min(idx, state.openTabs.length - 1);
            const newTab = state.openTabs[newIdx];
            state.activeTabId = newTab.id;
            state.currentFileName = newTab.name;
            if (state.editor) {
                state.editor.setModel(newTab.model);
                state.editor.updateOptions({ readOnly: !!newTab.readOnly });
                if (newTab.viewState) {
                    state.editor.restoreViewState(newTab.viewState);
                }
                state.editor.focus();
            }
            state._dirty = newTab.dirty;
            document.getElementById('scriptNameInput').value = newTab.name || '';
        } else {
            state.activeTabId = null;
            state.currentFileName = null;
            if (state.editor) {
                state.editor.setModel(monaco.editor.createModel('', 'alang'));
                state.editor.updateOptions({ readOnly: false });
            }
            state._dirty = false;
            document.getElementById('scriptNameInput').value = '';
        }
    }
    renderEditorTabs();
    return true;
}

/** Snapshot the active tab's text, dirty flag, and Monaco view state. */
function saveCurrentTabState() {
    if (!state.activeTabId) {
        return;
    }
    const tab = state.openTabs.find((t) => t.id === state.activeTabId);
    if (tab && state.editor) {
        tab.code = state.editor.getValue();
        tab.dirty = state._dirty;
        tab.viewState = state.editor.saveViewState();
    }
}

/** Render the `#editorTabBar` tab strip for all open script tabs. */
function renderEditorTabs() {
    const bar = document.getElementById('editorTabBar');
    if (!bar) {
        return;
    }
    if (state.openTabs.length === 0) {
        bar.innerHTML =
            '<div style="padding:5px 12px; font-size:11px; color:var(--text-secondary); opacity:0.5;">No files open</div>';
        return;
    }
    bar.innerHTML = state.openTabs
        .map((t) => {
            const isActive = t.id === state.activeTabId;
            const isRunning = state.runningFileName === t.name;
            const icon = isRunning ? 'flame' : 'file-code';
            const iconColor = isRunning ? 'color:#f97316;' : 'opacity:0.4;';
            const idJS = escJS(t.id);
            return `<div class="editor-tab ${isActive ? 'active' : ''}" onclick="switchTab('${idJS}')">
      <i data-lucide="${icon}" style="width:12px;height:12px;flex-shrink:0;${iconColor}"></i>
      <span class="tab-name">${escapeHtml(t.name)}</span>
      <span class="tab-dot ${t.dirty ? 'dirty' : ''}"></span>
      <span class="tab-close" onclick="closeTab('${idJS}', event)">×</span>
    </div>`;
        })
        .join('');
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.switchTab = switchTab;
window.closeTab = closeTab;
