/**
 * @file device.control.js — Device discovery, screen metrics synchronization,
 * hardware button/swipe dispatch, device info modal, and setup diagnostics.
 *
 * Communicates with `/api/ping`, `/screen_info`, `/key`, `/swipe`, and
 * `/api/setup/*` to manage the connected iOS target.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Device Connection & Screen Metrics
// -----------------------------------------------------------------------------

/**
 * Poll `/api/ping` to verify device connectivity, synchronize server language
 * and theme preferences, and connect to the local device when available.
 */
async function refreshDevices() {
    try {
        const res = await fetch(`${API}/api/ping`);
        const data = await res.json();
        _applyServerLang(data);
        _applyServerTheme(data);
        if (data.status === 'ok') {
            if (data.token) {
                state.apiToken = data.token;
            }
            state.devices = [{ udid: 'local', name: 'iPhone', ip: data.ip }];
            if (!state.currentDevice) {
                connectDevice('local');
            }
        } else {
            appendLog(_l('Could not connect to iPhone', 'Không kết nối được iPhone'), 'error');
        }
    } catch (e) {
        appendLog(_l('Could not connect to iPhone', 'Không kết nối được iPhone'), 'error');
    }
}

/**
 * Select `udid` as the active target device and query `/screen_info` to cache
 * physical pixel dimensions, point dimensions, and Retina scale factor.
 */
async function connectDevice(udid) {
    try {
        state.currentDevice = udid || 'local';

        try {
            const screenRes = await fetch(`${API}/screen_info`);
            const screenData = await screenRes.json();
            if (screenData.width) {
                const sc = screenData.scale || 3;
                state.screenSize = { w: screenData.width, h: screenData.height };
                state.wdaPoints = {
                    w: screenData.pointWidth || Math.round(screenData.width / sc),
                    h: screenData.pointHeight || Math.round(screenData.height / sc),
                };
                state.deviceScale = sc;
                state.screenInfo = {
                    width: screenData.width,
                    height: screenData.height,
                    scale: sc,
                    pointWidth: state.wdaPoints.w,
                    pointHeight: state.wdaPoints.h,
                };
            }
        } catch (e) {
            // Retain existing fallback screen metrics if /screen_info is unavailable.
        }
    } catch (e) {
        appendLog(_l('Could not connect to iPhone', 'Không kết nối được iPhone'), 'error');
    }
}

// -----------------------------------------------------------------------------
// Hardware Key & Quick Swipe Dispatch
// -----------------------------------------------------------------------------

/**
 * Dispatch a hardware button press (`home`, `power`, `volumeUp`, `volumeDown`)
 * to the connected device via `/key`.
 */
async function sendPress(button) {
    const key = (button || 'home').toString().toLowerCase();
    try {
        const res = await fetch(`${API}/key?key=${encodeURIComponent(key)}`);
        const data = await res.json().catch(() => ({}));
        if (data.ok === false) {
            appendLog(`⌨️ Key failed: ${data.error || key}`, 'error');
            return;
        }
        appendLog(_l(`⌨️ Pressed: ${key}`, `⌨️ Đã nhấn: ${key}`), 'success');
    } catch (e) {
        appendLog('⌨️ ' + e.message, 'error');
    }
}

/**
 * Dispatch a cardinal swipe gesture (`'up'`, `'down'`, `'left'`, `'right'`)
 * across the center of the screen using device-point coordinates.
 */
function quickSwipe(direction) {
    const udid = state.currentDevice;
    if (!udid) {
        return;
    }
    if (!state.wdaPoints || !state.wdaPoints.w || !state.wdaPoints.h) {
        appendLog(
            _l('⚠️ Screen size not initialized', '⚠️ Chưa lấy được kích thước màn hình'),
            'error',
        );
        return;
    }

    const w = state.wdaPoints.w;
    const h = state.wdaPoints.h;
    const cx = Math.round(w / 2);
    const cy = Math.round(h / 2);

    let x1;
    let y1;
    let x2;
    let y2;
    let duration;
    switch (direction) {
        case 'up':
            x1 = cx;
            y1 = Math.round(h * 0.7);
            x2 = cx;
            y2 = Math.round(h * 0.3);
            duration = 0.4;
            break;
        case 'down':
            x1 = cx;
            y1 = Math.round(h * 0.3);
            x2 = cx;
            y2 = Math.round(h * 0.7);
            duration = 0.4;
            break;
        case 'left':
            x1 = Math.round(w * 0.8);
            y1 = cy;
            x2 = Math.round(w * 0.2);
            y2 = cy;
            duration = 0.3;
            break;
        case 'right':
            x1 = Math.round(w * 0.2);
            y1 = cy;
            x2 = Math.round(w * 0.8);
            y2 = cy;
            duration = 0.3;
            break;
    }

    fetch(`${API}/swipe?x1=${x1}&y1=${y1}&x2=${x2}&y2=${y2}&duration=${duration}`).catch((e) =>
        appendLog('⚠️ Swipe network error: ' + e.message, 'error'),
    );
    appendLog(_l(`📱 Swipe ${direction} (${duration}s)`, `📱 Vuốt ${direction} (${duration}s)`));
}

// -----------------------------------------------------------------------------
// Device Information Modal & Setup Diagnostics
// -----------------------------------------------------------------------------

/**
 * Open the Device Information modal (`#deviceInfoModal`) and populate it with
 * hardware/screen attributes returned by `/screen_info`.
 */
async function showDeviceInfo() {
    const udid = state.currentDevice || 'local';
    if (!udid) {
        appendLog(_l('⚠️ No device connected', '⚠️ Chưa kết nối thiết bị'), 'error');
        return;
    }

    const modal = document.getElementById('deviceInfoModal');
    const body = document.getElementById('deviceInfoBody');
    body.innerHTML = '<p style="color: var(--text-dim)">Loading...</p>';
    modal.classList.add('visible');

    try {
        const res = await fetch(`${API}/screen_info`);
        const data = await res.json();
        if (data.success) {
            const info = data.info;
            body.innerHTML = `
                <div class="device-info-grid">
                    ${Object.entries(info)
                        .map(
                            ([key, val]) => `
                        <div class="device-info-item">
                            <div class="label">${key}</div>
                            <div class="value">${val || '—'}</div>
                        </div>
                    `,
                        )
                        .join('')}
                </div>
            `;
        }
    } catch (e) {
        body.innerHTML = `<p style="color:var(--red)">Failed to load: ${e.message}</p>`;
    }
}

/**
 * Query `/api/setup/check` on startup and log host environment warnings
 * (missing drivers or `pymobiledevice3` in desktop server mode).
 */
async function checkSystemSetup() {
    try {
        const res = await fetch(`${API}/api/setup/check`);
        const data = await res.json();

        if (data.ok || data.success) {
            if (data.issues && data.issues.length > 0) {
                appendLog(`⚠️ Setup issues: ${data.issues.join(', ')}`, 'error');
            }
            if (data.pymobiledevice3 === false) {
                appendLog('📦 pymobiledevice3 not installed — using mock mode');
            }
            if (data.os === 'Windows' && !data.apple_drivers) {
                appendLog('⚠️ Install iTunes for iPhone USB support', 'error');
            }
        }
    } catch (e) {
        // Endpoint is optional on embedded on-device HTTP server.
    }
}

/** Mount the Developer Disk Image (DDI) for `udid` via `/api/setup/ddi/:udid`. */
async function setupDDI(udid) {
    appendLog('📀 Setting up Developer Disk Image...');
    try {
        const res = await fetch(`${API}/api/setup/ddi/${udid}`);
        const data = await res.json();
        if (data.success) {
            appendLog(`✅ DDI ready for iOS ${data.ios_version}`, 'success');
        } else {
            appendLog(`❌ DDI setup failed: ${data.error || 'Unknown error'}`, 'error');
        }
    } catch (e) {
        appendLog(`❌ DDI setup error: ${e.message}`, 'error');
    }
}

/** Initialize WebDriverAgent (WDA) for `udid` via `/api/setup/wda/:udid`. */
async function setupWDA(udid) {
    appendLog('🔧 Setting up WebDriverAgent...');
    try {
        const res = await fetch(`${API}/api/setup/wda/${udid}`);
        const data = await res.json();
        if (data.success) {
            appendLog(
                `✅ WDA ready${data.session_id ? ' (session: ' + data.session_id + ')' : ''}`,
                'success',
            );
        } else {
            appendLog(`⚠️ WDA: ${data.error || 'Not available'}`, 'error');
            const guideRes = await fetch(`${API}/api/setup/wda/guide`);
            const guide = await guideRes.json();
            if (guide.methods) {
                appendLog('📖 WDA Installation Guide:');
                guide.methods.forEach((m) => {
                    appendLog(`  ${m.name}`);
                });
            }
        }
    } catch (e) {
        appendLog(`❌ WDA setup error: ${e.message}`, 'error');
    }
}

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.sendPress = sendPress;
window.quickSwipe = quickSwipe;
window.setupDDI = setupDDI;
window.setupWDA = setupWDA;
