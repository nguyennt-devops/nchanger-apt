/**
 * @file ui.i18n.js — Web IDE trilingual localization (`en`, `vi`, `zh`),
 * translation lookup helpers, and DOM localization bindings.
 *
 * Owns `IDE_LANGS`, `ideLang`, `IDE_I18N`, key/inline lookup functions (`_t`,
 * `_l`, `_sdkDoc`), signature display formatting (`_displaySig`), and DOM
 * `[data-i18n-ide]` / `[data-i18n-ide-placeholder]` synchronization.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Language State & Translation Dictionaries
// -----------------------------------------------------------------------------

/** Supported UI language codes. */
const IDE_LANGS = ['en', 'vi', 'zh'];

/** Active UI language code (`'en'`, `'vi'`, or `'zh'`). */
let ideLang = localStorage.getItem(STORAGE_KEYS.lang) || 'en';
if (!IDE_LANGS.includes(ideLang)) {
    ideLang = 'en';
}

/** Trilingual string tables keyed by language code and translation key. */
const IDE_I18N = {
    en: {
        screen: 'Screen',
        helper: 'Helper',
        noDevice: 'No device connected',
        scriptEditor: 'Write Code',
        files: 'Files',
        images: 'Images',
        console: 'Console',
        consoleLbl: 'Console',
        run: 'Run',
        stop: 'Stop',
        save: 'Save',
        clear: 'Clear',
        quickCmd: 'Run quick command',
        images: 'Images',
        hTabFunctions: 'Functions',
        searchFunctions: '🔍 Search functions (e.g. tap, color, app...)',
        screenPreview: 'Screen Preview',
        connectDevice: 'Connect a device to see screen',
        output: 'Log',
        welcomeTitle: 'Welcome to <strong>IOSAuto IDE</strong>',
        welcomeConnect: 'Connect an iPhone via USB to get started.',
        welcomeRun:
            'Write scripts in the editor and press <kbd>Run</kbd> or <kbd>Ctrl+Enter</kbd>.',
        saveScriptTitle: 'Save Script',
        scriptName: 'Script Name',
        saveBtn: 'Save',
        imgGalleryTitle: 'Image Gallery',
        imgGalleryDesc: 'Manage images on iPhone · Crop & save · Copy path to script',
        imgOnDevice: 'Images on device',
        imgNone: 'No images yet',
        imgHint: 'Press <b>Capture</b> or <b>Vol Up ×3</b> on iPhone',
        imgCrop: 'Crop',
        imgCapture: 'Capture',
        imgCropTitle: 'Drag to select crop area',
        imgCancel: 'Cancel',
        imgSaveToPhone: 'Save to iPhone',
        installedApps: 'Installed Apps',
        searchApps: 'Search apps...',
        loadingApps: 'Loading apps...',
        clickConnect: 'Click <b>Connect</b> to stream',
        vncLive: 'VNC Live',
        helperTools: 'Helper Tools',
        modeControl: 'Control',
        modePick: 'Write Code',
        newScript: 'New',
        newFolder: 'Folder',
        encTitle: 'Encrypt',
        encHint: 'Encrypt script to .aios — any device with IOSAuto can run.',
        encBtn: 'Encrypt',
        noScripts: 'No saved scripts yet',
        copy: 'Copy',
        editor: 'Editor',
        smartConvert: 'Smart Convert',
        paste: 'Paste',
        deviceInfo: 'Device Information',
        noDeviceInfo: 'No device connected',
        screenshot: 'Screenshot',
        close: 'Close',
        loadingScreenshot: 'Loading screenshot...',
        hTabColor: 'Color',
        hTabImage: 'Image',
        hTabApps: 'Apps',
        searchApps2: 'Search apps...',
        hmSearchPlaceholder: '🔍 Find function (e.g. tap, color, app...)',
        hmPickPoint: '👉 Click 1 point on screen',
        hmPickRegion: '👉 Click 2 points: top-left and bottom-right of region',
        hmPickPointTooltip: 'Click on screen to capture coordinates',
        hmPickRegionTooltip: 'Drag to select region',
        hmBtnDom: 'Scan',
        hmBtnDomTip: 'Scan Safari page → pick a field/button',
        hmBtnAx: '👁 Scan UI',
        hmBtnAxTip: 'Scan on-screen controls in the foreground app → pick (like OCR)',
        hmBtnOcr: '📖 Scan text',
        hmBtnOcrTip: 'Scan text from current screen → pick',
        hmBtnRandom: '🎲 Random',
        hmBtnRandomTip: 'Enter a list → script picks one at random when run',
        hmBtnCrop: '✂️ Crop image',
        hmBtnCropTip: 'Crop image from current screen — saves PNG to images folder',
        hmBtnPickPoint: '📍 Pick point',
        hmBtnPickRegion: '📍 Pick region',
        hmBtnPickColor: '🎨 Pick color from screen',
        hmBtnCopy: 'Copy',
        hmBtnInsert: '➕ Add to Script',
        hintX: 'X position (left→right)',
        hintY: 'Y position (top→bottom)',
        hintDuration: 'seconds, e.g. 0.3',
        hintSeconds: 'seconds, e.g. 1',
        hintTimeout: 'max wait (seconds)',
        hintInterval: 'check every (seconds)',
        hintDelaySec: 'delay between keys (sec), e.g. 0.08–0.15',
        hintType: '1=red 2=yellow 3=white 4=green',
        hintText: 'text to show',
        hintTitle: 'title',
        hintMessage: 'description',
        hintUrl: 'https://...',
        hintPath: 'file path',
        hintBundle: 'app id, e.g. com.apple...',
        hintLabel: 'field/button name',
        hintValue: 'value to fill',
        hintCommand: 'shell command',
        hintSize: 'pixels',
        hintFinger: '1-5',
        hintMatch: '0.9 or 90 — OCR match ratio',
        hmLoadingSdk: '⏳ Loading SDK...',
        catTouch: 'Touch',
        catKeyboard: 'Keyboard',
        catClipboard: 'Clipboard',
        catColor: 'Color',
        catImage: 'Image',
        catVCam: 'VCam',
        catOCR: 'OCR',
        catSystem: 'System',
        catApp: 'App',
        catFile: 'File',
        catNetwork: 'Network',
        catSleep: 'Sleep',
        catUI: 'Feedback',
        catPower: 'Screen',
        catRecording: 'Recording',
        catCron: 'Schedule',
        catScript: 'Script',
        catSafari: 'Safari',
        catLang: 'Utilities',
        imgUpload: 'Script folder',
        imgCountLabel: 'images',
        albumImport: 'Phone Photos',
        albumImportOk: 'Saved to Photos: ',
        albumImportFail: 'Photos save failed: ',
        albumImportDone: 'Photos done ',
        vcamImport: 'VCam',
        vcamImportOk: 'VCam on: ',
        vcamImportFail: 'VCam failed: ',
        imgEmpty: 'No images — click Upload to add',
        imgCopied: 'Copied: ',
        imgDeleteConfirm: 'Delete image ',
        imgDeleteLabel: 'Delete image',
        imgDeleteFail: '❌ Delete failed: ',
        imgUploadOk: '✓ Uploaded ',
        imgUploadFail: '❌ Upload failed: ',
        imgLoadErr: 'Error loading images: ',
        insertLog: '⬇️ Inserted: ',
        copyLog: 'Copied: ',
        hmTitle: 'Title',
        hmContent: 'Text',
        hmDuration: 'Duration',
        hmColor: 'Color',
        hmBg: 'Background',
        hmFg: 'Text color',
        hmToastPh: 'Toast text',
        hmCopiedToast: 'Copied',
        hmDefault: 'Default',
        hmButtons: 'Buttons',
        hmBtnBg: 'Button bg',
        hmBtnFg: 'Button text',
        randTabList: 'List',
        randTabEmail: 'Email',
        randListHint: 'One item per line — script picks one at run',
        randPrefixHint: 'Prefix (before @) — built from charset',
        randLen: 'Length',
        randChars: 'chars',
        randDomainHint: 'Domain (after @) — one per line',
    },
    vi: {
        screen: 'M.Hình',
        helper: 'Trợ giúp',
        noDevice: 'Chưa kết nối',
        scriptEditor: 'Viết lệnh',
        files: 'Tệp',
        images: 'Ảnh',
        console: 'Bảng đk',
        consoleLbl: 'Bảng đk',
        run: 'Chạy',
        stop: 'Dừng',
        save: 'Lưu',
        clear: 'Xoá',
        quickCmd: 'Chạy lệnh ngắn',
        images: 'Ảnh',
        hTabFunctions: 'Hàm',
        searchFunctions: '🔍 Tìm hàm (vd: tap, color, app...)',
        screenPreview: 'Xem màn hình',
        connectDevice: 'Kết nối thiết bị để xem',
        output: 'Nhật ký',
        welcomeTitle: 'Chào mừng đến <strong>IOSAuto IDE</strong>',
        welcomeConnect: 'Kết nối iPhone qua USB để bắt đầu.',
        welcomeRun:
            'Viết script trong trình soạn thảo và nhấn <kbd>Chạy</kbd> hoặc <kbd>Ctrl+Enter</kbd>.',
        saveScriptTitle: 'Lưu Script',
        scriptName: 'Tên Script',
        saveBtn: 'Lưu',
        imgGalleryTitle: 'Thư viện ảnh',
        imgGalleryDesc: 'Quản lý ảnh trên iPhone · Cắt & lưu · Copy đường dẫn vào script',
        imgOnDevice: 'Ảnh trên thiết bị',
        imgNone: 'Chưa có ảnh',
        imgHint: 'Bấm <b>Chụp</b> hoặc <b>Vol Up ×3</b> trên iPhone',
        imgCrop: 'Cắt',
        imgCapture: 'Chụp',
        imgCropTitle: 'Kéo chọn vùng cần cắt',
        imgCancel: 'Huỷ',
        imgSaveToPhone: 'Lưu vào iPhone',
        installedApps: 'Ứng dụng đã cài',
        searchApps: 'Tìm ứng dụng...',
        loadingApps: 'Đang tải...',
        clickConnect: 'Bấm <b>Kết nối</b> để xem',
        vncLive: 'Trực tiếp',
        helperTools: 'Công cụ hỗ trợ',
        modeControl: 'Điều khiển',
        modePick: 'Viết lệnh',
        newScript: 'Tạo mới',
        newFolder: 'Thư mục',
        encTitle: 'Mã hoá',
        encHint: 'Mã hoá script thành .aios — máy nào có IOSAuto đều chạy được.',
        encBtn: 'Mã hoá',
        noScripts: 'Chưa có script nào',
        copy: 'Copy',
        editor: 'Editor',
        smartConvert: 'Chuyển đổi thông minh',
        paste: 'Dán',
        deviceInfo: 'Thông tin thiết bị',
        noDeviceInfo: 'Chưa kết nối thiết bị',
        screenshot: 'Chụp màn hình',
        close: 'Đóng',
        loadingScreenshot: 'Đang tải ảnh...',
        hTabColor: 'Màu',
        hTabImage: 'Ảnh',
        hTabApps: 'Ứng dụng',
        searchApps2: 'Tìm ứng dụng...',
        hmSearchPlaceholder: '🔍 Tìm hàm (vd: tap, color, app...)',
        hmPickPoint: '👉 Click 1 điểm trên ảnh',
        hmPickRegion: '👉 Click 2 điểm: góc trên-trái và dưới-phải của vùng',
        hmPickPointTooltip: 'Click trên màn hình để lấy toạ độ',
        hmPickRegionTooltip: 'Kéo chọn vùng',
        hmBtnDom: 'Quét',
        hmBtnDomTip: 'Quét trang Safari → chọn ô/nút có sẵn',
        hmBtnAx: '👁 Quét UI',
        hmBtnAxTip: 'Quét nút/ô trên app đang mở → chọn (giống Quét chữ)',
        hmBtnOcr: '📖 Quét chữ',
        hmBtnOcrTip: 'Quét chữ từ màn hình hiện tại → chọn',
        hmBtnRandom: '🎲 Ngẫu nhiên',
        hmBtnRandomTip: 'Nhập danh sách → script chọn ngẫu nhiên 1 mục khi chạy',
        hmBtnCrop: '✂️ Cắt ảnh',
        hmBtnCropTip: 'Cắt ảnh từ màn hình hiện tại — lưu PNG vào thư mục images',
        hmBtnPickPoint: '📍 Chọn điểm',
        hmBtnPickRegion: '📍 Chọn vùng',
        hmBtnPickColor: '🎨 Lấy màu từ màn hình',
        hmBtnCopy: 'Copy',
        hmBtnInsert: '➕ Thêm vào lệnh',
        hintX: 'Toạ độ X (trái→phải)',
        hintY: 'Toạ độ Y (trên→dưới)',
        hintDuration: 'giây, vd: 0.3',
        hintSeconds: 'giây, vd: 1',
        hintTimeout: 'chờ tối đa (giây)',
        hintInterval: 'kiểm tra mỗi (giây)',
        hintDelaySec: 'nghỉ giữa ký tự (giây), vd: 0.08–0.15',
        hintType: '1=đỏ 2=vàng 3=trắng 4=xanh',
        hintText: 'nội dung hiển thị',
        hintTitle: 'tiêu đề',
        hintMessage: 'mô tả',
        hintUrl: 'https://...',
        hintPath: 'đường dẫn tệp',
        hintBundle: 'id app, vd: com.apple...',
        hintLabel: 'tên ô/nút',
        hintValue: 'giá trị cần điền',
        hintCommand: 'lệnh shell',
        hintSize: 'pixel',
        hintFinger: '1-5',
        hintMatch: '0.9 hoặc 90 — tỉ lệ khớp OCR',
        hmLoadingSdk: '⏳ Đang tải SDK...',
        catTouch: 'Chạm/Vuốt',
        catKeyboard: 'Bàn phím',
        catClipboard: 'Bộ nhớ tạm',
        catColor: 'Màu',
        catImage: 'Ảnh',
        catVCam: 'VCam',
        catOCR: 'Đọc chữ',
        catSystem: 'Hệ thống',
        catApp: 'Ứng dụng',
        catFile: 'Tệp',
        catNetwork: 'Mạng',
        catSleep: 'Nghỉ',
        catUI: 'Thông báo',
        catPower: 'Màn hình',
        catRecording: 'Ghi',
        catCron: 'Lịch',
        catScript: 'Kịch bản',
        catSafari: 'Safari',
        catLang: 'Tiện ích',
        imgUpload: 'Thư mục script',
        imgCountLabel: 'ảnh',
        albumImport: 'Ảnh máy',
        albumImportOk: 'Đã vào Ảnh: ',
        albumImportFail: 'Lưu Ảnh thất bại: ',
        albumImportDone: 'Xong Ảnh ',
        vcamImport: 'Camera ảo',
        vcamImportOk: 'Đã bật VCam: ',
        vcamImportFail: 'VCam lỗi: ',
        imgEmpty: 'Chưa có ảnh — bấm Upload để tải lên',
        imgCopied: 'Copied: ',
        imgDeleteConfirm: 'Xoá ảnh ',
        imgDeleteLabel: 'Xoá ảnh',
        imgDeleteFail: '❌ Xoá ảnh thất bại: ',
        imgUploadOk: '✓ Tải lên ',
        imgUploadFail: '❌ Tải lên thất bại: ',
        imgLoadErr: 'Lỗi tải ảnh: ',
        insertLog: '⬇️ Đã chèn: ',
        copyLog: 'Copied: ',
        hmTitle: 'Tiêu đề',
        hmContent: 'Nội dung',
        hmDuration: 'Thời gian',
        hmColor: 'Màu',
        hmBg: 'Màu nền',
        hmFg: 'Màu chữ',
        hmToastPh: 'Nội dung toast',
        hmCopiedToast: 'Copied',
        hmDefault: 'Mặc định',
        hmButtons: 'Nút',
        hmBtnBg: 'Nút nền',
        hmBtnFg: 'Nút chữ',
        randTabList: 'Danh sách',
        randTabEmail: 'Email',
        randListHint: 'Mỗi dòng 1 mục — script chọn ngẫu nhiên khi chạy',
        randPrefixHint: 'Phần trước @ — ghép từ bộ ký tự',
        randLen: 'Độ dài',
        randChars: 'ký tự',
        randDomainHint: 'Phần sau @ — mỗi dòng 1 domain',
    },
    zh: {
        screen: '屏幕',
        helper: '助手',
        noDevice: '未连接设备',
        scriptEditor: '写脚本',
        files: '文件',
        images: '图片',
        console: '控制台',
        consoleLbl: '控制台',
        run: '运行',
        stop: '停止',
        save: '保存',
        clear: '清除',
        quickCmd: '运行快捷命令',
        hTabFunctions: '函数',
        searchFunctions: '🔍 搜索函数（如 tap、color、app）',
        screenPreview: '屏幕预览',
        connectDevice: '连接设备后可查看屏幕',
        output: '日志',
        welcomeTitle: '欢迎使用 <strong>IOSAuto IDE</strong>',
        welcomeConnect: '通过 USB 连接 iPhone 即可开始。',
        welcomeRun: '在编辑器中写脚本，按 <kbd>运行</kbd> 或 <kbd>Ctrl+Enter</kbd>。',
        saveScriptTitle: '保存脚本',
        scriptName: '脚本名称',
        saveBtn: '保存',
        imgGalleryTitle: '图片库',
        imgGalleryDesc: '管理 iPhone 上的图片 · 裁剪保存 · 复制路径到脚本',
        imgOnDevice: '设备上的图片',
        imgNone: '暂无图片',
        imgHint: '点 <b>截图</b> 或在 iPhone 上 <b>音量+ ×3</b>',
        imgCrop: '裁剪',
        imgCapture: '截图',
        imgCropTitle: '拖选裁剪区域',
        imgCancel: '取消',
        imgSaveToPhone: '保存到 iPhone',
        installedApps: '已安装应用',
        searchApps: '搜索应用…',
        loadingApps: '加载中…',
        clickConnect: '点击 <b>连接</b> 开始推流',
        vncLive: 'VNC 实时',
        helperTools: '辅助工具',
        modeControl: '控制',
        modePick: '写脚本',
        newScript: '新建',
        newFolder: '文件夹',
        encTitle: '加密',
        encHint: '加密为 .aios — 任何安装 IOSAuto 的设备都能运行。',
        encBtn: '加密',
        noScripts: '还没有已保存的脚本',
        copy: 'Copy',
        editor: '编辑器',
        smartConvert: '智能转换',
        paste: '粘贴',
        deviceInfo: '设备信息',
        noDeviceInfo: '未连接设备',
        screenshot: '截图',
        close: '关闭',
        loadingScreenshot: '正在加载截图…',
        hTabColor: '颜色',
        hTabImage: '图片',
        hTabApps: '应用',
        searchApps2: '搜索应用…',
        hmSearchPlaceholder: '🔍 查找函数（如 tap、color、app）',
        hmPickPoint: '👉 在屏幕上点 1 个位置',
        hmPickRegion: '👉 点 2 个位置：区域左上和右下',
        hmPickPointTooltip: '点击屏幕获取坐标',
        hmPickRegionTooltip: '拖选区域',
        hmBtnDom: '扫描',
        hmBtnDomTip: '扫描 Safari 页面 → 选择输入框/按钮',
        hmBtnAx: '👁 扫描界面',
        hmBtnAxTip: '扫描前台应用控件 → 选择（类似 OCR）',
        hmBtnOcr: '📖 扫描文字',
        hmBtnOcrTip: '从当前屏幕识别文字 → 选择',
        hmBtnRandom: '🎲 随机',
        hmBtnRandomTip: '输入列表 → 运行时随机选一项',
        hmBtnCrop: '✂️ 裁剪图片',
        hmBtnCropTip: '从当前屏幕裁剪 — 保存 PNG 到 images',
        hmBtnPickPoint: '📍 选点',
        hmBtnPickRegion: '📍 选区域',
        hmBtnPickColor: '🎨 从屏幕取色',
        hmBtnCopy: 'Copy',
        hmBtnInsert: '➕ 插入脚本',
        hintX: 'X 坐标（左→右）',
        hintY: 'Y 坐标（上→下）',
        hintDuration: '秒，例如 0.3',
        hintSeconds: '秒，例如 1',
        hintTimeout: '最长等待（秒）',
        hintInterval: '检查间隔（秒）',
        hintDelaySec: '按键间隔（秒），例如 0.08–0.15',
        hintType: '1=红 2=黄 3=白 4=绿',
        hintText: '要显示的文字',
        hintTitle: '标题',
        hintMessage: '说明',
        hintUrl: 'https://...',
        hintPath: '文件路径',
        hintBundle: '应用 ID，例如 com.apple...',
        hintLabel: '控件/按钮名称',
        hintValue: '要填入的值',
        hintCommand: 'shell 命令',
        hintSize: '像素',
        hintFinger: '1-5',
        hintMatch: '0.9 或 90 — OCR 匹配度',
        hmLoadingSdk: '⏳ 正在加载 SDK…',
        catTouch: '触摸/滑动',
        catKeyboard: '键盘',
        catClipboard: '剪贴板',
        catColor: '颜色',
        catImage: '图片',
        catVCam: '虚拟摄像头',
        catOCR: '识字',
        catSystem: '系统',
        catApp: '应用',
        catFile: '文件',
        catNetwork: '网络',
        catSleep: '等待',
        catUI: '提示',
        catPower: '屏幕',
        catRecording: '录制',
        catCron: '计划',
        catScript: '脚本',
        catSafari: 'Safari',
        catLang: '工具函数',
        imgUpload: '脚本目录',
        imgCountLabel: '张图片',
        albumImport: '手机相册',
        albumImportOk: '已保存到相册: ',
        albumImportFail: '保存相册失败: ',
        albumImportDone: '相册完成 ',
        vcamImport: '虚拟摄像头',
        vcamImportOk: '已开 VCam: ',
        vcamImportFail: 'VCam 失败: ',
        imgEmpty: '暂无图片 — 点上传添加',
        imgCopied: '📋 已复制：',
        imgDeleteConfirm: '删除图片 ',
        imgDeleteLabel: '删除图片',
        imgDeleteFail: '❌ 删除失败：',
        imgUploadOk: '✓ 已上传 ',
        imgUploadFail: '❌ 上传失败：',
        imgLoadErr: '加载图片出错：',
        insertLog: '⬇️ 已插入：',
        copyLog: '📋 已复制：',
        hmTitle: '标题',
        hmContent: '内容',
        hmDuration: '时长',
        hmColor: '颜色',
        hmBg: '背景',
        hmFg: '文字色',
        hmToastPh: '提示文字',
        hmCopiedToast: '已复制',
        hmDefault: '默认',
        hmButtons: '按钮',
        hmBtnBg: '按钮背景',
        hmBtnFg: '按钮文字',
        randTabList: '列表',
        randTabEmail: '邮箱',
        randListHint: '每行一项 — 运行时随机选一项',
        randPrefixHint: '@ 前缀 — 由字符集生成',
        randLen: '长度',
        randChars: '字符',
        randDomainHint: '@ 后缀 — 每行一个域名',
    },
};

// -----------------------------------------------------------------------------
// Translation Lookup & Formatting Helpers
// -----------------------------------------------------------------------------

/**
 * Look up a localized UI string by `key` in the active language dictionary,
 * falling back to `fallback` or the raw `key` when absent.
 */
function _t(key, fallback) {
    const translations = IDE_I18N[ideLang] || IDE_I18N.en;
    return translations[key] || fallback || key;
}

/**
 * Inline trilingual selector returning `vi`, `zh` (if non-empty), or `en`
 * based on the active `ideLang`.
 */
function _l(en, vi, zh) {
    if (ideLang === 'vi') {
        return vi;
    }
    if (ideLang === 'zh') {
        return zh != null && zh !== '' ? zh : en;
    }
    return en;
}

/**
 * Strip trailing inline comments (`— ...` or `// ...`) from an SDK signature
 * string before displaying it in compact UI badges.
 */
function _displaySig(sig) {
    return String(sig || '()')
        .replace(/\s*(—|\/\/).*$/, '')
        .trim();
}

/**
 * Resolve localized documentation for an SDK method `name` from the active
 * language table (`_sdkVIDoc`, `_sdkZHDoc`, or `_sdkENDoc`), falling back to
 * the unqualified method name (`string.upper` -> `upper`) and `fallback`.
 */
function _sdkDoc(name, fallback) {
    const descriptions =
        ideLang === 'vi'
            ? window._sdkVIDoc
            : ideLang === 'zh'
              ? window._sdkZHDoc
              : window._sdkENDoc;
    if (!descriptions) {
        return fallback || '';
    }
    if (descriptions[name]) {
        return descriptions[name];
    }
    const unqualifiedName = name.replace(/^(string|math)\./, '');
    return descriptions[unqualifiedName] || fallback || '';
}

// -----------------------------------------------------------------------------
// DOM Localization & Server Synchronization
// -----------------------------------------------------------------------------

/**
 * Apply the language preference returned by `/api/ping` when it is supported
 * and differs from the current `ideLang`.
 */
function _applyServerLang(data) {
    const lang = data && data.lang;
    if (!lang || !IDE_LANGS.includes(lang) || lang === ideLang) {
        return;
    }
    ideLang = lang;
    applyIDELang();
}

/**
 * Synchronize all `[data-i18n-ide]` and `[data-i18n-ide-placeholder]` DOM
 * elements, language selector state, SDK catalog descriptions, Helper
 * accordion labels, and active Images tab with the current `ideLang`.
 */
function applyIDELang() {
    const s = IDE_I18N[ideLang] || IDE_I18N.en;
    const sel = document.getElementById('ideLangSelect');
    if (sel) {
        sel.value = ideLang;
    }
    localStorage.setItem(STORAGE_KEYS.lang, ideLang);

    document.querySelectorAll('[data-i18n-ide]').forEach((el) => {
        const key = el.getAttribute('data-i18n-ide');
        if (s[key]) {
            if (el.tagName === 'INPUT') {
                el.placeholder = s[key];
            } else {
                el.innerHTML = s[key];
            }
        }
    });

    document.querySelectorAll('[data-i18n-ide-placeholder]').forEach((el) => {
        const key = el.getAttribute('data-i18n-ide-placeholder');
        if (s[key]) {
            el.placeholder = s[key];
        }
    });

    if (typeof initSdkCatalog === 'function') {
        initSdkCatalog();
    }
    if (typeof window._buildHelperAccordion === 'function') {
        window._buildHelperAccordion();
    }
    if (
        typeof loadImagesTab === 'function' &&
        document.querySelector('.tab[data-tab="images"].active')
    ) {
        loadImagesTab();
    }
}

/**
 * Initialize Web IDE localization on startup and bind `#ideLangSelect` changes
 * to persist the selected language via `/api/lang`.
 */
function initIDELang() {
    applyIDELang();
    const sel = document.getElementById('ideLangSelect');
    if (!sel) {
        return;
    }
    sel.value = ideLang;
    sel.addEventListener('change', () => {
        if (!IDE_LANGS.includes(sel.value)) {
            return;
        }
        ideLang = sel.value;
        applyIDELang();
        fetch(`${API}/api/lang`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ lang: ideLang }),
        }).catch(() => {});
    });
}
