/**
 * @file ui.theme.js — Web IDE Dark/Light theme state, server preference
 * synchronization, and theme toggle control.
 *
 * Synchronizes the `[data-theme]` root attribute, Lucide header icon,
 * browser `localStorage`, Monaco editor theme (`iosauto-dark` / `iosauto-light`),
 * and `/api/theme` server persistence.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Theme State
// -----------------------------------------------------------------------------

/** Active UI theme (`'dark'` or `'light'`), initialized from `localStorage`. */
let ideTheme = localStorage.getItem(STORAGE_KEYS.theme) || 'dark';

// -----------------------------------------------------------------------------
// Theme Synchronization & Toggle Handlers
// -----------------------------------------------------------------------------

/**
 * Apply the theme reported by `/api/ping` when it differs from the local theme.
 */
function _applyServerTheme(data) {
    const serverTheme = data && data.theme;
    if (serverTheme !== 'light' && serverTheme !== 'dark') {
        return;
    }
    if (serverTheme === ideTheme) {
        return;
    }
    ideTheme = serverTheme;
    applyIDETheme();
}

/**
 * Apply the current `ideTheme` to the document root, theme toggle icon,
 * `localStorage`, and active Monaco editor instance.
 */
function applyIDETheme() {
    document.documentElement.setAttribute('data-theme', ideTheme);
    const icon = document.getElementById('ideThemeIcon');
    if (icon) {
        const iconName = ideTheme === 'dark' ? 'moon' : 'sun';
        icon.innerHTML = `<i data-lucide="${iconName}" style="width:16px;height:16px;"></i>`;
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }
    localStorage.setItem(STORAGE_KEYS.theme, ideTheme);
    if (window.monaco) {
        monaco.editor.setTheme(ideTheme === 'dark' ? 'iosauto-dark' : 'iosauto-light');
    }
}

/**
 * Initialize the Web IDE theme on startup and bind the header theme toggle
 * button (`#ideThemeToggle`) to persist changes to `/api/theme`.
 */
function initIDETheme() {
    applyIDETheme();
    document.getElementById('ideThemeToggle')?.addEventListener('click', () => {
        ideTheme = ideTheme === 'dark' ? 'light' : 'dark';
        applyIDETheme();
        fetch(`${API}/api/theme`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ theme: ideTheme }),
        }).catch(() => {});
    });
}
