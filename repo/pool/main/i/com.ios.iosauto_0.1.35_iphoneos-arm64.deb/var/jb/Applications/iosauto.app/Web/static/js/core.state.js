/**
 * @file core.state.js — Shared runtime state, coordinate conversion, formatting
 * utilities, clipboard/toast notifications, and run-button state machine.
 *
 * Owns the global `state` singleton, `API` base URL, pixel-to-point coordinate
 * helpers (`_deviceScale`, `_pxToPt`, `_pxRectToPt`), localStorage key names,
 * console emoji-to-Lucide mapping, HTML/JS escaping, clipboard/toast feedback,
 * and the single-source-of-truth script run button state machine.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Shared Runtime State & Configuration
// -----------------------------------------------------------------------------

/**
 * Global mutable application state shared across all Web IDE modules.
 * Property names and persisted key identifiers must remain stable.
 */
const state = {
    currentDevice: null,
    devices: [],
    runningTaskId: null,
    logPollInterval: null,
    lastLogIndex: 0,
    screenScale: { x: 1, y: 1 },
    screenSize: { w: 390, h: 844 },
    wdaPoints: { w: 390, h: 844 },
    deviceScale: 3,
    editor: null,
    helperActive: false,
    helperMode: 'single',
    pickedColors: [],
    regionStart: null,
    currentFileName: null,
    recording: false,
    recordedGestures: [],
    openTabs: [],
    activeTabId: null,
};

/** Base URL prefix for local HTTP API requests (empty for same-origin). */
const API = '';

/** Browser `localStorage` keys for persisted Web IDE user preferences. */
const STORAGE_KEYS = {
    theme: 'iosauto-theme',
    lang: 'iosauto-lang',
};

/** Mapping from console log emoji prefixes to Lucide icon names. */
const EMOJI_MAP = {
    '📱': 'smartphone',
    '📐': 'ruler',
    '📺': 'monitor',
    '✅': 'check-circle',
    '❌': 'x-circle',
    '⚠️': 'alert-triangle',
    '▶️': 'play',
    '⏹️': 'square',
    '🔄': 'refresh-cw',
    '⬇️': 'arrow-down-to-line',
    '💾': 'save',
    '🗑️': 'trash-2',
    '📂': 'folder-open',
    '📋': 'clipboard',
    '📸': 'camera',
    '🔧': 'wrench',
    '⏱️': 'timer',
    '✏️': 'pencil',
    '🎯': 'crosshair',
    '⌨️': 'keyboard',
    '🔥': 'flame',
    '🔍': 'search',
    '🎨': 'palette',
    '💡': 'lightbulb',
};

// -----------------------------------------------------------------------------
// Coordinate Conversion (Physical Pixels -> Device Points)
// -----------------------------------------------------------------------------

/**
 * Return the active Retina scale factor (e.g. 2x or 3x) used to convert
 * physical screenshot pixels into iOS device points.
 * Falls back to `3` when `state.deviceScale` is not a positive number.
 */
function _deviceScale() {
    const scale = Number(state.deviceScale);
    return scale > 0 ? scale : 3;
}

/**
 * Convert physical screenshot coordinates `(x, y)` in pixels to iOS device
 * points consumed by ALang touch and color APIs (`/tap`, `/color`).
 */
function _pxToPt(x, y) {
    const scale = _deviceScale();
    return {
        x: Math.round(Number(x) / scale),
        y: Math.round(Number(y) / scale),
    };
}

/**
 * Convert a pixel rectangle `(rx, ry, rw, rh)` into a 4-element device-point
 * array `[x, y, width, height]` with each component rounded independently.
 */
function _pxRectToPt(rx, ry, rw, rh) {
    const scale = _deviceScale();
    return [
        Math.round(Number(rx) / scale),
        Math.round(Number(ry) / scale),
        Math.round(Number(rw) / scale),
        Math.round(Number(rh) / scale),
    ];
}

// -----------------------------------------------------------------------------
// Formatting, DOM Capping & String Escaping Utilities
// -----------------------------------------------------------------------------

/** Format a `Date` instance as a zero-padded `HH:MM:SS` timestamp string. */
function formatTime(date) {
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}

/**
 * Trim oldest `.console-line` child elements so the container never exceeds
 * `maxLines` rendered DOM nodes.
 */
function capConsoleDOMLines(container, maxLines) {
    const allLines = container.querySelectorAll('.console-line');
    if (allLines.length > maxLines) {
        const toRemove = allLines.length - maxLines;
        for (let i = 0; i < toRemove; i++) {
            allLines[i].remove();
        }
    }
}

/** Generate a timestamped default script base name (`script_MMDD_HHMM`). */
function generateScriptName(prefix = 'script_') {
    const date = new Date();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${prefix}${month}${day}_${hours}${minutes}`;
}

/** Escape arbitrary text for safe insertion into HTML element content. */
function escapeHtml(str) {
    const container = document.createElement('div');
    container.textContent = str;
    return container.innerHTML;
}

/**
 * Escape a string for safe embedding inside single-quoted inline JavaScript
 * event handler attributes (`onclick="fn('${escJS(val)}')"`) in HTML templates.
 */
function escJS(s) {
    return String(s == null ? '' : s).replace(
        /[\\'"<>&\r\n]/g,
        (c) =>
            ({
                '\\': '\\\\',
                "'": "\\'",
                '"': '\\u0022',
                '<': '\\u003c',
                '>': '\\u003e',
                '&': '\\u0026',
                '\r': '\\r',
                '\n': '\\n',
            })[c],
    );
}

// -----------------------------------------------------------------------------
// Clipboard & Toast Notification Helpers
// -----------------------------------------------------------------------------

/**
 * Copy `text` to the system clipboard using the async Clipboard API in secure
 * contexts, falling back to a temporary off-screen `<textarea>` over plain HTTP.
 */
function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        return navigator.clipboard.writeText(text);
    }
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;left:-9999px;top:-9999px;';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    return Promise.resolve();
}

/** Copy `text` to the clipboard and log the first line to the IDE console. */
function _hmDoCopy(text) {
    const copiedText = text == null ? '' : String(text);
    copyToClipboard(copiedText);
    appendLog(_t('copyLog') + (copiedText.split('\n')[0] || ''), 'success');
}

/**
 * Display a floating accent-styled toast banner triggered by script `__TOAST__`
 * console messages or IDE feedback.
 */
function show_toast(message, duration = 1500) {
    const existing = document.getElementById('ideToast');
    if (existing) {
        existing.remove();
    }
    const toast = document.createElement('div');
    toast.id = 'ideToast';
    toast.textContent = message;
    toast.style.cssText = `
    position: fixed; bottom: 24px; right: 24px; z-index: 99999;
    background: var(--accent-gradient); color: #fff;
    padding: 10px 20px; border-radius: 8px;
    font-size: 13px; font-weight: 600; font-family: var(--font-sans);
    box-shadow: 0 4px 20px rgba(129,140,248,0.42);
    opacity: 0; transform: translateY(10px);
    transition: opacity 0.2s ease, transform 0.2s ease;
    pointer-events: none;
  `;
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    });
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(() => toast.remove(), 200);
    }, duration);
}

/**
 * Display a status toast (`success`, `warning`, or `error`) in the bottom-right
 * corner of the viewport for file and license operations.
 */
function showToast(text, kind) {
    const id = 'zx-toast-' + Date.now();
    const el = document.createElement('div');
    el.id = id;

    let bg = '#10b981';
    if (kind === 'error') {
        bg = '#ef4444';
    } else if (kind === 'warning') {
        bg = '#f59e0b';
    }

    el.style.cssText = `position:fixed;bottom:20px;right:20px;background:${bg};color:#fff;padding:10px 16px;border-radius:8px;font-size:13px;font-weight:500;box-shadow:0 4px 16px rgba(0,0,0,0.3);z-index:99999;opacity:0;transform:translateY(10px);transition:opacity 0.2s, transform 0.2s;`;
    el.textContent = text;
    document.body.appendChild(el);
    requestAnimationFrame(() => {
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
    });
    setTimeout(() => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(10px)';
        setTimeout(() => el.remove(), 250);
    }, 2000);
}

// -----------------------------------------------------------------------------
// Script Run-Button State Machine
// -----------------------------------------------------------------------------
// Single source of truth for the toolbar Run/Stop controls:
//   - 'idle'    : No script running -> show Run button enabled.
//   - 'running' : Script active -> show Stop button enabled.
//   - 'pending' : Start/Stop request in flight -> dim and disable active button
//                 until the daemon state poll confirms the transition.

let _runBtnMode = null;
let _runRequestBusy = false;

/** Synchronize the Run button disabled/opacity state with in-flight requests. */
function _syncRunRequestButton() {
    const runBtn = document.getElementById('runBtn');
    if (!runBtn) {
        return;
    }
    const pending = _runRequestBusy || _runBtnMode === 'pending';
    runBtn.disabled = pending;
    runBtn.style.opacity = pending ? '0.5' : '1';
}

/**
 * Gate script execution so only one run request can be in flight at a time.
 * Returns `true` if admitted, or `false` if a previous request is still pending.
 */
function _beginRunRequest() {
    if (_runRequestBusy) {
        appendLog(_l('A run request is already pending', 'Đang chờ yêu cầu chạy trước'), 'warn');
        return false;
    }
    _runRequestBusy = true;
    _syncRunRequestButton();
    return true;
}

/** Release the in-flight run request gate and restore button interactivity. */
function _endRunRequest() {
    _runRequestBusy = false;
    _syncRunRequestButton();
}

/**
 * Transition the Run/Stop toolbar buttons between `'idle'`, `'running'`, and
 * `'pending'` states. Accepts legacy boolean arguments (`true` -> `'running'`,
 * `false` -> `'idle'`) and skips redundant DOM updates when the mode is unchanged.
 */
function setRunButtonsState(mode) {
    if (mode === true) {
        mode = 'running';
    } else if (mode === false) {
        mode = 'idle';
    }
    if (mode === _runBtnMode) {
        return;
    }
    _runBtnMode = mode;

    const runBtn = document.getElementById('runBtn');
    const stopBtn = document.getElementById('stopBtn');
    const running = mode === 'running';
    const pending = mode === 'pending';

    if (runBtn) {
        runBtn.style.display = running ? 'none' : 'flex';
        runBtn.disabled = pending;
        runBtn.style.opacity = pending ? '0.5' : '1';
    }
    if (stopBtn) {
        stopBtn.style.display = running ? 'flex' : 'none';
        stopBtn.disabled = pending;
        stopBtn.style.opacity = pending ? '0.5' : '1';
    }
    _syncRunRequestButton();
}

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.showToast = showToast;
