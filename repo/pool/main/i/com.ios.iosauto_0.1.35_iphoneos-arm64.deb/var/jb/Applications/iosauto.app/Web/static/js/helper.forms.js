/**
 * @file helper.forms.js — Helper signature parser, argument hints/defaults,
 * shared form widgets, generic method form builder, and SDK category accordion.
 *
 * Parses SDK signatures into typed form fields, wires interactive coordinate,
 * region, color, OCR, Safari DOM, AX UI, and random-value pickers, and renders
 * the searchable `#hm_actions` accordion.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// SDK Signature Parsing, Hints & Default Values
// -----------------------------------------------------------------------------

/**
 * Parse only the first parenthesized parameter list from an SDK signature
 * string (`sig`), stripping trailing return-type (`-> {...}`) or description
 * annotations and preserving default values (`name=def`).
 */
function _helperParseArgs(sig) {
    const signature = (sig || '()').trim();
    const openingParenIndex = signature.indexOf('(');
    const closingParenIndex =
        openingParenIndex >= 0 ? signature.indexOf(')', openingParenIndex) : -1;
    const parameterList =
        openingParenIndex >= 0 && closingParenIndex > openingParenIndex
            ? signature.substring(openingParenIndex + 1, closingParenIndex).trim()
            : '';
    if (!parameterList) {
        return [];
    }
    return parameterList
        .split(',')
        .map((argument) => argument.trim())
        .filter((argument) => argument && argument !== 'self')
        .map((argument) => {
            const equalsIndex = argument.indexOf('=');
            const colonIndex = argument.indexOf(':');
            let name = argument;
            let def = '';
            if (equalsIndex >= 0) {
                name = argument.substring(0, equalsIndex).trim();
                def = argument.substring(equalsIndex + 1).trim();
            } else if (colonIndex >= 0) {
                name = argument.substring(0, colonIndex).trim();
            }
            if (name.includes(':')) {
                name = name.split(':')[0].trim();
            }
            return { name, def };
        });
}

/**
 * Return a localized placeholder hint string for an SDK parameter `argName`.
 */
function _helperHintFor(argName) {
    const normalizedName = (argName || '').toLowerCase();
    const key = {
        x: 'hintX',
        y: 'hintY',
        x1: 'hintX',
        y1: 'hintY',
        x2: 'hintX',
        y2: 'hintY',
        cx: 'hintX',
        cy: 'hintY',
        duration: 'hintDuration',
        swipe_duration: 'hintDuration',
        seconds: 'hintSeconds',
        timeout: 'hintTimeout',
        interval: 'hintInterval',
        delay_sec: 'hintDelaySec',
        delay: 'hintDelaySec',
        type: 'hintType',
        text: 'hintText',
        content: 'hintText',
        title: 'hintTitle',
        message: 'hintMessage',
        url: 'hintUrl',
        path: 'hintPath',
        file_path: 'hintPath',
        bundle_id: 'hintBundle',
        bundle_identifier: 'hintBundle',
        bundle: 'hintBundle',
        label: 'hintLabel',
        value: 'hintValue',
        command: 'hintCommand',
        width: 'hintSize',
        height: 'hintSize',
        finger: 'hintFinger',
        finger_index: 'hintFinger',
        match: 'hintMatch',
        accept: 'hintMatch',
    }[normalizedName];
    return key ? _t(key, '') : '';
}

/**
 * Resolve the initial default literal for `argName` on `method`, preferring an
 * explicit signature default (`def`) before method-specific and general fallbacks.
 */
function _helperDefaultFor(method, argName, def) {
    if (def) {
        return def;
    }
    const n = argName.toLowerCase();
    if (
        n === 'x' ||
        n === 'y' ||
        n === 'x1' ||
        n === 'y1' ||
        n === 'x2' ||
        n === 'y2' ||
        n === 'cx' ||
        n === 'cy'
    ) {
        return '0';
    }
    if (n === 'width' || n === 'height') {
        return '100';
    }
    if (n === 'duration' || n === 'swipe_duration') {
        return method.name === 'web_long_press' ? '10' : '0.3';
    }
    if (n === 'timeout') {
        return '10';
    }
    if (n === 'tolerance') {
        return '5';
    }
    if (n === 'scale' || n === 'scale_ratio') {
        return '0.8';
    }
    if (n === 'acceptable_value' || n === 'match' || n === 'accept') {
        return '0.9';
    }
    if (n === 'by' && method.name && method.name.indexOf('ax_') === 0) {
        return '"any"';
    }
    if (n === 'interval') {
        return '0.5';
    }
    if (n === 'delay_sec' || n === 'delay') {
        return '0.1';
    }
    if (n === 'max_swipes' || n === 'max_try_times' || n === 'max_tries') {
        return '10';
    }
    if (n === 'max_seconds') {
        return '2.0';
    }
    if (n === 'min_seconds') {
        return '0.5';
    }
    if (n === 'seconds') {
        return '1';
    }
    if (n === 'microseconds') {
        return '500000';
    }
    if (n === 'degrees') {
        return '90';
    }
    if (n === 'steps') {
        return '10';
    }
    if (n === 'distance') {
        return '200';
    }
    if (n === 'radius') {
        return '120';
    }
    if (n === 'finger_index' || n === 'finger') {
        return '1';
    }
    if (n === 'type') {
        return '1';
    }
    if (n === 'direction') {
        return '"up"';
    }
    if (n === 'recognition_level') {
        return '1';
    }
    if (n === 'contains' || n === 'word_match' || n === 'auto_correct') {
        return 'false';
    }
    if (n === 'languages') {
        return 'nil';
    }
    if (n === 'custom_words') {
        return '[]';
    }
    if (
        n === 'text' ||
        n === 'content' ||
        n === 'title' ||
        n === 'message' ||
        n === 'command' ||
        n === 'script_name'
    ) {
        if (method.name === 'safari_auto_click') {
            return '"Sign in"';
        }
        if (method.name && method.name.indexOf('ax_') === 0) {
            return '"Continue"';
        }
        return '""';
    }
    if (n === 'default') {
        return '""';
    }
    if (n === 'bundle_identifier' || n === 'bundle' || n === 'bundle_id') {
        return '"com.apple.mobilesafari"';
    }
    if (n === 'payload') {
        return '""';
    }
    if (n === 'url') {
        return '"https://example.com"';
    }
    if (
        n === 'path' ||
        n === 'script_path' ||
        n === 'script_absolute_path' ||
        n === 'file_path' ||
        n === 'in_path' ||
        n === 'out_path' ||
        n === 'save_path' ||
        n === 'image_path' ||
        n === 'debug_image_path'
    ) {
        return '"/tmp/file.txt"';
    }
    if (n === 'template_path') {
        return '"button"';
    }
    if (n === 'image_name') {
        return '"button"';
    }
    if (n === 'name' || n === 'version_dir') {
        return '""';
    }
    if (n === 'name_or_path' || n === 'name_or_index') {
        return '""';
    }
    if (n === 'region') {
        return '(0, 0, 750, 1334)';
    }
    if (n === 'region_or_path') {
        return 'nil';
    }
    if (n === 'min' || n === 'min_value') {
        return '0';
    }
    if (n === 'max' || n === 'max_value') {
        return '100';
    }
    if (n === 'red' || n === 'r') {
        return '255';
    }
    if (n === 'green' || n === 'g') {
        return '0';
    }
    if (n === 'blue' || n === 'b') {
        return '0';
    }
    if (n === 'host') {
        return '"127.0.0.1"';
    }
    if (n === 'port') {
        return '8080';
    }
    if (n === 'data') {
        return method.name === 'safari_auto_fill'
            ? '{"email": "user@example.com", "password": "Pass123"}'
            : '""';
    }
    if (n === 'value') {
        return method.name === 'web_fill' ? '"abc@gmail.com"' : '""';
    }
    if (n === 'label') {
        if (method.name === 'web_click') {
            return '"Next"';
        }
        if (method.name === 'web_long_press') {
            return '"Press and hold"';
        }
        if (
            method.name === 'web_wait' ||
            method.name === 'web_exists' ||
            method.name === 'web_text'
        ) {
            return '"Email"';
        }
        return '"Email"';
    }
    if (n === 'email') {
        return '"user@example.com"';
    }
    if (n === 'password') {
        return '"Pass123"';
    }
    if (n === 'username') {
        return '"myuser"';
    }
    if (n === 'selector') {
        return '"input[name=email]"';
    }
    if (n === 'form_selector') {
        return '"form"';
    }
    if (n === 'frame_selector') {
        return '"iframe"';
    }
    if (n === 'code') {
        return '"document.title"';
    }
    if (n === 'attr') {
        return '"href"';
    }
    if (n === 'pattern') {
        return '"dashboard"';
    }
    if (n === 'event_name') {
        return '"change"';
    }
    if (n === 'method') {
        return '"GET"';
    }
    if (n === 'body') {
        return 'nil';
    }
    if (n === 'days') {
        return '30';
    }
    if (n === 'key') {
        return '""';
    }
    if (n === 'params' || n === 'headers' || n === 'json') {
        return 'nil';
    }
    if (n === 'interval_seconds') {
        return '60';
    }
    if (n === 'fn') {
        return 'nil';
    }
    if (n === 'enable' || n === 'on') {
        return 'true';
    }
    if (n === 'options') {
        return '["A", "B", "C"]';
    }
    if (n === 'default') {
        return '""';
    }
    if (n === 'items') {
        return '{"Count": "0"}';
    }
    return '0';
}

/** Return `true` if `name` is a 2D point coordinate parameter (`x`, `y`, `x1`, etc.). */
function _helperIsCoordArg(name) {
    const n = name.toLowerCase();
    return ['x', 'y', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy'].includes(n);
}

/** Return `true` if `name` is a rectangular `region` parameter. */
function _helperIsRegionArg(name) {
    return name.toLowerCase() === 'region';
}

/** Return `true` if `name` is a `text` parameter eligible for OCR/AX/DOM/Random pickers. */
function _helperIsTextArg(name) {
    return name.toLowerCase() === 'text';
}

/** Return `true` if `name` is a hex color parameter (`bg`, `fg`, `color`, etc.). */
function _helperIsColorHexArg(name) {
    const n = name.toLowerCase();
    return n === 'bg' || n === 'fg' || n === 'color' || n === 'bg_color' || n === 'fg_color';
}

/**
 * Format an ALang call expression for `method` using the current `fields` map,
 * omitting trailing optional parameters whose values still match their defaults.
 */
function _helperGenCodeFromForm(method, fields) {
    const args = _helperParseArgs(method.sig);
    const vals = args.map((a) => {
        const userVal = fields[a.name];
        const hasUserVal = userVal !== undefined && userVal !== '';
        if (a.def) {
            return hasUserVal && userVal !== a.def ? userVal : a.def;
        }
        return hasUserVal ? userVal : _helperDefaultFor(method, a.name, '');
    });
    let lastNonDefault = -1;
    for (let i = 0; i < args.length; i++) {
        const a = args[i];
        if (!a.def || vals[i] !== a.def) {
            lastNonDefault = i;
        }
    }
    const parts = vals.slice(0, lastNonDefault + 1);
    return `${method.name}(${parts.join(', ')})`;
}

// -----------------------------------------------------------------------------
// Shared Helper Form Widgets & Escaping Utilities
// -----------------------------------------------------------------------------

/**
 * Render an expandable SDK method card inside a Helper category list.
 */
function _renderHelperMethodCard(method, container, ctx) {
    const rawDesc = (method.doc || '').split('\n')[0].slice(0, 80);
    const desc = _sdkDoc(method.name, rawDesc);

    const card = document.createElement('div');
    card.dataset.method = method.name;
    card.style.cssText = 'display:flex; flex-direction:column;';

    const btn = document.createElement('button');
    btn.className = 'hm-act';
    btn.innerHTML = `<b>${method.name}</b><span style="color:#888;font-size:10px;"> ${_displaySig(method.sig)}</span>`;
    if (desc) {
        btn.title = desc;
    }
    card.appendChild(btn);

    const panel = document.createElement('div');
    panel.style.cssText = 'display:none;';
    card.appendChild(panel);

    btn.addEventListener('click', () => {
        const isOpen = panel.style.display === 'block';
        container.querySelectorAll('.hm-act.active').forEach((b) => {
            b.classList.remove('active');
        });
        container.querySelectorAll('[data-method] > div').forEach((p) => {
            p.style.display = 'none';
        });
        if (isOpen) {
            state._helperOpenMethod = null;
            state._helperPickTarget = null;
            if (ctx.hint) {
                ctx.hint.style.display = 'none';
            }
            return;
        }
        btn.classList.add('active');
        panel.style.display = 'block';
        state._helperOpenMethod = { method, panel, fields: {} };
        _renderHelperMethodForm(method, panel, ctx);
    });

    container.appendChild(card);
}

/** Escape backslashes and double quotes for embedding inside an ALang string literal. */
function _hmEsc(value) {
    return String(value || '')
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"');
}

/** Wrap `value` as a double-quoted ALang string literal. */
function _hmAlangStr(value) {
    return `"${_hmEsc(value)}"`;
}

/** Create a Helper picker action button (`button.hm-pick`). */
function _hmPickBtn(text, title) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'hm-pick';
    button.textContent = text;
    if (title) {
        button.title = title;
    }
    return button;
}

/** Create a labeled text input row (`div.hm-row`) that invokes `onVal` on input. */
function _hmTextRow(label, ph, onVal) {
    const row = document.createElement('div');
    row.className = 'hm-row';
    const lbl = document.createElement('label');
    lbl.textContent = label;
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.placeholder = ph;
    inp.addEventListener('input', () => onVal(inp.value));
    row.appendChild(lbl);
    row.appendChild(inp);
    return row;
}

/** Create a color swatch + hex input + clear button row (`div.hm-row`). */
function _hmColorRow(label, defHex, onHex) {
    const row = document.createElement('div');
    row.className = 'hm-row';
    const lbl = document.createElement('label');
    lbl.textContent = label;
    const picker = document.createElement('input');
    picker.type = 'color';
    picker.className = 'hm-swatch';
    picker.value = defHex;
    const text = document.createElement('input');
    text.type = 'text';
    text.placeholder = '#RRGGBB';
    const clear = document.createElement('button');
    clear.type = 'button';
    clear.className = 'hm-clear';
    clear.textContent = '✕';
    clear.title = 'Xóa màu';
    picker.addEventListener('input', () => {
        text.value = picker.value.toUpperCase();
        onHex(text.value);
    });
    text.addEventListener('input', () => {
        onHex(text.value);
        if (/^#[0-9A-Fa-f]{6}$/.test(text.value)) {
            picker.value = text.value;
        }
    });
    clear.addEventListener('click', () => {
        text.value = '';
        onHex('');
    });
    row.appendChild(lbl);
    row.appendChild(picker);
    row.appendChild(text);
    row.appendChild(clear);
    return row;
}

/** Create a titled container block (`div.hm-colors`) for color picker rows. */
function _hmColorBlock(title) {
    const box = document.createElement('div');
    box.className = 'hm-colors';
    const h = document.createElement('div');
    h.className = 'hm-colors-title';
    h.textContent = title;
    box.appendChild(h);
    return box;
}

/**
 * Append the live ALang code preview (`div.hm-code`) and Copy / Insert action
 * buttons to `panel`.
 */
function _hmCodeFooter(panel, ctx, updateCode) {
    const codeWrap = document.createElement('div');
    codeWrap.className = 'hm-code';
    const codeEl = document.createElement('code');
    ctx.codeEl = codeEl;
    codeWrap.appendChild(codeEl);
    panel.appendChild(codeWrap);

    const btnRow = document.createElement('div');
    btnRow.className = 'hm-row-btns';

    const copyBtn = document.createElement('button');
    copyBtn.className = 'hm-btn-copy';
    copyBtn.textContent = _t('hmBtnCopy');
    copyBtn.addEventListener('click', () => {
        updateCode();
        _hmDoCopy(ctx.codeEl.textContent);
    });

    const insertBtn = document.createElement('button');
    insertBtn.className = 'hm-btn-insert';
    insertBtn.textContent = _t('hmBtnInsert');
    insertBtn.addEventListener('click', () => {
        updateCode();
        insertEditorText(ctx.codeEl.textContent);
    });

    btnRow.appendChild(copyBtn);
    btnRow.appendChild(insertBtn);
    panel.appendChild(btnRow);
    updateCode();
}

// -----------------------------------------------------------------------------
// Generic SDK Method Form Builder
// -----------------------------------------------------------------------------

/**
 * Build the parameter input form for `method` inside `panel`, delegating to
 * specialized dialog/Safari form builders when applicable and wiring coordinate,
 * region, color, crop, OCR, AX, DOM, and random-value pickers for generic methods.
 */
function _renderHelperMethodForm(method, panel, ctx) {
    const hint = ctx.hint;
    const args = _helperParseArgs(method.sig);
    const argNames = args.map((a) => a.name);
    const fields = {};
    panel.innerHTML = '';

    if (method.name === 'show_toast' || method.name === 'show_toast_ex') {
        _renderShowToastForm(panel, ctx);
        return;
    }
    if (method.name === 'web_long_press') {
        _renderWebLongPressForm(panel, ctx);
        return;
    }
    if (method.name === 'show_alert_box') {
        _renderShowAlertBoxForm(panel, ctx);
        return;
    }
    if (method.name === 'dialog_input' || method.name === 'dialog_input_styled') {
        _renderDialogInputForm(panel, ctx);
        return;
    }
    if (method.name === 'dialog_choice' || method.name === 'dialog_choice_styled') {
        _renderDialogChoiceForm(panel, ctx);
        return;
    }

    let firstXInput = null;
    let firstXArgName = null;

    const hasColorArgs =
        argNames.includes('red') && argNames.includes('green') && argNames.includes('blue');
    const isImgFn = method.name && /image/i.test(method.name);
    const imageArgName =
        ['template_path', 'image', 'template'].find((n) => argNames.includes(n)) ||
        (isImgFn && argNames.includes('path') ? 'path' : null);
    const regionGroup =
        argNames.includes('x') &&
        argNames.includes('y') &&
        argNames.includes('w') &&
        argNames.includes('h')
            ? { x: 'x', y: 'y', w: 'w', h: 'h' }
            : argNames.includes('rx') &&
                argNames.includes('ry') &&
                argNames.includes('rw') &&
                argNames.includes('rh')
              ? { x: 'rx', y: 'ry', w: 'rw', h: 'rh' }
              : null;
    const inputByName = {};

    if (args.length) {
        const form = document.createElement('div');
        form.className = 'hm-form';
        const advanced = document.createElement('div');
        advanced.style.cssText =
            'display:none; margin-top:6px; padding-top:6px; border-top:1px dashed rgba(255,255,255,0.08);';
        let pendingCoordWrap = null;

        args.forEach((a) => {
            const row = document.createElement('div');
            row.className = 'hm-row';
            const lbl = document.createElement('label');
            lbl.textContent = a.name;
            const inp = document.createElement('input');
            inp.type = 'text';
            inp.value = a.def || _helperDefaultFor(method, a.name, '');
            const _hint = _helperHintFor(a.name);
            if (_hint) {
                inp.placeholder = _hint;
            }
            fields[a.name] = inp.value;
            inp.addEventListener('input', () => {
                fields[a.name] = inp.value;
                updateCode();
            });
            row.appendChild(lbl);
            row.appendChild(inp);

            if (_helperIsColorHexArg(a.name)) {
                const picker = document.createElement('input');
                picker.type = 'color';
                picker.value = '#818cf8';
                picker.className = 'hm-swatch';
                picker.title = 'Chọn màu (xoá ô text để bỏ về mặc định)';
                picker.addEventListener('input', () => {
                    const hex = picker.value.toUpperCase();
                    const quoted = '"' + hex + '"';
                    inp.value = quoted;
                    fields[a.name] = quoted;
                    updateCode();
                });
                row.appendChild(picker);
            }

            if (method.name === 'show_toast' && a.name === 'type') {
                const colorRow = document.createElement('div');
                colorRow.style.cssText = 'display:flex; gap:4px; margin-top:4px; margin-left:94px;';
                const colors = [
                    { type: 1, color: '#e74c3c', label: 'Đỏ' },
                    { type: 2, color: '#f1c40f', label: 'Vàng' },
                    { type: 3, color: '#ffffff', label: 'Trắng' },
                    { type: 4, color: '#2ecc71', label: 'Xanh' },
                ];
                colors.forEach((c) => {
                    const btn = document.createElement('button');
                    btn.style.cssText = `width:28px; height:28px; background:${c.color}; border:2px solid ${c.type === 3 ? '#666' : c.color}; border-radius:6px; cursor:pointer;`;
                    btn.title = c.label + ' (type=' + c.type + ')';
                    btn.addEventListener('click', () => {
                        inp.value = c.type;
                        fields[a.name] = c.type;
                        updateCode();
                    });
                    colorRow.appendChild(btn);
                });
                row.appendChild(colorRow);
            }

            inp.dataset.arg = a.name;
            inputByName[a.name] = inp;

            if (pendingCoordWrap && a.name === pendingCoordWrap._expectY) {
                pendingCoordWrap._stack.appendChild(row);
                pendingCoordWrap = null;
                return;
            }

            const isXCoord = ['x', 'x1', 'x2', 'cx'].includes(a.name);
            const isRegionAnchor = regionGroup && regionGroup.x === a.name;
            if (isXCoord && _helperIsCoordArg(a.name) && !hasColorArgs && !isRegionAnchor) {
                const wrap = document.createElement('div');
                wrap.className = 'hm-coord';
                const stack = document.createElement('div');
                stack.className = 'hm-coord-stack';
                stack.appendChild(row);
                wrap.appendChild(stack);
                const pickBtn = _hmPickBtn('📍', _t('hmPickPointTooltip'));
                pickBtn.classList.add('hm-pick-icon');
                const startPick = () => {
                    state._helperPickTarget = { type: 'point', input: inp, fields, partner: null };
                    const partnerName = a.name.replace('x', 'y');
                    const partnerInput = inputByName[partnerName];
                    if (partnerInput) {
                        state._helperPickTarget.partner = partnerInput;
                    }
                    setHelperMode('single');
                    if (hint) {
                        hint.style.display = 'block';
                        hint.textContent = _t('hmPickPoint');
                    }
                };
                pickBtn.addEventListener('click', startPick);
                wrap.appendChild(pickBtn);
                wrap._stack = stack;
                wrap._expectY = a.name.replace('x', 'y');
                if ((a.name === 'x' || a.name === 'x1' || a.name === 'cx') && !firstXInput) {
                    firstXInput = inp;
                    firstXArgName = a.name;
                    wrap._autoStartPick = startPick;
                }
                pendingCoordWrap = wrap;
                (a.def !== '' && a.def != null ? advanced : form).appendChild(wrap);
                return;
            }

            if (_helperIsRegionArg(a.name)) {
                const pickBtn = _hmPickBtn(_t('hmBtnPickRegion'), _t('hmPickRegionTooltip'));
                const startRegionPick = () => {
                    state._helperPickTarget = { type: 'region', input: inp, fields };
                    setHelperMode('region');
                    state.regionStart = null;
                    if (hint) {
                        hint.style.display = 'block';
                        hint.textContent = _t('hmPickRegion');
                    }
                };
                pickBtn.addEventListener('click', startRegionPick);
                row.appendChild(pickBtn);
                if (!firstXInput) {
                    row._autoStartPick = startRegionPick;
                }
            }

            if (_helperIsTextArg(a.name)) {
                const KB_FNS = new Set(['type_keys', 'insert_text', 'paste_text', 'set_clipboard']);
                const isKeyboard = KB_FNS.has(method.name);
                const isSafariFn =
                    method.name &&
                    (method.name.indexOf('safari_') === 0 || method.name.indexOf('web_') === 0);
                const isAxFn = method.name && method.name.indexOf('ax_') === 0;
                const pickBtn = _hmPickBtn('', '');
                if (isKeyboard) {
                    pickBtn.textContent = _t('hmBtnRandom');
                    pickBtn.title = _t('hmBtnRandomTip');
                } else if (isSafariFn) {
                    pickBtn.textContent = _t('hmBtnDom');
                    pickBtn.title = _t('hmBtnDomTip');
                } else if (isAxFn) {
                    pickBtn.textContent = _t('hmBtnAx');
                    pickBtn.title = _t('hmBtnAxTip');
                } else {
                    pickBtn.textContent = _t('hmBtnOcr');
                    pickBtn.title = _t('hmBtnOcrTip');
                }
                pickBtn.addEventListener('click', () => {
                    if (isKeyboard) {
                        helperPickRandomList(inp, fields, a.name, updateCode);
                    } else if (isSafariFn) {
                        helperPickFromSafariDOM(inp, fields, a.name, updateCode, 'text');
                    } else if (isAxFn) {
                        helperPickFromAX(inp, fields, a.name, updateCode, inputByName.by);
                    } else {
                        helperPickTextFromOcr(inp, fields, a.name, updateCode);
                    }
                });
                row.appendChild(pickBtn);
            }

            if (a.name === 'match' && method.name && method.name.indexOf('ax_') === 0) {
                // Legacy catalog entries may still use parameter name `match` on `ax_*` methods; attach the AX UI scanner button.
                const pickBtn = _hmPickBtn(_t('hmBtnAx'), _t('hmBtnAxTip'));
                pickBtn.addEventListener('click', () =>
                    helperPickFromAX(inp, fields, a.name, updateCode, inputByName.by),
                );
                row.appendChild(pickBtn);
            }

            if (a.name === 'selector' || a.name === 'form_selector') {
                const pickBtn = _hmPickBtn(_t('hmBtnDom'), _t('hmBtnDomTip'));
                pickBtn.addEventListener('click', () =>
                    helperPickFromSafariDOM(inp, fields, a.name, updateCode, 'sel'),
                );
                row.appendChild(pickBtn);
            }

            if (a.name === 'value' && method.name === 'web_fill') {
                const pickBtn = _hmPickBtn(_t('hmBtnRandom'), _t('hmBtnRandomTip'));
                pickBtn.addEventListener('click', () =>
                    helperPickRandomList(inp, fields, a.name, updateCode),
                );
                row.appendChild(pickBtn);
            }

            if (a.name === 'label' && method.name && method.name.indexOf('web_') === 0) {
                const pickBtn = _hmPickBtn(_t('hmBtnDom'), _t('hmBtnDomTip'));
                pickBtn.addEventListener('click', () =>
                    helperPickFromSafariDOM(inp, fields, a.name, updateCode, 'text'),
                );
                row.appendChild(pickBtn);
            }

            if (imageArgName && a.name === imageArgName) {
                const cropBtn = _hmPickBtn(_t('hmBtnCrop'), _t('hmBtnCropTip'));
                const startImageCrop = () => {
                    state._helperPickTarget = { type: 'image_crop', input: inp, fields };
                    setHelperMode('region');
                    state.regionStart = null;
                    if (hint) {
                        hint.style.display = 'block';
                        hint.textContent = '✂️ Kéo chọn vùng ảnh — sẽ lưu PNG vào thư mục images';
                    }
                };
                cropBtn.addEventListener('click', startImageCrop);
                row.appendChild(cropBtn);
            }

            if (regionGroup && a.name === regionGroup.x) {
                const regBtn = _hmPickBtn(_t('hmBtnPickRegion'), _t('hmPickRegionTooltip'));
                const startRegionPick4 = () => {
                    state._helperPickTarget = {
                        type: 'region_4inputs',
                        fields,
                        xInput: inputByName[regionGroup.x],
                        yInput: inputByName[regionGroup.y],
                        wInput: inputByName[regionGroup.w],
                        hInput: inputByName[regionGroup.h],
                    };
                    setHelperMode('region');
                    state.regionStart = null;
                    if (hint) {
                        hint.style.display = 'block';
                        hint.textContent = '📍 Kéo chọn vùng trên màn hình';
                    }
                };
                regBtn.addEventListener('click', startRegionPick4);
                row.appendChild(regBtn);
            }

            const forceMain = regionGroup && a.name === regionGroup.x;
            (!forceMain && a.def !== '' && a.def != null ? advanced : form).appendChild(row);
        });

        let priorityAuto = null;

        if (hasColorArgs) {
            const startColorPick = () => {
                state._helperPickTarget = {
                    type: 'color',
                    fields,
                    rInput: inputByName['red'],
                    gInput: inputByName['green'],
                    bInput: inputByName['blue'],
                    xInput: inputByName['x'],
                    yInput: inputByName['y'],
                };
                setHelperMode('single');
                if (hint) {
                    hint.style.display = 'block';
                    hint.textContent = '🎨 Click 1 điểm trên ảnh để lấy màu';
                }
            };
            const colorRow = document.createElement('div');
            const colorBtn = _hmPickBtn(_t('hmBtnPickColor'));
            colorBtn.classList.add('hm-pick-block');
            colorBtn.addEventListener('click', startColorPick);
            colorRow.appendChild(colorBtn);
            form.appendChild(colorRow);
            if (!priorityAuto) {
                priorityAuto = startColorPick;
            }
        }

        panel.appendChild(form);

        if (advanced.children.length) {
            const toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.className = 'hm-adv-toggle';
            toggle.innerHTML = `<span class="hm-adv-arrow">▸</span> Tuỳ chọn nâng cao (${advanced.children.length})`;
            toggle.addEventListener('click', () => {
                const open = advanced.style.display !== 'none';
                advanced.style.display = open ? 'none' : 'block';
                toggle.querySelector('.hm-adv-arrow').textContent = open ? '▸' : '▾';
            });
            panel.appendChild(toggle);
            panel.appendChild(advanced);
        }

        const autoTrigger =
            priorityAuto ||
            (Array.from(form.children).find((r) => r._autoStartPick) || {})._autoStartPick;
        if (autoTrigger) {
            setTimeout(autoTrigger, 50);
        }
    }

    function updateCode() {
        if (ctx.codeEl) {
            ctx.codeEl.textContent = _helperGenCodeFromForm(method, fields);
        }
    }
    _hmCodeFooter(panel, ctx, updateCode);

    if (state._helperOpenMethod) {
        state._helperOpenMethod.fields = fields;
        state._helperOpenMethod.updateCode = updateCode;
    }
}

// -----------------------------------------------------------------------------
// Helper SDK Category Accordion & Search
// -----------------------------------------------------------------------------

/**
 * Initialize the Helper Functions accordion (`#hm_actions`) and live search
 * filter (`#hm_search`), exposing `window._buildHelperAccordion` for catalog
 * and language updates.
 */
function _initHelperAccordion(ctx) {
    function buildHelperAccordion() {
        const container = document.getElementById('hm_actions');
        if (!container) {
            return;
        }
        const methods = window._sdkMethods || [];
        if (!methods.length) {
            container.innerHTML = `<div style="color:#888;text-align:center;padding:20px;">${_t('hmLoadingSdk')}</div>`;
            setTimeout(buildHelperAccordion, 500);
            return;
        }
        const CAT_LABELS = {
            Touch: _t('catTouch'),
            Keyboard: _t('catKeyboard'),
            Clipboard: _t('catClipboard'),
            Color: _t('catColor'),
            Image: _t('catImage'),
            VCam: _t('catVCam'),
            OCR: _t('catOCR'),
            System: _t('catSystem'),
            App: _t('catApp'),
            File: _t('catFile'),
            Network: _t('catNetwork'),
            Sleep: _t('catSleep'),
            UI: _t('catUI'),
            Recording: _t('catRecording'),
            Script: _t('catScript'),
            Safari: _t('catSafari'),
            Lang: _t('catLang'),
        };
        const cats = window._helperCATS || [];
        container.innerHTML = '';
        const methodMap = {};
        methods.forEach((m) => {
            methodMap[m.name] = m;
        });

        Object.entries(window._helperCATMAP || {}).forEach(([key, def]) => {
            const cat = document.createElement('div');
            cat.className = 'hm-cat';
            const header = document.createElement('div');
            header.className = 'hm-cat-h';
            const list = (def.names || []).filter((n) => methodMap[n]);
            if (!list.length) {
                return;
            }
            header.innerHTML = `<span>${CAT_LABELS[key] || key} <span style="color:#666;font-weight:normal;">(${list.length})</span></span><span class="chev">▸</span>`;
            header.addEventListener('click', () => cat.classList.toggle('open'));
            cat.appendChild(header);
            const listDiv = document.createElement('div');
            listDiv.className = 'hm-cat-list';
            list.forEach((n) => _renderHelperMethodCard(methodMap[n], listDiv, ctx));
            cat.appendChild(listDiv);
            container.appendChild(cat);
        });

        const search = document.getElementById('hm_search');
        if (search) {
            search.placeholder = _t('hmSearchPlaceholder');
            search.addEventListener('input', () => {
                const q = search.value.toLowerCase().trim();
                container.querySelectorAll('.hm-cat').forEach((cat) => {
                    let any = false;
                    cat.querySelectorAll('[data-method]').forEach((card) => {
                        const match = !q || card.dataset.method.toLowerCase().includes(q);
                        card.style.display = match ? '' : 'none';
                        if (match) {
                            any = true;
                        }
                    });
                    cat.style.display = any ? '' : 'none';
                    if (q && any) {
                        cat.classList.add('open');
                    }
                });
            });
        }
    }

    window._buildHelperAccordion = buildHelperAccordion;
}
