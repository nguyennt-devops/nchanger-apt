/**
 * @file script.runner.js — Script execution, daemon running-state checks,
 * stop requests, and `.aios` script encryption modal.
 *
 * Communicates with `/api/scripts/state`, `/api/scripts/run`,
 * `/api/scripts/stop`, `/api/scripts/save`, and `/api/scripts/encrypt`.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Daemon Running-State Check
// -----------------------------------------------------------------------------

/**
 * Query `/api/scripts/state` on startup to detect if a script is already
 * running on the daemon (e.g., started from the on-device Quick Panel) and
 * synchronize the Run/Stop button state.
 */
async function checkRunningScript() {
    try {
        const res = await fetch(`${API}/api/scripts/state?since=999999999`);
        const data = await res.json();
        if (data.running) {
            state.runningTaskId = data.taskId || '__quickpanel__';
            state.runningFileName = data.scriptName || null;
            state.lastLogIndex = 0;
            setRunButtonsState(true);
            const source = data.source === 'quickpanel' ? ' (Quick Panel)' : '';
            appendLog(
                _l(
                    `🔄 Script "${data.scriptName || 'unknown'}" is running${source}`,
                    `🔄 Script "${data.scriptName || 'unknown'}" đang chạy${source}`,
                ),
            );
        }
    } catch (e) {
        // Ignore transient startup network errors; periodic state polling will retry.
    }
}

// -----------------------------------------------------------------------------
// Script Execution & Cancellation
// -----------------------------------------------------------------------------

/**
 * Execute the active editor buffer on the connected device.
 * Automatically saves dirty named files before running, or prompts for a file
 * name when the active buffer has not yet been saved.
 */
async function runScript() {
    if (!_beginRunRequest()) {
        return;
    }
    try {
        if (state.runningTaskId) {
            try {
                const chk = await fetch(`${API}/api/scripts/state?since=999999999`);
                const cs = await chk.json();
                if (!cs.running) {
                    state.runningTaskId = null;
                    state.runningFileName = null;
                } else {
                    appendLog(
                        _l(
                            `⚠️ Script "${state.runningFileName || 'unknown'}" is still running. Stop it first!`,
                            `⚠️ Script "${state.runningFileName || 'unknown'}" vẫn đang chạy. Dừng trước đã!`,
                        ),
                        'error',
                    );
                    return;
                }
            } catch (_) {
                state.runningTaskId = null;
            }
        }

        const code = getEditorValue();
        if (!code.trim()) {
            appendLog(_l('⚠️ No code to run', '⚠️ Không có code để chạy'), 'error');
            return;
        }

        if (typeof toggleConsolePanel === 'function') {
            toggleConsolePanel(true);
        }

        const helperModal = document.getElementById('helperModal');
        state._panelStateBeforeRun = {
            helperWasOpen: helperModal && helperModal.classList.contains('helper-open'),
        };

        if (state._dirty) {
            if (state.currentFileName) {
                try {
                    const res = await fetch(`${API}/api/scripts/save`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ name: state.currentFileName, code }),
                    });
                    const data = await res.json();
                    if (res.ok && data.success) {
                        state._dirty = false;
                        appendLog(
                            _l(
                                `💾 Auto-saved: ${state.currentFileName}`,
                                `💾 Tự lưu: ${state.currentFileName}`,
                            ),
                            'success',
                        );
                    } else {
                        appendLog(
                            '❌ Auto-save failed: ' + (data.error || `HTTP ${res.status}`),
                            'error',
                        );
                        return;
                    }
                } catch (e) {
                    appendLog('⚠️ Auto-save failed: ' + e.message, 'warn');
                    return;
                }
            } else {
                state._runAfterSave = true;
                document.getElementById('saveModal').classList.add('visible');
                const inp = document.getElementById('scriptNameInput');
                if (!inp.value) {
                    inp.value = generateScriptName();
                }
                setTimeout(() => {
                    inp.focus();
                    inp.select();
                }, 100);
                appendLog('💾 Đặt tên file trước khi chạy...', 'info');
                return;
            }
        }

        const udid = state.currentDevice || 'local';

        try {
            const isEnc = state.currentFileName && state.currentFileName.endsWith('.aios');
            const bodyObj = isEnc
                ? { udid, scriptName: state.currentFileName }
                : { code: code, udid, scriptName: state.currentFileName || '' };

            const res = await fetch(`${API}/api/scripts/run`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bodyObj),
            });
            const data = await res.json();

            if (data.success) {
                state.runningTaskId = data.taskId;
                state.lastLogIndex = 0;
                state.runningFileName = state.currentFileName || null;

                setRunButtonsState(true);

                appendLog(
                    _l(
                        `▶️ Script started (task: ${data.taskId})`,
                        `▶️ Đã chạy script (task: ${data.taskId})`,
                    ),
                );

                loadScriptFiles();
            } else {
                const errMsg = data.detail || data.error || 'Failed to start';
                appendLog('❌ ' + errMsg, 'error');
                if (/license|premium|hết hạn|expir|cooldown|kích hoạt/i.test(errMsg)) {
                    if (!state._licenseExpiredShown) {
                        state._licenseExpiredShown = true;
                        if (typeof showToast === 'function') {
                            showToast(
                                _l(
                                    'Premium expired — open app to renew',
                                    'Premium hết hạn — mở app gia hạn',
                                ),
                                'error',
                            );
                        }
                    }
                }
            }
        } catch (e) {
            appendLog('❌ ' + e.message, 'error');
        }
    } finally {
        _endRunRequest();
    }
}

/**
 * Load a saved script (`fileName`) from the device into an editor tab and
 * execute it immediately via `/api/scripts/run`.
 */
async function runFileScript(fileName) {
    if (!_beginRunRequest()) {
        return;
    }
    try {
        if (state.runningTaskId) {
            appendLog(
                _l(
                    `⚠️ Script "${state.runningFileName || 'unknown'}" is still running. Stop it first!`,
                    `⚠️ Script "${state.runningFileName || 'unknown'}" vẫn đang chạy. Dừng trước đã!`,
                ),
                'error',
            );
            return;
        }

        if (typeof toggleConsolePanel === 'function') {
            toggleConsolePanel(true);
        }

        try {
            const isEnc = fileName.endsWith('.aios');
            const res = await fetch(`${API}/api/scripts/load?name=${encodeURIComponent(fileName)}`);
            const data = await res.json();
            if (!data.success) {
                appendLog(`❌ Failed to load ${fileName}`, 'error');
                return;
            }
            if (!openTab(fileName, data.code, data.encrypted)) {
                return;
            }
            document.getElementById('scriptNameInput').value = fileName;

            const udid = state.currentDevice || 'local';
            const bodyObj = isEnc
                ? { udid, scriptName: fileName }
                : { code: data.code, udid, scriptName: fileName };

            const runRes = await fetch(`${API}/api/scripts/run`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bodyObj),
            });
            const runData = await runRes.json();
            if (runData.success) {
                state.runningTaskId = runData.taskId;
                state.runningFileName = fileName;
                state.lastLogIndex = 0;
                setRunButtonsState(true);
                appendLog(
                    _l(
                        `▶️ Running: ${fileName} (task: ${runData.taskId})`,
                        `▶️ Đang chạy: ${fileName} (task: ${runData.taskId})`,
                    ),
                );
                loadScriptFiles();
            } else {
                appendLog('❌ ' + (runData.detail || runData.error || 'Failed to start'), 'error');
            }
        } catch (e) {
            appendLog('❌ ' + e.message, 'error');
        }
    } finally {
        _endRunRequest();
    }
}

/**
 * Request script cancellation via `/api/scripts/stop`.
 * Places the Run/Stop button in `'pending'` mode until the `/api/scripts/state`
 * polling loop confirms the daemon has terminated the task, preventing UI flicker.
 */
async function stopScript() {
    const taskId = state.runningTaskId;
    setRunButtonsState('pending');
    if (state._panelStateBeforeRun) {
        if (state._panelStateBeforeRun.helperWasOpen) {
            if (typeof window._openHelperPanel === 'function') {
                window._openHelperPanel();
            } else {
                document.getElementById('helperToggleBtn')?.click();
            }
        }
        state._panelStateBeforeRun = null;
    }
    try {
        const res = await fetch(`${API}/api/scripts/stop`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ taskId: taskId }),
        });
        const data = await res.json();
        if (!res.ok || data.ok === false || data.success === false) {
            throw new Error(data.detail || data.error || `HTTP ${res.status}`);
        }
        appendLog(_l('⏹️ Stop requested;', '⏹️ Đã gửi yêu cầu dừng; đang chờ trạng thái thiết bị'));
    } catch (e) {
        appendLog('❌ ' + e.message, 'error');
        setRunButtonsState(state.runningTaskId ? 'running' : 'idle');
    }
}

/**
 * Shared script execution helper used by the console quick-command bar.
 * Preserves the single-request admission gate and license-expiry notification.
 */
async function _runScriptUnified(bodyObj) {
    if (!_beginRunRequest()) {
        return { ok: false, error: 'Run request already pending' };
    }
    try {
        const res = await fetch(`${API}/api/scripts/run`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyObj),
        });
        const data = await res.json();
        if (data.success) {
            return { ok: true, taskId: data.taskId, data };
        }
        const errMsg = data.detail || data.error || 'Failed to start';
        appendLog('❌ ' + errMsg, 'error');
        if (/license|premium|hết hạn|expir|cooldown|kích hoạt/i.test(errMsg)) {
            if (!state._licenseExpiredShown) {
                state._licenseExpiredShown = true;
                if (typeof showToast === 'function') {
                    showToast(
                        _l(
                            'Premium expired — open app to renew',
                            'Premium hết hạn — mở app gia hạn',
                        ),
                        'error',
                    );
                }
            }
        }
        return { ok: false, error: data.error || errMsg, data };
    } catch (e) {
        appendLog('❌ ' + e.message, 'error');
        return { ok: false, error: e.message };
    } finally {
        _endRunRequest();
    }
}

// -----------------------------------------------------------------------------
// Script Encryption (.a -> .aios)
// -----------------------------------------------------------------------------

/**
 * Open the confirmation modal (`#encryptModal`) and encrypt a plain `.a` script
 * into a redistributable `.aios` package via `/api/scripts/encrypt`.
 */
async function encrypt_script(fileName) {
    if (!fileName) {
        fileName = state.currentFileName;
    }
    if (!fileName || !fileName.endsWith('.a')) {
        appendLog('⚠️ Can only encrypt .a files', 'error');
        return;
    }

    document.getElementById('encryptFileName').textContent = fileName;
    document.getElementById('encryptModal').classList.add('visible');

    return new Promise((resolve) => {
        const btn = document.getElementById('confirmEncryptBtn');
        const modal = document.getElementById('encryptModal');
        let cleanup = null;

        const handler = async () => {
            if (cleanup) {
                cleanup();
            }
            modal.classList.remove('visible');
            try {
                const res = await fetch(`${API}/api/scripts/encrypt`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: fileName }),
                });
                const data = await res.json();
                if (data.success) {
                    appendLog(
                        _l(
                            `🔒 Encrypted: ${fileName} → ${data.name}`,
                            `🔒 Đã mã hoá: ${fileName} → ${data.name}`,
                        ),
                        'success',
                    );
                    loadScriptFiles();
                } else {
                    appendLog(
                        '❌ ' +
                            _l('Encrypt failed: ', 'Mã hoá lỗi: ') +
                            (data.error || 'Unknown error'),
                        'error',
                    );
                }
            } catch (e) {
                appendLog('❌ ' + _l('Encrypt failed: ', 'Mã hoá lỗi: ') + e.message, 'error');
            }
            resolve();
        };

        const cancel = () => {
            if (cleanup) {
                cleanup();
            }
            modal.classList.remove('visible');
            resolve();
        };

        const onOverlay = (e) => {
            if (e.target === modal) {
                cancel();
            }
        };

        const onEsc = (e) => {
            if (e.key === 'Escape' && modal.classList.contains('visible')) {
                cancel();
            }
        };

        const closeX = modal.querySelector('.modal-close, [data-modal-close]');
        cleanup = () => {
            btn.removeEventListener('click', handler);
            modal.removeEventListener('click', onOverlay);
            document.removeEventListener('keydown', onEsc);
            if (closeX) {
                closeX.removeEventListener('click', cancel);
            }
        };

        btn.addEventListener('click', handler);
        modal.addEventListener('click', onOverlay);
        document.addEventListener('keydown', onEsc);
        if (closeX) {
            closeX.addEventListener('click', cancel);
        }
    });
}

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.encrypt_script = encrypt_script;
