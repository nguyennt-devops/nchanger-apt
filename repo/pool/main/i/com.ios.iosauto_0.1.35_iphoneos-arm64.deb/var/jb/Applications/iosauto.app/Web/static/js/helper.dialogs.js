/**
 * @file helper.dialogs.js — Specialized Helper form builders for Alert Box,
 * Input Dialog, Choice Dialog, Toast notification, and Safari Long Press.
 *
 * Generates ALang calls (`show_alert_box`, `dialog_input`,
 * `dialog_input_styled`, `dialog_choice`, `dialog_choice_styled`, `show_toast`,
 * `show_toast_ex`, and `web_long_press`) with live code preview and color pickers.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Alert, Dialog & Toast Form Builders
// -----------------------------------------------------------------------------

/**
 * Render the custom Helper form for `show_alert_box(title, content, duration, bg?, fg?)`.
 */
function _renderShowAlertBoxForm(panel, ctx) {
    const state = { title: '', content: '', duration: 5, bg: '', fg: '' };
    function updateCode() {
        const t = _hmEsc(state.title);
        const c = _hmEsc(state.content);
        let code = `show_alert_box("${t}", "${c}", ${state.duration}`;
        if (state.bg || state.fg) {
            code += `, "${_hmEsc(state.bg)}", "${_hmEsc(state.fg)}"`;
        }
        code += ')';
        if (ctx.codeEl) {
            ctx.codeEl.textContent = code;
        }
    }

    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form hm-run-frame';
    form.appendChild(
        _hmTextRow(_t('hmTitle') || 'Tiêu đề', 'hello', (v) => {
            state.title = v;
            updateCode();
        }),
    );
    form.appendChild(
        _hmTextRow(_t('hmContent'), 'hi', (v) => {
            state.content = v;
            updateCode();
        }),
    );

    const durRow = _hmTextRow(_t('hmDuration'), '5', (v) => {
        state.duration = parseFloat(v) || 5;
        updateCode();
    });
    durRow.querySelector('input').type = 'number';
    durRow.querySelector('input').value = '5';
    form.appendChild(durRow);

    const colors = _hmColorBlock(_t('hmColor'));
    colors.appendChild(
        _hmColorRow(_t('hmBg'), '#262626', (v) => {
            state.bg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmFg'), '#ffffff', (v) => {
            state.fg = v;
            updateCode();
        }),
    );
    form.appendChild(colors);
    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
}

/**
 * Render the custom Helper form for `dialog_input` / `dialog_input_styled`.
 */
function _renderDialogInputForm(panel, ctx) {
    const state = { title: '', message: '', defaultText: '', bg: '', fg: '', btnBg: '', btnFg: '' };
    function updateCode() {
        let code;
        if (state.bg || state.fg || state.btnBg || state.btnFg) {
            const obj = { title: state.title };
            if (state.message) {
                obj.message = state.message;
            }
            if (state.defaultText) {
                obj.default = state.defaultText;
            }
            if (state.bg) {
                obj.bg = state.bg;
            }
            if (state.fg) {
                obj.fg = state.fg;
            }
            if (state.btnBg) {
                obj.btn_bg = state.btnBg;
            }
            if (state.btnFg) {
                obj.btn_fg = state.btnFg;
            }
            code = `dialog_input_styled(${_hmAlangStr(JSON.stringify(obj))})`;
        } else {
            code = `dialog_input("${_hmEsc(state.title)}", "${_hmEsc(state.message)}", "${_hmEsc(state.defaultText)}")`;
        }
        if (ctx.codeEl) {
            ctx.codeEl.textContent = code;
        }
    }

    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form hm-run-frame';
    form.appendChild(
        _hmTextRow(_t('hmTitle') || 'Tiêu đề', 'Tiêu đề', (v) => {
            state.title = v;
            updateCode();
        }),
    );
    form.appendChild(
        _hmTextRow(_t('hmContent'), 'Mô tả', (v) => {
            state.message = v;
            updateCode();
        }),
    );
    form.appendChild(
        _hmTextRow(_t('hmDefault') || 'Mặc định', '', (v) => {
            state.defaultText = v;
            updateCode();
        }),
    );

    const colors = _hmColorBlock(_t('hmColor'));
    colors.appendChild(
        _hmColorRow(_t('hmBg'), '#262626', (v) => {
            state.bg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmFg'), '#ffffff', (v) => {
            state.fg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmBtnBg') || 'Nút nền', '#3498db', (v) => {
            state.btnBg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmBtnFg') || 'Nút chữ', '#ffffff', (v) => {
            state.btnFg = v;
            updateCode();
        }),
    );
    form.appendChild(colors);
    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
}

/**
 * Render the custom Helper form for `dialog_choice` / `dialog_choice_styled`.
 */
function _renderDialogChoiceForm(panel, ctx) {
    const state = { title: '', options: 'Có, Không', bg: '', fg: '', btnBg: '', btnFg: '' };
    function opts() {
        return state.options
            .split(/[,|\n]/)
            .map((s) => s.trim())
            .filter(Boolean);
    }
    function updateCode() {
        const list = opts();
        let code;
        if (state.bg || state.fg || state.btnBg || state.btnFg) {
            const buttons = list.map((label) => ({
                label,
                value: label,
                bg: state.btnBg || '#3498db',
                fg: state.btnFg || '#ffffff',
            }));
            const obj = { title: state.title, buttons };
            if (state.bg) {
                obj.bg = state.bg;
            }
            if (state.fg) {
                obj.fg = state.fg;
            }
            code = `dialog_choice_styled(${_hmAlangStr(JSON.stringify(obj))})`;
        } else {
            code = `dialog_choice("${_hmEsc(state.title)}", [${list.map((o) => `"${_hmEsc(o)}"`).join(', ')}])`;
        }
        if (ctx.codeEl) {
            ctx.codeEl.textContent = code;
        }
    }

    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form hm-run-frame';
    form.appendChild(
        _hmTextRow(_t('hmTitle') || 'Tiêu đề', 'Chọn', (v) => {
            state.title = v;
            updateCode();
        }),
    );
    form.appendChild(
        _hmTextRow(_t('hmButtons') || 'Nút', 'Có, Không', (v) => {
            state.options = v;
            updateCode();
        }),
    );

    const colors = _hmColorBlock(_t('hmColor'));
    colors.appendChild(
        _hmColorRow(_t('hmBg'), '#262626', (v) => {
            state.bg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmFg'), '#ffffff', (v) => {
            state.fg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmBtnBg') || 'Nút nền', '#3498db', (v) => {
            state.btnBg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmBtnFg') || 'Nút chữ', '#ffffff', (v) => {
            state.btnFg = v;
            updateCode();
        }),
    );
    form.appendChild(colors);
    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
}

/**
 * Render the custom Helper form for `show_toast` / `show_toast_ex`.
 */
function _renderShowToastForm(panel, ctx) {
    const state = { content: '', duration: 2, bg: '', fg: '' };
    function updateCode() {
        const c = _hmEsc(state.content);
        let code;
        if (state.bg || state.fg) {
            code = `show_toast_ex("${c}", ${state.duration}, 3, 0, "${_hmEsc(state.bg)}", "${_hmEsc(state.fg)}")`;
        } else {
            code = `show_toast("${c}", ${state.duration})`;
        }
        if (ctx.codeEl) {
            ctx.codeEl.textContent = code;
        }
    }

    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form hm-run-frame';
    form.appendChild(
        _hmTextRow(_t('hmContent'), _t('hmToastPh'), (v) => {
            state.content = v;
            updateCode();
        }),
    );

    const durRow = _hmTextRow(_t('hmDuration'), '2', (v) => {
        state.duration = parseFloat(v) || 2;
        updateCode();
    });
    durRow.querySelector('input').type = 'number';
    durRow.querySelector('input').value = '2';
    form.appendChild(durRow);

    const colors = _hmColorBlock(_t('hmColor'));
    colors.appendChild(
        _hmColorRow(_t('hmBg'), '#3498db', (v) => {
            state.bg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmFg'), '#ffffff', (v) => {
            state.fg = v;
            updateCode();
        }),
    );
    form.appendChild(colors);
    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
}

// -----------------------------------------------------------------------------
// Safari Long Press Form Builder
// -----------------------------------------------------------------------------

/**
 * Render the custom Helper form for `web_long_press`, supporting both fixed
 * hold duration (in seconds) and `"gone"` mode (hold until the element disappears).
 */
function _renderWebLongPressForm(panel, ctx) {
    const fields = { label: '"Press and hold"', duration_or_gone: '10', timeout: '20' };
    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form';

    const labelRow = document.createElement('div');
    labelRow.className = 'hm-row';
    const labelTitle = document.createElement('label');
    labelTitle.textContent = 'label';
    const labelInput = document.createElement('input');
    labelInput.type = 'text';
    labelInput.value = fields.label;
    labelInput.addEventListener('input', () => {
        fields.label = labelInput.value;
        updateCode();
    });
    const scanButton = _hmPickBtn(_t('hmBtnDom'), _t('hmBtnDomTip'));
    scanButton.addEventListener('click', () =>
        helperPickFromSafariDOM(labelInput, fields, 'label', updateCode, 'text'),
    );
    labelRow.appendChild(labelTitle);
    labelRow.appendChild(labelInput);
    labelRow.appendChild(scanButton);
    form.appendChild(labelRow);

    const modeRow = document.createElement('div');
    modeRow.className = 'hm-row';
    const modeTitle = document.createElement('label');
    modeTitle.textContent = _l('Hold mode', 'Chế độ giữ', '长按方式');
    const modeSelect = document.createElement('select');
    [
        ['seconds', _l('Hold for seconds', 'Giữ theo số giây', '按指定秒数')],
        ['gone', _l('Hold until button disappears', 'Giữ đến khi nút biến mất', '按到按钮消失')],
    ].forEach(([value, text]) => {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = text;
        modeSelect.appendChild(option);
    });
    modeRow.appendChild(modeTitle);
    modeRow.appendChild(modeSelect);
    form.appendChild(modeRow);

    const secondsRow = _hmTextRow(_l('Seconds', 'Số giây', '秒数'), '10', (value) => {
        fields.duration_or_gone = value || '10';
        updateCode();
    });
    const secondsInput = secondsRow.querySelector('input');
    secondsInput.type = 'number';
    secondsInput.min = '0.1';
    secondsInput.step = '0.1';
    secondsInput.value = '10';
    form.appendChild(secondsRow);

    const timeoutRow = _hmTextRow(_l('Max wait', 'Chờ tối đa', '最长等待'), '20', (value) => {
        fields.timeout = value || '20';
        updateCode();
    });
    const timeoutInput = timeoutRow.querySelector('input');
    timeoutInput.type = 'number';
    timeoutInput.min = '0.1';
    timeoutInput.step = '0.1';
    timeoutInput.value = '20';
    timeoutRow.style.display = 'none';
    form.appendChild(timeoutRow);

    modeSelect.addEventListener('change', () => {
        const gone = modeSelect.value === 'gone';
        secondsRow.style.display = gone ? 'none' : 'flex';
        timeoutRow.style.display = gone ? 'flex' : 'none';
        fields.duration_or_gone = gone ? '"gone"' : secondsInput.value || '10';
        updateCode();
    });

    function updateCode() {
        if (!ctx.codeEl) {
            return;
        }
        ctx.codeEl.textContent =
            modeSelect.value === 'gone'
                ? `web_long_press(${fields.label || '""'}, "gone", ${fields.timeout || '20'})`
                : `web_long_press(${fields.label || '""'}, ${fields.duration_or_gone || '10'})`;
    }

    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
    if (state._helperOpenMethod) {
        state._helperOpenMethod.fields = fields;
        state._helperOpenMethod.updateCode = updateCode;
    }
}
