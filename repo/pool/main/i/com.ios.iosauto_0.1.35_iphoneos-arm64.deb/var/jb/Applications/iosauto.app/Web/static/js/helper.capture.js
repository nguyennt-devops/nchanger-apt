/**
 * @file helper.capture.js — Helper panel layout/resizer, screenshot capture,
 * interactive pixel/region/color picker, and Helper panel navigation.
 *
 * Coordinates the screenshot overlay (`#helperScreenOverlay`), 2D pixel
 * readback canvas (`#helperScreenCanvas`), region selection box, and automatic
 * form field population when picking points, regions, colors, or cropped images.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Helper Panel Edge Resizer & Toggle
// -----------------------------------------------------------------------------

/**
 * Initialize horizontal drag-resizing on `#helperEdgeResizer` for the Helper
 * side panel (`#helperModal`) and synchronize its visibility class.
 */
function initHelperEdgeResizer() {
    const resizer = document.getElementById('helperEdgeResizer');
    const panel = document.getElementById('helperModal');
    if (!resizer || !panel) {
        return;
    }

    const sync = () => resizer.classList.toggle('visible', panel.classList.contains('helper-open'));
    sync();
    new MutationObserver(sync).observe(panel, { attributes: true, attributeFilter: ['class'] });

    let startX;
    let startW;
    resizer.addEventListener('mousedown', (e) => {
        if (e.target.closest('#helperToggleBtn')) {
            return;
        }
        if (!panel.classList.contains('helper-open')) {
            return;
        }
        startX = e.clientX;
        startW = panel.offsetWidth;
        resizer.classList.add('dragging');
        const onMove = (ev) => {
            const w = startW + (ev.clientX - startX);
            if (w >= 240 && w <= window.innerWidth * 0.8) {
                panel.style.width = w + 'px';
                if (state.editor) {
                    state.editor.layout();
                }
            }
        };
        const onUp = () => {
            resizer.classList.remove('dragging');
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
        e.preventDefault();
    });
}

/**
 * Toggle the Helper panel (`#helperModal`) open or closed and relayout the
 * Monaco editor after the width transition completes.
 */
function toggleHelperPanel() {
    const m = document.getElementById('helperModal');
    if (!m) {
        return;
    }
    if (m.classList.contains('helper-open')) {
        if (typeof window._closeHelperPanel === 'function') {
            window._closeHelperPanel();
        } else {
            m.classList.remove('helper-open');
        }
    } else {
        if (typeof window._openHelperPanel === 'function') {
            window._openHelperPanel();
        } else {
            m.classList.add('helper-open');
            if (typeof window._buildHelperAccordion === 'function') {
                window._buildHelperAccordion();
            }
        }
    }
    setTimeout(() => {
        if (state.editor) {
            state.editor.layout();
        }
    }, 350);
}

// -----------------------------------------------------------------------------
// Helper Screenshot Capture & Interactive Coordinate/Color Picking
// -----------------------------------------------------------------------------

/**
 * Attach screenshot capture (`/screenshot?format=png`), pixel-to-point coordinate
 * mapping, 2D canvas color sampling, and click/drag region selection handlers
 * to the Helper screen overlay.
 */
function _initHelperScreenCapture(ctx) {
    const { overlay, screenImg, screenCanvas, loadingEl } = ctx;

    ctx.captureScreen = async function captureScreen() {
        const hadPrev = screenImg && screenImg.naturalWidth > 0;
        if (!hadPrev && loadingEl) {
            loadingEl.style.display = 'block';
        }

        try {
            const url = `${API}/screenshot?format=png&t=${Date.now()}`;
            const png = new Image();
            png.crossOrigin = 'anonymous';
            await new Promise((resolve, reject) => {
                png.onload = resolve;
                png.onerror = reject;
                png.src = url;
            });
            screenImg.src = png.src;
            screenImg.style.display = 'block';
            if (loadingEl) {
                loadingEl.style.display = 'none';
            }
            screenCanvas.width = png.naturalWidth;
            screenCanvas.height = png.naturalHeight;
            ctx.canvasCtx = screenCanvas.getContext('2d', { willReadFrequently: true });
            ctx.canvasCtx.drawImage(png, 0, 0);
            state.screenSize = { w: png.naturalWidth, h: png.naturalHeight };
            appendLog(`📸 Screenshot: ${screenCanvas.width}x${screenCanvas.height}`, 'info');
        } catch (e) {
            if (!hadPrev && loadingEl) {
                loadingEl.textContent = '❌ Screenshot failed.';
            }
            appendLog('❌ Screenshot failed: ' + e.message, 'error');
        }
    };

    ctx.overlayToPixel = function overlayToPixel(e) {
        if (!screenImg || screenImg.style.display === 'none') {
            return null;
        }
        const imgRect = screenImg.getBoundingClientRect();
        const relX = e.clientX - imgRect.left;
        const relY = e.clientY - imgRect.top;
        if (relX < 0 || relX > imgRect.width || relY < 0 || relY > imgRect.height) {
            return null;
        }
        const pixelX = Math.round((relX / imgRect.width) * screenImg.naturalWidth);
        const pixelY = Math.round((relY / imgRect.height) * screenImg.naturalHeight);
        const px = Math.max(0, Math.min(pixelX, screenImg.naturalWidth - 1));
        const py = Math.max(0, Math.min(pixelY, screenImg.naturalHeight - 1));
        const pt = _pxToPt(px, py);
        return { x: px, y: py, ptX: pt.x, ptY: pt.y };
    };

    ctx.getColorAtPixel = function getColorAtPixel(x, y) {
        if (!ctx.canvasCtx) {
            return null;
        }
        const pixel = ctx.canvasCtx.getImageData(x, y, 1, 1).data;
        const r = pixel[0];
        const g = pixel[1];
        const b = pixel[2];
        const intColor = (r << 16) | (g << 8) | b;
        return {
            r,
            g,
            b,
            hex: `#${r.toString(16).padStart(2, '0').toUpperCase()}${g.toString(16).padStart(2, '0').toUpperCase()}${b.toString(16).padStart(2, '0').toUpperCase()}`,
            intHex: `0x${intColor.toString(16).padStart(6, '0').toUpperCase()}`,
            int: intColor,
        };
    };

    const _readoutEl = document.getElementById('helperReadout');
    const _scContainer = document.getElementById('helperScreenContainer');
    if (_readoutEl && _scContainer) {
        _scContainer.addEventListener('mouseenter', () => {
            _readoutEl.style.opacity = '1';
        });
        _scContainer.addEventListener('mouseleave', () => {
            _readoutEl.style.opacity = '0';
        });
    }

    overlay?.addEventListener('mousemove', (e) => {
        const pos = ctx.overlayToPixel(e);
        if (!pos) {
            return;
        }

        const ct = document.getElementById('helperCoordText');
        if (ct) {
            ct.textContent = `x: ${pos.ptX}  y: ${pos.ptY}  (pt)`;
        }

        const color = ctx.getColorAtPixel(pos.x, pos.y);
        if (color) {
            const sw = document.getElementById('helperColorSwatch');
            const it = document.getElementById('helperColorInt');
            if (sw) {
                sw.style.background = color.hex;
            }
            if (it) {
                it.textContent = color.int;
            }
        }

        if (state.helperMode === 'region' && state.regionStart && screenImg) {
            const regionRect = document.getElementById('helperRegionRect');
            if (regionRect) {
                const imgRect = screenImg.getBoundingClientRect();
                const container = document.getElementById('helperScreenContainer');
                const containerRect = container ? container.getBoundingClientRect() : imgRect;

                const scaleX = imgRect.width / screenImg.naturalWidth;
                const scaleY = imgRect.height / screenImg.naturalHeight;
                const offsetX = imgRect.left - containerRect.left;
                const offsetY = imgRect.top - containerRect.top;

                const startDispX = state.regionStart.x * scaleX + offsetX;
                const startDispY = state.regionStart.y * scaleY + offsetY;
                const curDispX = pos.x * scaleX + offsetX;
                const curDispY = pos.y * scaleY + offsetY;

                const rx = Math.min(startDispX, curDispX);
                const ry = Math.min(startDispY, curDispY);
                const rw = Math.abs(curDispX - startDispX);
                const rh = Math.abs(curDispY - startDispY);

                regionRect.style.left = rx + 'px';
                regionRect.style.top = ry + 'px';
                regionRect.style.width = rw + 'px';
                regionRect.style.height = rh + 'px';
                regionRect.style.display = 'block';
            }
        }
    });

    overlay?.addEventListener('click', async (e) => {
        const pos = ctx.overlayToPixel(e);
        if (!pos) {
            return;
        }
        e.preventDefault();
        e.stopPropagation();

        // Overlay/canvas coordinates are in physical pixels; ALang form fields use device points.
        const px = Math.round(pos.x);
        const py = Math.round(pos.y);
        const ptX = pos.ptX;
        const ptY = pos.ptY;

        let colorInt = 0;
        let hex = '#000000';
        const c = ctx.getColorAtPixel(pos.x, pos.y);
        if (c) {
            colorInt = c.int;
            hex = c.hex;
        }

        const sw = document.getElementById('helperColorSwatch');
        const it = document.getElementById('helperColorInt');
        if (sw) {
            sw.style.background = hex;
        }
        if (it) {
            it.textContent = colorInt;
        }

        const colorInfo = {
            x: ptX,
            y: ptY,
            hex: hex,
            int: colorInt,
        };

        if (state.helperMode === 'single') {
            state.pickedColors = [colorInfo];
        } else if (state.helperMode === 'multi') {
            state.pickedColors.push(colorInfo);
        } else if (state.helperMode === 'region' || state.helperMode === 'multiregion') {
            if (!state.regionStart) {
                state.regionStart = { x: px, y: py };
                let regionRect = document.getElementById('helperRegionRect');
                if (!regionRect) {
                    regionRect = document.createElement('div');
                    regionRect.id = 'helperRegionRect';
                    regionRect.style.cssText =
                        'position:absolute; border:2px dashed #818cf8; background:rgba(129,140,248,0.16); pointer-events:none; z-index:10; display:none; border-radius:3px;';
                    const container = document.getElementById('helperScreenContainer');
                    if (container) {
                        container.appendChild(regionRect);
                    }
                }
                appendLog(
                    _l(`Region start: (${ptX}, ${ptY}) pt`, `Bắt đầu vùng: (${ptX}, ${ptY}) pt`),
                );
                renderModalResults();
                return;
            } else {
                const rx = Math.min(state.regionStart.x, px);
                const ry = Math.min(state.regionStart.y, py);
                const rw = Math.abs(px - state.regionStart.x);
                const rh = Math.abs(py - state.regionStart.y);
                state.regionStart = null;
                const regionRect = document.getElementById('helperRegionRect');
                if (regionRect) {
                    regionRect.style.display = 'none';
                }
                // Retain pixel coordinates in `region` for `image_crop`; convert to device points in `regionPt` for ALang arguments.
                const entry = { region: [rx, ry, rw, rh], regionPt: _pxRectToPt(rx, ry, rw, rh) };
                if (state.helperMode === 'region') {
                    state.pickedColors = [entry];
                } else {
                    state.pickedColors.push(entry);
                }
                const pr = entry.regionPt;
                appendLog(
                    _l(
                        `Region #${state.pickedColors.length}: {${pr.join(', ')}} pt`,
                        `Vùng #${state.pickedColors.length}: {${pr.join(', ')}} pt`,
                    ),
                );
            }
        }

        appendLog(
            _l(
                `Color at (${ptX}, ${ptY}) pt: ${colorInt}`,
                `Màu tại (${ptX}, ${ptY}) pt: ${colorInt}`,
            ),
            'success',
        );
        renderModalResults();

        const tgt = state._helperPickTarget;
        if (tgt && state._helperOpenMethod) {
            const hideHint = () => {
                const h = document.getElementById('hm_act_hint');
                if (h) {
                    h.style.display = 'none';
                }
            };
            if (tgt.type === 'point') {
                tgt.input.value = String(ptX);
                tgt.fields[tgt.input.dataset.arg] = String(ptX);
                if (tgt.partner) {
                    tgt.partner.value = String(ptY);
                    tgt.fields[tgt.partner.dataset.arg] = String(ptY);
                }
                state._helperOpenMethod.updateCode?.();
                state._helperPickTarget = null;
                hideHint();
            } else if (tgt.type === 'color' && c) {
                if (tgt.rInput) {
                    tgt.rInput.value = String(c.r);
                    tgt.fields['red'] = String(c.r);
                }
                if (tgt.gInput) {
                    tgt.gInput.value = String(c.g);
                    tgt.fields['green'] = String(c.g);
                }
                if (tgt.bInput) {
                    tgt.bInput.value = String(c.b);
                    tgt.fields['blue'] = String(c.b);
                }
                if (tgt.xInput) {
                    tgt.xInput.value = String(ptX);
                    tgt.fields['x'] = String(ptX);
                }
                if (tgt.yInput) {
                    tgt.yInput.value = String(ptY);
                    tgt.fields['y'] = String(ptY);
                }
                state._helperOpenMethod.updateCode?.();
                state._helperPickTarget = null;
                hideHint();
            } else if (tgt.type === 'region') {
                const pc = state.pickedColors;
                const lastReg = pc[pc.length - 1];
                if (lastReg?.region) {
                    const [rx, ry, rw, rh] = lastReg.regionPt || _pxRectToPt(...lastReg.region);
                    tgt.input.value = `(${rx}, ${ry}, ${rw}, ${rh})`;
                    tgt.fields[tgt.input.dataset.arg] = tgt.input.value;
                    state._helperOpenMethod.updateCode?.();
                    state._helperPickTarget = null;
                    hideHint();
                }
            } else if (tgt.type === 'region_4inputs') {
                const pc = state.pickedColors;
                const lastReg = pc[pc.length - 1];
                if (lastReg?.region) {
                    const [rx, ry, rw, rh] = lastReg.regionPt || _pxRectToPt(...lastReg.region);
                    const fill = (inp, name, v) => {
                        if (!inp) {
                            return;
                        }
                        inp.value = String(v);
                        tgt.fields[name] = String(v);
                    };
                    fill(tgt.xInput, tgt.xInput?.dataset.arg, rx);
                    fill(tgt.yInput, tgt.yInput?.dataset.arg, ry);
                    fill(tgt.wInput, tgt.wInput?.dataset.arg, rw);
                    fill(tgt.hInput, tgt.hInput?.dataset.arg, rh);
                    state._helperOpenMethod.updateCode?.();
                    state._helperPickTarget = null;
                    hideHint();
                }
            } else if (tgt.type === 'image_crop') {
                const pc = state.pickedColors;
                const lastReg = pc[pc.length - 1];
                if (lastReg?.region && screenCanvas) {
                    const [rx, ry, rw, rh] = lastReg.region;
                    const buf = document.createElement('canvas');
                    buf.width = rw;
                    buf.height = rh;
                    buf.getContext('2d').drawImage(screenCanvas, rx, ry, rw, rh, 0, 0, rw, rh);
                    buf.toBlob(async (blob) => {
                        const name = 'auto_' + Date.now() + '.png';
                        try {
                            const res = await fetch(
                                `${API}/api/images?name=${encodeURIComponent(name)}`,
                                { method: 'POST', body: blob },
                            );
                            const ok = res.ok;
                            if (ok) {
                                tgt.input.value = `"${name}"`;
                                tgt.fields[tgt.input.dataset.arg] = tgt.input.value;
                                state._helperOpenMethod.updateCode?.();
                                appendLog(`💾 Saved crop: ${name}`, 'success');
                            } else {
                                appendLog('❌ Upload crop failed', 'error');
                            }
                        } catch (e) {
                            appendLog('❌ ' + e.message, 'error');
                        }
                        state._helperPickTarget = null;
                        hideHint();
                    }, 'image/png');
                }
            }
        }
    });
}

// -----------------------------------------------------------------------------
// Helper Panel Navigation & Mode Switching
// -----------------------------------------------------------------------------

/**
 * Initialize Helper panel open/close lifecycle, Escape key handling, and sub-tab
 * switching (`Functions`, `Apps`, `Color`).
 */
function _initHelperPanel(ctx) {
    const { modal } = ctx;
    const screenView = document.getElementById('screenView');
    const helperScreenSection = document.getElementById('helperScreenSection');
    const helperInner = modal.querySelector('.helper-inner');

    function closeHelper() {
        state.helperActive = false;
        if (helperScreenSection) {
            helperScreenSection.style.opacity = '0';
            helperScreenSection.style.transition = 'opacity 0.15s ease';
        }
        modal.classList.remove('helper-open');
        setTimeout(() => {
            if (helperScreenSection && helperInner) {
                helperScreenSection.classList.remove('overlaying-vnc');
                helperScreenSection.style.opacity = '';
                helperScreenSection.style.transition = '';
                helperInner.insertBefore(helperScreenSection, helperInner.firstChild);
            }
            if (state.editor) {
                state.editor.layout();
            }
        }, 380);
    }

    function openHelper() {
        initSdkCatalog();
        state.helperActive = true;
        if (helperScreenSection && screenView) {
            screenView.appendChild(helperScreenSection);
            helperScreenSection.classList.add('overlaying-vnc');
        }
        modal.classList.add('helper-open');
        ctx.captureScreen();
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        if (typeof window._buildHelperAccordion === 'function') {
            window._buildHelperAccordion();
        }
        setTimeout(() => {
            if (state.editor) {
                state.editor.layout();
            }
        }, 380);
    }

    // Expose open/close hooks for the workspace Control / Write Code mode switcher.
    window._openHelperPanel = openHelper;
    window._closeHelperPanel = closeHelper;

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('helper-open')) {
            closeHelper();
        }
    });

    document.querySelectorAll('.helper-tab-btn').forEach((btn) => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.htab;
            document
                .querySelectorAll('.helper-tab-btn')
                .forEach((b) => b.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.helper-tab-content').forEach((tc) => {
                tc.style.display = 'none';
            });
            const target = document.getElementById(
                'htab' + tab.charAt(0).toUpperCase() + tab.slice(1),
            );
            if (target) {
                target.style.display = 'flex';
            }
            if (tab === 'apps') {
                ctx.hmLoadApps();
            } else if (tab === 'color') {
                initSdkCatalog();
            }
            const overlay = document.getElementById('helperScreenOverlay');
            if (overlay) {
                overlay.style.cursor = 'default';
            }
        });
    });
}

/**
 * Initialize the Helper subsystem on `DOMContentLoaded`: screenshot capture,
 * Apps tab, panel open/close lifecycle, default picker mode, and SDK accordion.
 */
function initHelper() {
    const modal = document.getElementById('helperModal');
    if (!modal) {
        return;
    }

    const ctx = {
        modal,
        overlay: document.getElementById('helperScreenOverlay'),
        screenImg: document.getElementById('helperScreenImg'),
        screenCanvas: document.getElementById('helperScreenCanvas'),
        loadingEl: document.getElementById('helperScreenLoading'),
        canvasCtx: null,
        hint: null,
    };

    _initHelperScreenCapture(ctx);
    _initHelperAppsTab(ctx);
    _initHelperPanel(ctx);

    setHelperMode('region');
    state.helperAction = null;
    ctx.hint = document.getElementById('hm_act_hint');
    state._helperOpenMethod = null;
    state._helperPickTarget = null;

    _initHelperAccordion(ctx);
}

/** Set the active Helper coordinate picker mode (`'single'`, `'multi'`, or `'region'`). */
function setHelperMode(mode) {
    state.helperMode = mode;
}

// -----------------------------------------------------------------------------
// Picked Colors & Region Results Presentation
// -----------------------------------------------------------------------------

/** Render picked coordinates, colors, and regions inside `#helperModalResults`. */
function renderModalResults() {
    const container = document.getElementById('helperModalResults');
    if (!container) {
        return;
    }

    if (state.pickedColors.length === 0) {
        container.innerHTML =
            '<div style="color:#555; text-align:center; padding:16px 0;">Click on screen to pick colors</div>';
        return;
    }

    let html = '';
    state.pickedColors.forEach((c, i) => {
        if (c.region) {
            html += `<div class="hm-result-item">
        <span style="color:#818cf8;">#${i + 1}</span>
        <span>⬜</span>
        <span class="hm-result-coords">region {${c.region.join(', ')}}</span>
      </div>`;
        } else {
            html += `<div class="hm-result-item">
        <span style="color:#666;">#${i + 1}</span>
        <span class="hm-result-swatch" style="background:${c.hex}"></span>
        <span class="hm-result-coords">(${c.x}, ${c.y})</span>
        <span class="hm-result-int" style="color:#f0a030; cursor:pointer;" title="${_t('hmBtnCopy')}" onclick="_hmDoCopy('${c.int}')">${c.int}</span>
      </div>`;
        }
    });
    container.innerHTML = html;
}

/**
 * Sample pixel color from the device via `/color?x=<ptX>&y=<ptY>` and record
 * the picked color or region in `state.pickedColors`.
 */
async function helperPickColor(x, y, event) {
    if (!state.currentDevice) {
        return;
    }

    try {
        // Convert caller pixel coordinates to device points expected by `/color`.
        const pt = _pxToPt(x, y);
        const pixX = pt.x;
        const pixY = pt.y;

        const sampleSize = 1;
        const half = 0;

        let sumR = 0;
        let sumG = 0;
        let sumB = 0;
        let count = 0;
        if (sampleSize <= 1) {
            const res = await fetch(`${API}/color?x=${pixX}&y=${pixY}`);
            const data = await res.json();
            if (!data.success && data.ok !== true) {
                appendLog(`⚠️ Color pick failed`, 'error');
                return;
            }
            sumR = data.r;
            sumG = data.g;
            sumB = data.b;
            count = 1;
        } else {
            const step = sampleSize >= 9 ? 2 : 1;
            const promises = [];
            for (let dy = -half; dy <= half; dy += step) {
                for (let dx = -half; dx <= half; dx += step) {
                    const sx = Math.max(0, pixX + dx);
                    const sy = Math.max(0, pixY + dy);
                    promises.push(
                        fetch(`${API}/color?x=${sx}&y=${sy}`)
                            .then((r) => r.json())
                            .catch(() => null),
                    );
                }
            }
            const results = await Promise.all(promises);
            for (const d of results) {
                if (d && (d.success || d.ok)) {
                    sumR += d.r;
                    sumG += d.g;
                    sumB += d.b;
                    count++;
                }
            }
            if (count === 0) {
                appendLog(`⚠️ Color pick failed (no samples)`, 'error');
                return;
            }
        }

        const avgR = Math.round(sumR / count);
        const avgG = Math.round(sumG / count);
        const avgB = Math.round(sumB / count);
        const hex = `#${[avgR, avgG, avgB].map((v) => v.toString(16).padStart(2, '0')).join('')}`;
        const intColor = (avgR << 16) | (avgG << 8) | avgB;
        const intHex = `0x${intColor.toString(16).padStart(6, '0').toUpperCase()}`;

        const colorInfo = {
            x: pixX,
            y: pixY,
            r: avgR,
            g: avgG,
            b: avgB,
            hex,
            int: intColor,
            intHex,
            sampleSize,
            clientX: event.clientX,
            clientY: event.clientY,
        };

        if (state.helperMode === 'single') {
            state.pickedColors = [colorInfo];
        } else if (state.helperMode === 'multi') {
            state.pickedColors.push(colorInfo);
        } else if (state.helperMode === 'region') {
            if (!state.regionStart) {
                state.regionStart = { x: pixX, y: pixY };
                appendLog(
                    _l(
                        `⬜ Region start: (${pixX}, ${pixY})`,
                        `⬜ Bắt đầu vùng: (${pixX}, ${pixY})`,
                    ),
                );
                return;
            } else {
                const rx = Math.min(state.regionStart.x, pixX);
                const ry = Math.min(state.regionStart.y, pixY);
                const rw = Math.abs(pixX - state.regionStart.x);
                const rh = Math.abs(pixY - state.regionStart.y);
                state.pickedColors = [{ region: [rx, ry, rw, rh] }];
                state.regionStart = null;
                appendLog(
                    _l(
                        `⬜ Region: {${rx}, ${ry}, ${rw}, ${rh}}`,
                        `⬜ Vùng: {${rx}, ${ry}, ${rw}, ${rh}}`,
                    ),
                );
            }
        }

        addPickMarker(event, hex);

        ['', 'zoom'].forEach((prefix) => {
            const sid = prefix ? 'zoomColorSwatch' : 'liveColorSwatch';
            const pid = prefix ? 'zoomPixelColor' : 'pixelColor';
            const swatch = document.getElementById(sid);
            if (swatch) {
                swatch.style.display = 'inline-block';
                swatch.style.backgroundColor = hex;
            }
            const pc = document.getElementById(pid);
            if (pc) {
                pc.textContent = intHex;
                pc.style.color = hex;
            }
        });

        appendLog(
            `🎨 (${pixX},${pixY}) avg ${sampleSize}×${sampleSize}: ${intHex} ${hex} RGB(${avgR},${avgG},${avgB})`,
        );

        renderPickedColors();
    } catch (err) {
        appendLog(`⚠️ Color pick error: ${err.message}`, 'error');
    }
}

/** Place a visual color marker dot on `#screenView` at the clicked position. */
function addPickMarker(event, color) {
    const screenView = document.getElementById('screenView');
    const viewRect = screenView.getBoundingClientRect();

    if (state.helperMode === 'single') {
        screenView.querySelectorAll('.pick-marker').forEach((m) => m.remove());
    }

    const marker = document.createElement('div');
    marker.className = 'pick-marker';
    marker.style.left = event.clientX - viewRect.left + 'px';
    marker.style.top = event.clientY - viewRect.top + 'px';
    marker.style.borderColor = color;
    marker.style.boxShadow = `0 0 6px ${color}`;

    if (state.helperMode === 'multi') {
        marker.textContent = state.pickedColors.length;
        marker.style.width = '16px';
        marker.style.height = '16px';
        marker.style.fontSize = '9px';
        marker.style.display = 'flex';
        marker.style.alignItems = 'center';
        marker.style.justifyContent = 'center';
        marker.style.color = '#fff';
        marker.style.fontWeight = 'bold';
        marker.style.textShadow = '0 0 3px #000';
    }

    screenView.appendChild(marker);
}

/** Render the picked color list inside `#helperResults` and `#zoomHelperResults`. */
function renderPickedColors() {
    const containers = [
        document.getElementById('helperResults'),
        document.getElementById('zoomHelperResults'),
    ];

    const emptyHtml = '<div class="helper-empty">Click on screen to pick colors</div>';
    if (state.pickedColors.length === 0) {
        containers.forEach((c) => {
            if (c) {
                c.innerHTML = emptyHtml;
            }
        });
        return;
    }

    let html = '';
    state.pickedColors.forEach((c, i) => {
        if (c.region) {
            html += `<div class="helper-color-item">
                <span class="index">#${i + 1}</span>
                <span>⬜</span>
                <span class="coords">region {${c.region.join(', ')}}</span>
                <span class="remove-pick" onclick="removePickedColor(${i})">✕</span>
            </div>`;
        } else {
            html += `<div class="helper-color-item">
                <span class="index">#${i + 1}</span>
                <span class="swatch" style="background:${c.hex}"></span>
                <span class="coords">(${c.x}, ${c.y})</span>
                <span class="color-hex">${c.intHex}</span>
                <span class="color-int">RGB(${c.r},${c.g},${c.b})</span>
                <span class="remove-pick" onclick="removePickedColor(${i})">✕</span>
            </div>`;
        }
    });
    containers.forEach((c) => {
        if (c) {
            c.innerHTML = html;
        }
    });
}

/** Remove the picked color entry at `index` and refresh the results list. */
function removePickedColor(index) {
    state.pickedColors.splice(index, 1);
    renderPickedColors();
}

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.toggleHelperPanel = toggleHelperPanel;
window.removePickedColor = removePickedColor;
