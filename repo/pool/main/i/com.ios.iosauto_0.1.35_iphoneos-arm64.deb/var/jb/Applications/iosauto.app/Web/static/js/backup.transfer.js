/**
 * @file backup.transfer.js — Script/media file download and full backup archive
 * export/import.
 *
 * Communicates with `/api/scripts/download`, `/api/scripts/upload`,
 * `/api/backup/export`, and `/api/backup/import`.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Individual File Download
// -----------------------------------------------------------------------------

/**
 * Trigger a browser download for `blob` using a temporary object URL and anchor.
 */
function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

/**
 * Download a script or media file (`name`) from `/api/scripts/download`.
 * Encrypted `.aios` packages are downloaded directly via anchor navigation.
 */
async function downloadFile(name) {
    try {
        const baseName = name.split('/').pop();
        const ext = baseName.split('.').pop().toLowerCase();
        const href = `${API}/api/scripts/download?name=${encodeURIComponent(name)}`;

        if (ext === 'aios') {
            const a = document.createElement('a');
            a.href = href;
            a.download = baseName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            appendLog(`⬇️ Downloaded: ${name} 🔒`, 'success');
        } else {
            const res = await fetch(href);
            if (res.ok) {
                const blob = await res.blob();
                triggerDownload(blob, baseName);
                appendLog(`⬇️ Downloaded: ${name}`, 'success');
            } else {
                appendLog(`❌ Download failed`, 'error');
            }
        }
    } catch (e) {
        appendLog('❌ Download failed: ' + e.message, 'error');
    }
}

// -----------------------------------------------------------------------------
// Full Backup Archive Export & Import
// -----------------------------------------------------------------------------

/**
 * Export all scripts and images from `/api/backup/export` as a timestamped
 * `na_backup_YYYYMMDD_HHMM.json` archive.
 */
async function exportBackup() {
    const btn = document.getElementById('exportBackupBtn');
    const origHTML = btn.innerHTML;
    btn.innerHTML =
        '<i data-lucide="loader" style="width:12px;height:12px;animation:spin 1s linear infinite;"></i> Exporting...';
    btn.disabled = true;
    try {
        const res = await fetch(`${API}/api/backup/export`, { method: 'POST' });
        const data = await res.json();
        if (!data.success) {
            throw new Error('Export failed');
        }
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const now = new Date();
        const ts =
            now.getFullYear().toString() +
            String(now.getMonth() + 1).padStart(2, '0') +
            String(now.getDate()).padStart(2, '0') +
            '_' +
            String(now.getHours()).padStart(2, '0') +
            String(now.getMinutes()).padStart(2, '0');
        a.href = url;
        a.download = `na_backup_${ts}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        appendLog(
            `✅ Exported: ${data.script_count} scripts, ${data.image_count} images`,
            'success',
        );
    } catch (e) {
        appendLog('❌ Export failed: ' + e.message, 'error');
    } finally {
        btn.innerHTML = origHTML;
        btn.disabled = false;
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }
}

/**
 * Restore a JSON backup archive (`file`) containing scripts and images via
 * `/api/backup/import`.
 */
async function importBackup(file) {
    const btn = document.getElementById('importBackupBtn');
    const origHTML = btn.innerHTML;
    btn.innerHTML =
        '<i data-lucide="loader" style="width:12px;height:12px;animation:spin 1s linear infinite;"></i> Importing...';
    btn.disabled = true;
    try {
        const text = await file.text();
        const backup = JSON.parse(text);
        if (!backup.scripts && !backup.images) {
            throw new Error('Invalid backup file');
        }
        const res = await fetch(`${API}/api/backup/import`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: text,
        });
        const data = await res.json();
        if (data.success) {
            appendLog(
                `✅ Imported: ${data.scripts_imported} scripts, ${data.images_imported} images`,
                'success',
            );
            loadScriptFiles();
        } else {
            throw new Error(data.error || 'Import failed');
        }
    } catch (e) {
        appendLog('❌ Import failed: ' + e.message, 'error');
    } finally {
        btn.innerHTML = origHTML;
        btn.disabled = false;
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }
}

// -----------------------------------------------------------------------------
// Backup & Script Upload Control Bindings
// -----------------------------------------------------------------------------

document.getElementById('exportBackupBtn')?.addEventListener('click', exportBackup);
document.getElementById('importBackupBtn')?.addEventListener('click', () => {
    document.getElementById('importFileInput').click();
});
document.getElementById('importFileInput')?.addEventListener('change', async (e) => {
    if (!e.target.files[0]) {
        return;
    }
    const file = e.target.files[0];
    const ext = file.name.split('.').pop().toLowerCase();

    if (ext === 'json') {
        try {
            const text = await file.text();
            const parsed = JSON.parse(text);
            if (parsed && (parsed.scripts || parsed.images)) {
                importBackup(file);
                e.target.value = '';
                return;
            }
        } catch (_) {
            // Fall through to plain text upload if JSON is not a backup archive.
        }
    }

    if (ext === 'aios') {
        try {
            const buf = await file.arrayBuffer();
            const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
            const res = await fetch(`${API}/api/scripts/upload`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: file.name, data: b64 }),
            });
            const data = await res.json();
            if (data.success) {
                appendLog(`✅ Imported encrypted script: ${file.name} 🔒`, 'success');
                showToast(`🔒 Imported ${file.name}`, 'success');
                loadScriptFiles();
            } else {
                appendLog(`❌ Import failed: ${data.error}`, 'error');
                showToast(`❌ ${data.error}`, 'error');
            }
        } catch (err) {
            appendLog(`❌ Import error: ${err.message}`, 'error');
        }
    } else if (!ext || ['dylib', 'so', 'bin', 'plist', 'deb', 'ipa', 'exe'].includes(ext)) {
        appendLog(`❌ Unsupported file type: .${ext}`, 'error');
    } else {
        try {
            const code = await file.text();
            const res = await fetch(`${API}/api/scripts/upload`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: file.name, code }),
            });
            const data = await res.json();
            if (data.success) {
                appendLog(`✅ Imported: ${file.name}`, 'success');
                showToast(`✅ Imported ${file.name}`, 'success');
                loadScriptFiles();
            } else {
                appendLog(`❌ Import failed: ${data.error}`, 'error');
                showToast(`❌ ${data.error}`, 'error');
            }
        } catch (err) {
            appendLog(`❌ Import error: ${err.message}`, 'error');
        }
    }
    e.target.value = '';
});

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.downloadFile = downloadFile;
