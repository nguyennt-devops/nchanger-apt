/**
 * @file app.js — Web IDE classic-script bootstrap entry point.
 *
 * Functional modules reside under `/static/js/` using `<domain>.<role>.js`
 * naming and are loaded in deterministic dependency order before this file:
 *   1. core.state.js       — Shared state, coordinates, escaping, clipboard & toasts
 *   2. ui.theme.js         — Dark/Light theme state & toggle control
 *   3. ui.i18n.js          — Trilingual localization (`en`, `vi`, `zh`)
 *   4. device.control.js   — Device connection, keys/swipes, device info & setup
 *   5. editor.language.js  — Monaco themes, ALang syntax & IntelliSense providers
 *   6. editor.workspace.js — Monaco editor instance, tabs & unsaved-changes guard
 *   7. script.runner.js    — Script execution, stop handling & `.aios` encryption
 *   8. console.panel.js    — Console log output, state polling & panel resizer
 *   9. file.manager.js     — Script save, folder tree & file CRUD operations
 *  10. backup.transfer.js  — File download & backup archive export/import
 *  11. image.gallery.js    — Image/video gallery & media upload/import controls
 *  12. sdk.catalog.js      — SDK method categories, localized docs & loader
 *  13. screen.live.js      — Live screen stream iframe, overlay tap & resizer
 *  14. app.browser.js      — Installed iOS applications modal & Helper Apps tab
 *  15. helper.capture.js   — Helper panel layout, screenshot capture & color picker
 *  16. helper.dialogs.js   — Specialized Toast/Alert/Dialog/Safari Helper forms
 *  17. helper.forms.js     — Helper argument parser, generic forms & accordion
 *  18. helper.pickers.js   — Random list/email, OCR, Safari DOM & AX UI pickers
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Workspace Tabs & Control/Pick Mode Switcher
// -----------------------------------------------------------------------------

/**
 * Initialize primary workspace tab switching (`Editor`, `Files`, `Images`,
 * `Console`), vertical strip shortcuts (`.vstrip-tab`), and the Control vs.
 * Write Code (`#modeControlBtn` / `#modePickBtn`) mode switcher.
 */
function initTabs() {
    document.querySelectorAll('.tab').forEach((tab) => {
        tab.addEventListener('click', () => {
            const target = tab.dataset.tab;

            document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
            tab.classList.add('active');

            document.querySelectorAll('.tab-content').forEach((c) => c.classList.remove('active'));
            document.getElementById(`${target}Tab`)?.classList.add('active');

            if (target === 'files') {
                loadScriptFiles();
            }
            if (target === 'images') {
                loadImagesTab();
            }
            if (target === 'console') {
                const badge = document.getElementById('consoleBadge');
                if (badge) {
                    badge.textContent = '0';
                    badge.style.display = 'none';
                }
            }
        });
    });

    document.querySelectorAll('.vstrip-tab').forEach((vt) => {
        vt.addEventListener('click', () => {
            const target = vt.dataset.vtab;
            document.querySelectorAll('.vstrip-tab').forEach((b) => b.classList.remove('active'));
            vt.classList.add('active');
            document.querySelector(`.tab[data-tab="${target}"]`)?.click();
        });
    });

    const controlBtn = document.getElementById('modeControlBtn');
    const pickBtn = document.getElementById('modePickBtn');
    const helperModal = document.getElementById('helperModal');

    function syncMode() {
        const open = helperModal?.classList.contains('helper-open');
        controlBtn?.classList.toggle('active', !open);
        pickBtn?.classList.toggle('active', !!open);
    }

    function setMode(mode) {
        const open = helperModal?.classList.contains('helper-open');
        if (mode === 'pick' && !open) {
            if (typeof window._openHelperPanel === 'function') {
                window._openHelperPanel();
            }
        }
        if (mode === 'control' && open) {
            if (typeof window._closeHelperPanel === 'function') {
                window._closeHelperPanel();
            }
        }
        syncMode();
    }

    controlBtn?.addEventListener('click', () => setMode('control'));
    pickBtn?.addEventListener('click', () => setMode('pick'));
    if (helperModal) {
        new MutationObserver(syncMode).observe(helperModal, {
            attributes: true,
            attributeFilter: ['class'],
        });
    }
    // Tab visibility and Pick mode retain the mounted viewer. Its own lifecycle
    // releases input while hidden; only explicit Disconnect unloads the iframe.
}

// -----------------------------------------------------------------------------
// Global Keyboard Shortcuts & Shared Modal Overlays
// -----------------------------------------------------------------------------

/**
 * Bind document-level keyboard shortcuts (`Ctrl/Cmd+Enter` to run/stop and
 * `Ctrl/Cmd+S` to save the active script).
 */
function initKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            if (state.runningTaskId) {
                stopScript();
            } else {
                runScript();
            }
        }

        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            if (state.currentFileName) {
                saveScriptAs(state.currentFileName);
            } else {
                const now = new Date();
                const ts =
                    now.getFullYear().toString() +
                    String(now.getMonth() + 1).padStart(2, '0') +
                    String(now.getDate()).padStart(2, '0') +
                    '_' +
                    String(now.getHours()).padStart(2, '0') +
                    String(now.getMinutes()).padStart(2, '0') +
                    String(now.getSeconds()).padStart(2, '0');
                const autoName = `script_${ts}.a`;
                saveScriptAs(autoName);
            }
        }
    });
}

/**
 * Bind close buttons and backdrop click-to-dismiss handlers for shared
 * `.modal-overlay` dialogs (`#deviceInfoModal`, `#saveModal`).
 */
function initModals() {
    document.getElementById('closeDeviceInfo')?.addEventListener('click', () => {
        document.getElementById('deviceInfoModal').classList.remove('visible');
    });

    document.getElementById('closeSaveModal')?.addEventListener('click', () => {
        document.getElementById('saveModal').classList.remove('visible');
    });
    document.getElementById('confirmSaveBtn')?.addEventListener('click', saveScript);

    document.querySelectorAll('.modal-overlay').forEach((overlay) => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.classList.remove('visible');
            }
        });
    });
}

// -----------------------------------------------------------------------------
// Application Startup Sequence
// -----------------------------------------------------------------------------

/**
 * Initialize all Web IDE subsystems in deterministic order when the DOM is
 * ready, isolating individual subsystem failures so a single error cannot
 * abort page startup.
 */
function bootstrapIDE() {
    const safeInit = (name, fn) => {
        try {
            fn();
        } catch (e) {
            console.warn(`⚠️ ${name} failed:`, e);
        }
    };
    safeInit('theme', initIDETheme);
    safeInit('lang', initIDELang);
    safeInit('tabs', initTabs);
    safeInit('monaco', initMonacoEditor);
    safeInit('liveScreen', initLiveScreen);
    safeInit('console', initConsole);
    safeInit('modals', initModals);
    safeInit('shortcuts', initKeyboardShortcuts);
    safeInit('sdkCatalog', initSdkCatalog);
    safeInit('helperEdge', initHelperEdgeResizer);
    refreshDevices();
    safeInit('setup', checkSystemSetup);
    checkRunningScript();
    // Pre-load scripts so the Files tree is populated when the user opens the tab.
    loadScriptFiles().catch((e) => console.warn('Pre-load scripts failed:', e));
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

document.addEventListener('DOMContentLoaded', bootstrapIDE);
document.addEventListener('DOMContentLoaded', initImageUploadControls);
document.addEventListener('DOMContentLoaded', initHelper);
