/**
 * @file screen.live.js — Live screen stream iframe connection, disconnect,
 * Home button dispatch, coordinate overlay double-click tap, and panel width
 * resizer.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Stream Endpoint & Overlay Helpers
// -----------------------------------------------------------------------------

/**
 * Construct the embedded screen-stream iframe URL for `host` on port `5911`
 * (or the configured `IOSAUTO_SCREEN_PORT` override).
 */
function _getVncUrl(host, viewOnly) {
    const port = window.IOSAUTO_SCREEN_PORT || 5911;
    return `http://${host}:${port}/?embed=1`;
}

/**
 * Resolve the target device hostname from global overrides or `window.location.hostname`.
 */
function _getDeviceHost() {
    return window.IOSAUTO_DEVICE_HOST || window.location.hostname;
}

/**
 * Toggle pointer-event interception on `#vncCoordOverlay`:
 * - When a script is running (`state.runningTaskId` is truthy), capture pointer
 *   events on the overlay so accidental clicks do not pass into the live stream.
 * - When idle, set `pointer-events: none` so the embedded viewer receives input.
 */
function _syncVncOverlayPointer() {
    const coordOverlay = document.getElementById('vncCoordOverlay');
    if (!coordOverlay || coordOverlay.style.display === 'none') {
        return;
    }
    coordOverlay.style.pointerEvents = state.runningTaskId ? 'auto' : 'none';
}

// -----------------------------------------------------------------------------
// Live Screen Panel Initialization & Resizing
// -----------------------------------------------------------------------------

/**
 * Initialize the Live Screen panel (`#liveScreenPanel`), binding Connect,
 * Disconnect, Home button, double-click tap overlay, and horizontal drag resizer.
 */
function initLiveScreen() {
    const connectBtn = document.getElementById('screenConnectBtn');
    const disconnectBtn = document.getElementById('screenDisconnectBtn');
    const homeBtn = document.getElementById('screenHomeBtn');
    const placeholder = document.getElementById('screenPlaceholder');
    const screenView = document.getElementById('screenView');

    if (!connectBtn) {
        return;
    }

    let screenInfo = {
        width: 1170,
        height: 2532,
        scale: 3,
        pointWidth: 390,
        pointHeight: 844,
    };
    let isStreaming = false;

    (async function () {
        try {
            const res = await fetch(`${API}/screen_info`);
            const data = await res.json();
            if (data.width) {
                screenInfo = {
                    width: data.width,
                    height: data.height,
                    scale: data.scale || 3,
                    pointWidth: data.pointWidth || Math.round(data.width / (data.scale || 3)),
                    pointHeight: data.pointHeight || Math.round(data.height / (data.scale || 3)),
                };
                state.screenSize = { w: data.width, h: data.height };
                state.wdaPoints = { w: screenInfo.pointWidth, h: screenInfo.pointHeight };
                state.deviceScale = data.scale || 3;
                state.screenInfo = screenInfo;
                const bezel = document.getElementById('phoneBezel');
                if (bezel && screenInfo.width > 0 && screenInfo.height > 0) {
                    bezel.style.setProperty('--pw', String(screenInfo.width));
                    bezel.style.setProperty('--ph', String(screenInfo.height));
                }
            }
        } catch (e) {
            // Retain default iPhone 3x screen metrics if /screen_info fails.
        }
    })();

    connectBtn.addEventListener('click', async () => {
        // Each tab owns its viewer; repeated Connect must not reload a live iframe.
        // Contract: docs/WORKFLOW-SCREEN-PERSISTENCE-CONTRACT.md.
        if (isStreaming) {
            return;
        }
        const vncFrame = document.getElementById('vncFrame');
        const host = _getDeviceHost();
        if (!host || !vncFrame) {
            appendLog(_l('Could not connect to iPhone', 'Không kết nối được iPhone'), 'error');
            return;
        }

        placeholder.style.display = 'none';
        isStreaming = true;
        if (homeBtn) {
            homeBtn.style.display = 'flex';
        }
        connectBtn.style.display = 'none';
        if (disconnectBtn) {
            disconnectBtn.style.display = 'flex';
        }

        const vncUrl = _getVncUrl(host, false);
        vncFrame.src = vncUrl;
        vncFrame.style.display = 'block';
        const coordOverlay = document.getElementById('vncCoordOverlay');
        if (coordOverlay) {
            coordOverlay.style.display = 'block';
            _syncVncOverlayPointer();
        }
        appendLog(_l('Connected to iPhone', 'Đã kết nối iPhone'), 'success');
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    });

    disconnectBtn.addEventListener('click', () => {
        const vncFrame = document.getElementById('vncFrame');
        if (vncFrame) {
            vncFrame.src = '';
            vncFrame.style.display = 'none';
        }
        const coordOverlay = document.getElementById('vncCoordOverlay');
        if (coordOverlay) {
            coordOverlay.style.display = 'none';
        }
        placeholder.style.display = '';
        if (homeBtn) {
            homeBtn.style.display = 'flex';
        }
        connectBtn.style.display = 'flex';
        if (disconnectBtn) {
            disconnectBtn.style.display = 'none';
        }
        isStreaming = false;
        appendLog(_l('Disconnected from iPhone', 'Đã ngắt kết nối iPhone'), 'info');
    });

    if (homeBtn) {
        homeBtn.style.display = 'flex';
        homeBtn.addEventListener('click', async () => {
            try {
                await fetch(`${API}/key?key=home`);
                appendLog(_l('🏠 Home', '🏠 Home'), 'success');
            } catch (e) {
                appendLog('🏠 ' + e.message, 'error');
            }
        });
    }

    function getStreamBounds() {
        const box = document.getElementById('phoneBezel') || screenView;
        const rect = box.getBoundingClientRect();
        const natW =
            screenInfo.pointWidth || Math.round(screenInfo.width / (screenInfo.scale || 3));
        const natH =
            screenInfo.pointHeight || Math.round(screenInfo.height / (screenInfo.scale || 3));
        const containerRatio = rect.width / rect.height;
        const imageRatio = natW / natH;

        let renderW;
        let renderH;
        let offsetX;
        let offsetY;
        if (imageRatio > containerRatio) {
            renderW = rect.width;
            renderH = rect.width / imageRatio;
            offsetX = 0;
            offsetY = (rect.height - renderH) / 2;
        } else {
            renderH = rect.height;
            renderW = rect.height * imageRatio;
            offsetX = (rect.width - renderW) / 2;
            offsetY = 0;
        }
        return { renderW, renderH, offsetX, offsetY, natW, natH, rect };
    }

    // Double-clicking the coordinate overlay dispatches a device-point tap (/tap).
    const coordOverlayEl = document.getElementById('vncCoordOverlay');
    if (coordOverlayEl) {
        coordOverlayEl.addEventListener('dblclick', async (e) => {
            const bounds = getStreamBounds();
            const relX = e.clientX - bounds.rect.left - bounds.offsetX;
            const relY = e.clientY - bounds.rect.top - bounds.offsetY;
            if (relX < 0 || relX > bounds.renderW || relY < 0 || relY > bounds.renderH) {
                return;
            }
            const x = Math.round((relX / bounds.renderW) * bounds.natW);
            const y = Math.round((relY / bounds.renderH) * bounds.natH);
            try {
                await fetch(`${API}/tap?x=${x}&y=${y}`);
                appendLog(_l(`👆 Tap (${x}, ${y}) pt`, `👆 Chạm (${x}, ${y}) pt`), 'success');
            } catch (err) {
                appendLog('👆 ' + err.message, 'error');
            }
        });
    }

    const resizer = document.getElementById('screenResizer');
    const panel = document.getElementById('liveScreenPanel');
    if (resizer && panel) {
        let startX;
        let startWidth;

        resizer.addEventListener('mousedown', (e) => {
            startX = e.clientX;
            startWidth = panel.offsetWidth;
            document.addEventListener('mousemove', onResize);
            document.addEventListener('mouseup', stopResize);
            e.preventDefault();
        });

        function onResize(e) {
            const newWidth = startWidth + (e.clientX - startX);
            if (newWidth >= 200 && newWidth <= 600) {
                panel.style.width = newWidth + 'px';
                if (state.editor) {
                    state.editor.layout();
                }
            }
        }

        function stopResize() {
            document.removeEventListener('mousemove', onResize);
            document.removeEventListener('mouseup', stopResize);
        }
    }
}

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window._syncVncOverlayPointer = _syncVncOverlayPointer;
