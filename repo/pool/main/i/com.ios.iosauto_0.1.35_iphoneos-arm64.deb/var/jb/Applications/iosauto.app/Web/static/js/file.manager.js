/**
 * @file file.manager.js — Script saving, destination folder picker, recursive
 * folder/file tree rendering, and file CRUD operations.
 *
 * Communicates with `/api/scripts/save`, `/api/scripts/files`,
 * `/api/scripts/load`, `/api/scripts/mkdir`, `/api/scripts/move`, and
 * `/api/scripts/delete`.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Script Saving & Destination Folder Selection
// -----------------------------------------------------------------------------

/**
 * Save the active editor buffer using the folder and filename selected in
 * `#saveModal` via `/api/scripts/save`.
 * Refuses to overwrite encrypted `.aios` packages.
 */
async function saveScript() {
    const folder = document.getElementById('saveFolderSelect')?.value || '';
    const baseName = document.getElementById('scriptNameInput').value || 'untitled.a';
    const name = folder ? `${folder}/${baseName}` : baseName;
    if (/\.aios$/i.test(name)) {
        appendLog(
            _l('❌ Cannot save over encrypted .aios', '❌ Không ghi đè file .aios đã mã hoá'),
            'error',
        );
        return;
    }
    const code = getEditorValue();

    try {
        const res = await fetch(`${API}/api/scripts/save`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, code }),
        });
        const data = await res.json();
        if (data.success) {
            state.currentFileName = data.name || name;
            state._dirty = false;
            appendLog(
                _l(`💾 Saved: ${state.currentFileName}`, `💾 Đã lưu: ${state.currentFileName}`),
                'success',
            );
            document.getElementById('saveModal').classList.remove('visible');
            loadScriptFiles();
            if (state._runAfterSave) {
                state._runAfterSave = false;
                runScript();
            }
        } else {
            state._runAfterSave = false;
            appendLog(
                _l(
                    `❌ Save failed: ${data.error || 'unknown'}`,
                    `❌ Lưu thất bại: ${data.error || 'không rõ lý do'}`,
                ),
                'error',
            );
        }
    } catch (e) {
        state._runAfterSave = false;
        appendLog('❌ Save failed: ' + e.message, 'error');
    }
}

/**
 * Populate `#saveFolderSelect` with the current list of script directories
 * whenever `#saveModal` becomes visible.
 */
function populateFolderPicker() {
    const sel = document.getElementById('saveFolderSelect');
    if (!sel) {
        return;
    }
    const folders = state._folders || [];
    sel.innerHTML =
        '<option value="">/ (root)</option>' +
        folders.map((f) => `<option value="${f}">${f}</option>`).join('');
    if (state.currentFileName && state.currentFileName.includes('/')) {
        const folder = state.currentFileName.substring(0, state.currentFileName.lastIndexOf('/'));
        sel.value = folder;
        document.getElementById('scriptNameInput').value = state.currentFileName.split('/').pop();
    }
}

const _saveModalEl = document.getElementById('saveModal');
if (_saveModalEl) {
    const _saveMo = new MutationObserver(() => {
        if (_saveModalEl.classList.contains('visible')) {
            populateFolderPicker();
        }
    });
    _saveMo.observe(_saveModalEl, { attributes: true, attributeFilter: ['class'] });
}

/**
 * Save the active editor buffer directly to `fileName` (`Ctrl/Cmd+S` shortcut)
 * without opening the Save modal.
 */
async function saveScriptAs(fileName) {
    if (/\.aios$/i.test(fileName || '')) {
        appendLog(
            _l('❌ Cannot save over encrypted .aios', '❌ Không ghi đè file .aios đã mã hoá'),
            'error',
        );
        return;
    }
    const code = getEditorValue();
    try {
        const res = await fetch(`${API}/api/scripts/save`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: fileName, code }),
        });
        const data = await res.json();
        if (data.success) {
            state.currentFileName = data.name || fileName;
            state._dirty = false;
            document.getElementById('scriptNameInput').value = state.currentFileName;
            appendLog(
                _l(`💾 Saved: ${state.currentFileName}`, `💾 Đã lưu: ${state.currentFileName}`),
                'success',
            );
            showToast(`💾 ${state.currentFileName}`, 'success');
        } else {
            showToast(`❌ ${data.error || 'Save failed'}`, 'error');
        }
    } catch (e) {
        appendLog('❌ Save failed: ' + e.message, 'error');
        showToast(`❌ ${e.message}`, 'error');
    }
}

// -----------------------------------------------------------------------------
// Folder & File Tree Rendering
// -----------------------------------------------------------------------------

if (!window._expandedFolders) {
    window._expandedFolders = new Set();
}

/**
 * Render a collapsible directory entry and its recursively sorted children for
 * the Files tab tree view.
 */
function renderFolderItem(f, indent = 0) {
    const expanded = window._expandedFolders.has(f.path);
    const childrenHtml = expanded
        ? f.children
              .sort((a, b) => {
                  if (a.type !== b.type) {
                      return a.type === 'folder' ? -1 : 1;
                  }
                  return (b.modified || 0) - (a.modified || 0);
              })
              .map((c) => renderFileItem(c, indent + 1))
              .join('')
        : '';
    const childWrapper =
        expanded && childrenHtml
            ? `
      <div class="folder-children" style="margin-left:${12 + indent * 12}px; padding-left:12px; border-left:2px solid rgba(129,140,248,0.28); margin-bottom:6px;">
        ${childrenHtml}
      </div>`
            : '';
    return `
      <div class="folder-item" style="margin-left:${indent * 12}px" onclick="toggleFolder('${f.path}')">
        <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0;">
          <i data-lucide="${expanded ? 'folder-open' : 'folder'}" style="width:16px;height:16px;flex-shrink:0;color:#818cf8;"></i>
          <div style="min-width:0;">
            <div class="file-name" style="font-weight:600;">${f.name}</div>
            <div class="file-meta">${f.count || 0} ${_l('items', 'mục')}</div>
          </div>
        </div>
        <div class="file-actions">
          <i data-lucide="${expanded ? 'chevron-down' : 'chevron-right'}" style="width:14px;height:14px;opacity:0.4;"></i>
          <button class="file-action-btn file-delete-btn" onclick="event.stopPropagation(); delete_file('${f.path}')" title="Delete Folder"><i data-lucide="trash-2" style="width:14px;height:14px;"></i></button>
        </div>
      </div>
      ${childWrapper}`;
}

/**
 * Render a file row (`.a`, `.aios`, `.txt`, image, or video) or delegate to
 * `renderFolderItem` when `f.type === 'folder'`.
 */
function renderFileItem(f, indent = 0) {
    if (f.type === 'folder') {
        return renderFolderItem(f, indent);
    }

    const date = new Date(f.modified * 1000);
    const dateStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    const isRunning = state.runningFileName === f.path;
    const isTxt = f.name.endsWith('.txt');
    const isPy = f.name.endsWith('.a');
    const isEnc = f.name.endsWith('.aios') || f.encrypted;
    const isImg = /\.(png|jpe?g|webp|heic|gif)$/i.test(f.name);
    const isVid = /\.(mp4|mov|m4v|webm)$/i.test(f.name);
    const isMedia = isImg || isVid;

    let fileIcon = 'file-code';
    if (isEnc) {
        fileIcon = 'lock';
    } else if (isVid) {
        fileIcon = 'film';
    } else if (isImg) {
        fileIcon = 'image';
    } else if (isTxt) {
        fileIcon = 'file-text';
    } else if (isRunning) {
        fileIcon = 'flame';
    }

    let iconStyle = 'color:#818cf8;opacity:0.75;';
    if (isEnc) {
        iconStyle = 'color:#f59e0b;';
    } else if (isRunning) {
        iconStyle = 'color:#f97316;';
    } else if (isVid) {
        iconStyle = 'color:#67e8f9;';
    } else if (isImg) {
        iconStyle = 'color:#34d399;';
    } else if (isTxt) {
        iconStyle = 'color:#a3b1c6;';
    }

    const pathJS = escJS(f.path);
    const nameJS = escJS(f.name);

    let playStopBtn = '';
    if (!isTxt && !isMedia) {
        if (isRunning) {
            playStopBtn = `<button class="file-action-btn file-stop-btn" onclick="event.stopPropagation(); stopScript()" title="Stop"><i data-lucide="square" style="width:14px;height:14px;"></i></button>`;
        } else {
            playStopBtn = `<button class="file-action-btn file-play-btn" onclick="event.stopPropagation(); runFileScript('${pathJS}')" title="Run"><i data-lucide="play" style="width:14px;height:14px;"></i></button>`;
        }
    }

    const moveBtn = isMedia
        ? ''
        : `<button class="file-action-btn" onclick="event.stopPropagation(); moveFileToFolder('${pathJS}')" title="Move" style="color:#818cf8;"><i data-lucide="folder-input" style="width:14px;height:14px;"></i></button>`;
    const rowClick = isMedia ? `copyImageName('${nameJS}')` : `loadFile('${pathJS}')`;

    return `
    <div class="file-item ${isRunning ? 'file-running' : ''}" onclick="${rowClick}">
      <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0;">
        <i data-lucide="${fileIcon}" style="width:16px;height:16px;flex-shrink:0;${iconStyle}"></i>
        <div style="min-width:0;">
          <div class="file-name">${escapeHtml(f.name)}</div>
          <div class="file-meta">${dateStr} · ${(f.size / 1024).toFixed(1)}KB${isRunning ? ` · <span style="color:#22c55e;font-weight:600;">${_l('Running', 'Đang chạy')}</span>` : ''}</div>
        </div>
      </div>
      <div class="file-actions">
        ${playStopBtn}
        ${moveBtn}
        ${isPy ? `<button class="file-action-btn" onclick="event.stopPropagation(); encrypt_script('${pathJS}')" title="Encrypt" style="color:#f59e0b;"><i data-lucide="lock" style="width:14px;height:14px;"></i></button>` : ''}
        <button class="file-action-btn" onclick="event.stopPropagation(); downloadFile('${pathJS}')" title="Download"><i data-lucide="download" style="width:14px;height:14px;"></i></button>
        ${!isEnc ? `<button class="file-action-btn file-rename-btn" onclick="event.stopPropagation(); renameFile('${pathJS}')" title="Rename"><i data-lucide="pencil" style="width:14px;height:14px;"></i></button>` : ''}
        <button class="file-action-btn file-delete-btn" onclick="event.stopPropagation(); delete_file('${pathJS}')" title="Delete"><i data-lucide="trash-2" style="width:14px;height:14px;"></i></button>
      </div>
    </div>`;
}

/** Toggle the expanded/collapsed state of a folder path in the Files tree. */
function toggleFolder(path) {
    if (window._expandedFolders.has(path)) {
        window._expandedFolders.delete(path);
    } else {
        window._expandedFolders.add(path);
    }
    loadScriptFiles();
}

// -----------------------------------------------------------------------------
// Directory & File CRUD Operations
// -----------------------------------------------------------------------------

/** Prompt for a directory name and create it on the device via `/api/scripts/mkdir`. */
async function createFolder() {
    const name = prompt('Folder name:');
    if (!name || !name.trim()) {
        return;
    }
    try {
        const res = await fetch(`${API}/api/scripts/mkdir`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: name.trim() }),
        });
        const data = await res.json();
        if (data.success) {
            appendLog(
                _l(`📁 Created folder: ${data.path}`, `📁 Đã tạo thư mục: ${data.path}`),
                'success',
            );
            loadScriptFiles();
        } else {
            appendLog(`❌ ${data.error}`, 'error');
        }
    } catch (e) {
        appendLog('❌ Create folder failed: ' + e.message, 'error');
    }
}

/** Move or rename a script/media path on the server via `/api/scripts/move`. */
async function moveScriptPath(from, to) {
    const res = await fetch(`${API}/api/scripts/move`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ from, to }),
    });
    const data = await res.json();
    if (!data.success && !data.ok) {
        throw new Error(data.error || 'move fail');
    }
    return data;
}

/** Prompt the user for a target directory and move `filePath` into it. */
async function moveFileToFolder(filePath) {
    const folders = state._folders || [];
    const current = filePath.includes('/') ? filePath.substring(0, filePath.lastIndexOf('/')) : '';
    const label = _l(
        `Move to folder (empty = root):\nAvailable: ${folders.join(', ') || '(none)'}`,
        `Chuyển vào thư mục (trống = root):\nCó: ${folders.join(', ') || '(không có)'}`,
    );
    const choice = prompt(label, current);
    if (choice === null) {
        return;
    }
    const targetFolder = choice.trim();
    const fileName = filePath.split('/').pop();
    const newPath = targetFolder ? `${targetFolder}/${fileName}` : fileName;
    if (newPath === filePath) {
        return;
    }
    try {
        await moveScriptPath(filePath, newPath);
        appendLog(`📁 Moved: ${filePath} → ${newPath}`, 'success');
        if (state.currentFileName === filePath) {
            state.currentFileName = newPath;
            document.getElementById('scriptNameInput').value = newPath;
        }
        loadScriptFiles();
    } catch (e) {
        appendLog('❌ Move failed: ' + e.message, 'error');
    }
}

/**
 * Fetch the hierarchical script and media file tree from `/api/scripts/files`,
 * filter to supported script/media extensions, and render `#filesList`.
 */
async function loadScriptFiles() {
    try {
        const res = await fetch(`${API}/api/scripts/files`);
        const data = await res.json();
        const container = document.getElementById('filesList');

        state._folders = data.folders || [];

        const KEEP_EXT = /\.(a|aios|txt|png|jpe?g|webp|heic|gif|mp4|mov|m4v|webm)$/i;
        function keepFile(f) {
            if (f.type === 'folder') {
                return true;
            }
            return KEEP_EXT.test(f.name);
        }
        function filterTree(arr) {
            return arr.filter(keepFile).map((f) => {
                if (f.type === 'folder' && Array.isArray(f.children)) {
                    const kids = filterTree(f.children);
                    return { ...f, children: kids, count: kids.length };
                }
                return f;
            });
        }
        const visible = filterTree(data.files || []);

        if (!data.success || visible.length === 0) {
            container.innerHTML =
                '<div class="files-empty">' +
                _l(
                    'No saved scripts yet.<br>Press 💾 to save your first script.',
                    'Chưa có script nào.<br>Bấm 💾 để lưu script đầu tiên.',
                ) +
                '</div>';
            return;
        }

        const sorted = visible.sort((a, b) => {
            if (a.type !== b.type) {
                return a.type === 'folder' ? -1 : 1;
            }
            return (b.modified || 0) - (a.modified || 0);
        });

        container.innerHTML = sorted.map((f) => renderFileItem(f)).join('');
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    } catch (e) {
        console.error('Load files failed:', e);
    }
}

/**
 * Delete a script, media file, or folder (`name`) via `/api/scripts/delete`
 * and refresh the Files tree (and Images tab when deleting from `images/`).
 */
async function delete_file(name) {
    try {
        const res = await fetch(`${API}/api/scripts/delete?name=${encodeURIComponent(name)}`, {
            method: 'POST',
        });
        const data = await res.json();
        if (data.success) {
            appendLog(_l(`🗑️ Deleted: ${name}`, `🗑️ Đã xoá: ${name}`));
            loadScriptFiles();
            if (name === 'images' || name.startsWith('images/')) {
                loadImagesTab();
            }
        } else {
            appendLog(`❌ Delete failed`, 'error');
        }
    } catch (e) {
        appendLog('❌ Delete failed: ' + e.message, 'error');
    }
}

/**
 * Load a script or text file (`name`) from `/api/scripts/load` into an editor
 * tab and switch to the Editor view.
 */
async function loadFile(name) {
    try {
        const res = await fetch(`${API}/api/scripts/load?name=${encodeURIComponent(name)}`);
        const data = await res.json();
        if (data.success) {
            const isEncrypted = data.encrypted || false;
            if (!openTab(name, data.code, isEncrypted)) {
                return;
            }
            const nameInput = document.getElementById('scriptNameInput');
            if (nameInput) {
                nameInput.value = name;
            }
            document.querySelector('.tab[data-tab="editor"]')?.click();
            appendLog(
                _l(
                    `📂 Loaded: ${name}${isEncrypted ? ' 🔒' : ''}`,
                    `📂 Đã mở: ${name}${isEncrypted ? ' 🔒' : ''}`,
                ),
            );
        } else {
            appendLog(
                _l(
                    `❌ Load failed: ${data.error || name}`,
                    `❌ Mở file thất bại: ${data.error || name}`,
                ),
                'error',
            );
        }
    } catch (e) {
        appendLog('❌ Load failed: ' + e.message, 'error');
    }
}

/**
 * Start an inline rename input inside the matching `.file-item` row, falling
 * back to `window.prompt` when the row is not currently mounted.
 */
async function renameFile(oldName) {
    const baseName = oldName.split('/').pop();
    const stem = baseName.replace(/\.[^.]+$/, '');
    const fileRows = document.querySelectorAll('.file-item');
    let targetRow = null;
    for (const row of fileRows) {
        const nm = row.querySelector('.file-name');
        if (nm && nm.textContent === baseName) {
            targetRow = row;
            break;
        }
    }

    if (!targetRow) {
        const newName = window.prompt('Rename file:', stem);
        if (!newName || newName === stem) {
            return;
        }
        await doRename(oldName, newName);
        return;
    }

    const nameEl = targetRow.querySelector('.file-name');
    if (!nameEl) {
        return;
    }
    const origText = nameEl.textContent;
    const input = document.createElement('input');
    input.type = 'text';
    input.value = stem;
    input.className = 'rename-input';
    input.style.cssText =
        'padding:2px 6px; font-size:12px; border-radius:4px; border:1px solid var(--accent); background:var(--bg-primary); color:var(--text-primary); width:120px; outline:none;';
    nameEl.textContent = '';
    nameEl.appendChild(input);
    input.focus();
    input.select();

    const finish = async (confirmed) => {
        if (confirmed) {
            const val = input.value.trim();
            if (val && val !== stem) {
                await doRename(oldName, val);
                return;
            }
        }
        nameEl.textContent = origText;
    };

    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            finish(true);
        }
        if (e.key === 'Escape') {
            e.preventDefault();
            finish(false);
        }
    });
    input.addEventListener('blur', () => finish(false));
}

/**
 * Execute a file rename on the server while preserving the parent folder path
 * and original file extension when omitted by the user.
 */
async function doRename(oldName, newName) {
    const folderPrefix = oldName.includes('/')
        ? oldName.substring(0, oldName.lastIndexOf('/') + 1)
        : '';
    const ext = oldName.match(/\.[^./]+$/);
    const origExt = ext ? ext[0] : '.a';
    const cleanNew = newName.split('/').pop();
    const finalBase = cleanNew.match(/\.[^.]+$/) ? cleanNew : cleanNew + origExt;
    const finalName = folderPrefix + finalBase;
    try {
        await moveScriptPath(oldName, finalName);
        if (state.currentFileName === oldName) {
            state.currentFileName = finalName;
            document.getElementById('scriptNameInput').value = finalName;
        }
        appendLog(
            _l(`✏️ Renamed: ${oldName} → ${finalName}`, `✏️ Đã đổi tên: ${oldName} → ${finalName}`),
        );
        loadScriptFiles();
        if (oldName.startsWith('images/')) {
            loadImagesTab();
        }
    } catch (e) {
        appendLog('❌ Rename failed: ' + e.message, 'error');
    }
}

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.toggleFolder = toggleFolder;
window.createFolder = createFolder;
window.moveFileToFolder = moveFileToFolder;
window.renameFile = renameFile;
window.loadFile = loadFile;
window.delete_file = delete_file;
