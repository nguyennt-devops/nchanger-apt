/**
 * @file console.panel.js — Console log output rendering, bounded RAF batch
 * flushing, `/api/scripts/state` polling loop, quick command bar, and console
 * panel drag resizer.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Console Output, RAF Batching & State Polling
// -----------------------------------------------------------------------------

/**
 * Initialize the console clear button, bounded `requestAnimationFrame` log
 * flushing queue, `/api/scripts/state` polling loop, periodic file-list refresh,
 * and the quick ALang command input bar.
 */
function initConsole() {
    document.getElementById('clearConsole')?.addEventListener('click', () => {
        const output = document.getElementById('consoleOutput');
        output.innerHTML = '';
        state._consoleLogCount = 0;
        state._consoleTotalLines = 0;
        fetch(`${API}/api/console/clear`, { method: 'POST' }).catch(() => {});
        appendLog(_l('🗑️ Console cleared', '🗑️ Đã xoá console'));
    });

    state._consoleLogCount = 0;
    state._consoleRunId = 0;

    // A poll admitted before a tab hides can finish while animation callbacks
    // are suspended. Give that pending display batch its own explicit bound.
    // Retain only the newest display events, matching the existing 300-line batch
    // DOM bound; device logs and polling cursors keep their separate ownership.
    // Contract: docs/WORKFLOW-SCREEN-RESOURCE-CONTRACT.md.
    const pendingConsoleLimit = 300;
    let _ssePending = [];
    let _sseRafScheduled = false;

    function _sseFlush() {
        _sseRafScheduled = false;
        if (_ssePending.length === 0) {
            return;
        }

        const output = document.getElementById('consoleOutput');
        const welcome = output.querySelector('.console-welcome');
        if (welcome) {
            welcome.remove();
        }

        const frag = document.createDocumentFragment();
        const ts = formatTime(new Date());

        for (const msg of _ssePending) {
            if (typeof msg === 'string' && msg.includes('__TOAST__|')) {
                const parts = msg.split('__TOAST__|')[1].split('|');
                show_toast(parts[0] || 'Toast', (parseFloat(parts[1]) || 2.0) * 1000);
                continue;
            }

            const line = document.createElement('div');
            let type = '';
            if (msg.includes('❌') || msg.includes('Error')) {
                type = 'error';
            } else if (msg.includes('✅')) {
                type = 'success';
            } else if (msg.includes('▶️') || msg.includes('📋')) {
                type = 'info';
            }
            line.className = `console-line ${type}`;

            line.innerHTML = `<span class="timestamp">${ts}</span>${_formatLogMsg(msg)}`;
            frag.appendChild(line);
        }

        const batchSize = _ssePending.length;
        _ssePending = [];
        output.appendChild(frag);

        capConsoleDOMLines(output, 300);

        if (typeof lucide !== 'undefined') {
            lucide.createIcons({ attrs: {}, nameAttr: 'data-lucide' });
        }
        output.scrollTop = output.scrollHeight;

        _incrementConsoleBadge(batchSize);
    }

    function _sseSchedule(msg) {
        _ssePending.push(msg);
        if (_ssePending.length > pendingConsoleLimit) {
            _ssePending.splice(0, _ssePending.length - pendingConsoleLimit);
        }
        if (!_sseRafScheduled) {
            _sseRafScheduled = true;
            requestAnimationFrame(_sseFlush);
        }
    }

    let _stateSince = 0;
    let _stateRunId = 0;
    let _stateBusy = false;
    let _stateTimer = null;

    async function _pollState() {
        if (_stateBusy) {
            return;
        }
        if (document.visibilityState !== 'visible') {
            return;
        }
        _stateBusy = true;
        try {
            const res = await fetch(`${API}/api/scripts/state?since=${_stateSince}`);
            const data = await res.json();
            if (!data.ok) {
                _stateBusy = false;
                return;
            }
            const isNewRun = data.runId !== _stateRunId;
            if (isNewRun) {
                _stateRunId = data.runId;
                _stateSince = 0;
            } else {
                for (const entry of data.logs || []) {
                    const m = entry.msg || '';
                    if (m.length) {
                        _sseSchedule(m);
                    }
                }
                if (typeof data.total === 'number') {
                    _stateSince = data.total;
                }
            }

            // Daemon state is the sole source of truth for Run/Stop button transitions.
            // While in 'pending' mode (waiting for a Stop request to complete), keep
            // the button dimmed until the daemon reports `running === false`.
            const wasRunning = !!state.runningTaskId;
            if (data.running) {
                if (_runBtnMode === 'pending') {
                    // Wait for the daemon to finish stopping; keep the button dimmed.
                } else {
                    const newName = data.scriptName || null;
                    if (!wasRunning || state.runningFileName !== newName) {
                        state.runningFileName = newName;
                        state.runningTaskId = data.taskId || '__active__';
                        loadScriptFiles();
                    }
                    setRunButtonsState('running');
                    if (typeof window._syncVncOverlayPointer === 'function') {
                        window._syncVncOverlayPointer();
                    }
                }
            } else {
                if (wasRunning || _runBtnMode === 'pending') {
                    state.runningFileName = null;
                    state.runningTaskId = null;
                    loadScriptFiles();
                }
                setRunButtonsState('idle');
                if (typeof window._syncVncOverlayPointer === 'function') {
                    window._syncVncOverlayPointer();
                }
            }
        } catch (_) {
            // The app API and independent screen daemon have separate lifetimes.
            // Keep the last verified script state; the iframe owns stream recovery.
            // Contract: docs/WORKFLOW-ALWAYS-SCREEN-WEB-CONTRACT.md.
        }
        _stateBusy = false;
    }

    function _scheduleState() {
        if (_stateTimer) {
            clearTimeout(_stateTimer);
        }
        const delay = state.runningTaskId ? 400 : 2000;
        _stateTimer = setTimeout(async () => {
            await _pollState();
            _scheduleState();
        }, delay);
    }
    _scheduleState();

    setInterval(() => {
        if (document.visibilityState !== 'visible') {
            return;
        }
        const filesTab = document.querySelector('.tab[data-tab="files"]');
        if (filesTab && filesTab.classList.contains('active')) {
            loadScriptFiles();
        }
    }, 15000);

    const input = document.getElementById('quickCommand');
    const quickRunBtn = document.getElementById('quickRunBtn');

    const runQuick = () => {
        const cmd = input.value.trim();
        if (!cmd) {
            return;
        }
        const isMulti = cmd.includes(';') || cmd.includes('\n');
        const assignMatch = !isMulti && cmd.match(/^[a-zA-Z_][\w\s,]*?\s*=(?!=)\s*(.+)$/);
        const body = assignMatch ? assignMatch[1] : cmd.replace(/;\s*/g, '\n');
        const trimmed = body.trim();
        const isStmt = /^(print|let|if|while|for|fn|return|break|continue|repeat)\b/.test(trimmed);
        const isMultiline = trimmed.includes('\n');
        const wrapped =
            !isStmt && !isMultiline
                ? `let _r = ${trimmed}\nif _r == nil then print("✓ OK") else print("→", _r) end\n`
                : body + '\n';

        _runScriptUnified({
            code: wrapped,
            udid: state.currentDevice || 'local',
            scriptName: '',
        }).then((r) => {
            if (r.ok) {
                appendLog(`⚡ ${cmd}`);
            } else {
                appendLog(`✗ ${cmd} — ${r.detail || r.error || 'fail'}`);
            }
        });
        input.value = '';
    };

    input?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            runQuick();
        }
    });
    quickRunBtn?.addEventListener('click', runQuick);
}

/**
 * Append a single timestamped log line to `#consoleOutput`, intercepting
 * `__TOAST__|` messages to display floating toast notifications.
 */
function appendLog(message, type = '') {
    const output = document.getElementById('consoleOutput');

    if (typeof message === 'string' && message.includes('__TOAST__|')) {
        const parts = message.split('__TOAST__|')[1].split('|');
        const toastMsg = parts[0] || 'Toast';
        const toastDelay = parseFloat(parts[1]) || 2.0;
        show_toast(toastMsg, toastDelay * 1000);
        return;
    }

    const welcome = output.querySelector('.console-welcome');
    if (welcome) {
        welcome.remove();
    }

    const line = document.createElement('div');
    const timestamp = formatTime(new Date());

    if (message.includes('❌') || message.includes('Error')) {
        type = 'error';
    } else if (message.includes('✅')) {
        type = 'success';
    } else if (message.includes('▶️') || message.includes('📋')) {
        type = 'info';
    }

    line.className = `console-line ${type}`;
    line.innerHTML = `<span class="timestamp">${timestamp}</span>${_formatLogMsg(message)}`;

    output.appendChild(line);

    capConsoleDOMLines(output, 500);

    if (typeof lucide !== 'undefined') {
        lucide.createIcons({ attrs: {}, nameAttr: 'data-lucide' });
    }
    output.scrollTop = output.scrollHeight;

    _incrementConsoleBadge(1);
}

/**
 * Escape HTML in `msg` and replace known status emoji prefixes with inline
 * Lucide icon markup.
 */
function _formatLogMsg(msg) {
    let displayMsg = escapeHtml(msg);
    for (const [emoji, icon] of Object.entries(EMOJI_MAP)) {
        if (displayMsg.includes(emoji)) {
            displayMsg = displayMsg.replace(
                emoji,
                `<i data-lucide="${icon}" style="width:13px;height:13px;display:inline-block;vertical-align:-2px;margin-right:2px;"></i>`,
            );
        }
    }
    return displayMsg;
}

/**
 * Increment the unread log badge (`#consoleBadge`) when the console panel is
 * collapsed.
 */
function _incrementConsoleBadge(increment) {
    const panel = document.getElementById('consolePanel');
    if (!panel || panel.dataset.collapsed !== 'true') {
        return;
    }
    const badge = document.getElementById('consoleBadge');
    if (!badge) {
        return;
    }
    const currentCount = Number(badge.textContent);
    const count = (Number.isFinite(currentCount) ? currentCount : 0) + increment;
    badge.textContent = count > 99 ? '99+' : count;
    badge.style.display = 'inline';
}

// -----------------------------------------------------------------------------
// Console Panel Collapse & Drag Resizer
// -----------------------------------------------------------------------------

/**
 * Collapse or expand the bottom console drawer (`#consolePanel`) and relayout
 * the Monaco editor after the height transition completes.
 */
function toggleConsolePanel(forceOpen) {
    const panel = document.getElementById('consolePanel');
    const icon = document.getElementById('consoleToggleIcon');
    if (!panel) {
        return;
    }

    const isCollapsed = panel.dataset.collapsed === 'true';
    const shouldOpen = forceOpen !== undefined ? forceOpen : isCollapsed;

    panel.style.transition = 'height 0.3s cubic-bezier(0.4, 0, 0.2, 1)';

    if (shouldOpen) {
        panel.style.height = panel.dataset.prevHeight || '180px';
        panel.dataset.collapsed = 'false';
        if (icon) {
            icon.style.transform = 'rotate(180deg)';
        }
    } else {
        const h = panel.offsetHeight;
        if (h > 40) {
            panel.dataset.prevHeight = h + 'px';
        }
        panel.style.height = '32px';
        panel.dataset.collapsed = 'true';
        if (icon) {
            icon.style.transform = 'rotate(0deg)';
        }
    }
    setTimeout(() => {
        if (state.editor) {
            state.editor.layout();
        }
    }, 350);
}

/**
 * Attach vertical drag-to-resize and click-to-toggle handlers to the console
 * panel header (`#consolePanel .console-tab-header`).
 */
(function initConsoleDrag() {
    const cPanel = document.getElementById('consolePanel');
    const cHeader = document.querySelector('#consolePanel .console-tab-header');
    if (!cPanel || !cHeader) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initConsoleDrag);
        }
        return;
    }

    let cStartY;
    let cStartH;
    let hasDragged;
    let dragOverlay;

    cHeader.addEventListener('mousedown', (e) => {
        if (e.target.closest('button')) {
            return;
        }

        cStartY = e.clientY;
        cStartH = cPanel.offsetHeight;
        hasDragged = false;

        cPanel.style.transition = 'none';

        dragOverlay = document.createElement('div');
        dragOverlay.style.cssText =
            'position:fixed;top:0;left:0;right:0;bottom:0;z-index:9999;cursor:row-resize;';
        document.body.appendChild(dragOverlay);

        document.addEventListener('mousemove', onDrag);
        document.addEventListener('mouseup', onDragEnd);
        e.preventDefault();
    });

    function onDrag(e) {
        const delta = Math.abs(e.clientY - cStartY);
        if (delta < 5) {
            return;
        }

        hasDragged = true;
        const newH = cStartH - (e.clientY - cStartY);
        if (newH >= 32 && newH <= 400) {
            cPanel.style.height = newH + 'px';
            cPanel.dataset.collapsed = newH <= 36 ? 'true' : 'false';
            const icon = document.getElementById('consoleToggleIcon');
            if (icon) {
                icon.style.transform = newH <= 36 ? 'rotate(0deg)' : 'rotate(180deg)';
            }
            if (state.editor) {
                state.editor.layout();
            }
        }
    }

    function onDragEnd() {
        document.removeEventListener('mousemove', onDrag);
        document.removeEventListener('mouseup', onDragEnd);

        if (dragOverlay && dragOverlay.parentNode) {
            dragOverlay.parentNode.removeChild(dragOverlay);
            dragOverlay = null;
        }

        cPanel.style.transition = 'height 0.3s cubic-bezier(0.4, 0, 0.2, 1)';

        if (!hasDragged) {
            toggleConsolePanel();
        }
    }
})();

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.toggleConsolePanel = toggleConsolePanel;
