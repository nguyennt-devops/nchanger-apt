/**
 * @file app.browser.js — Installed iOS applications browser modal and Helper
 * Apps tab.
 *
 * Fetches installed application metadata and icons from `/apps` and `/app_icon`
 * to copy bundle identifiers or insert `switch_to_app("...")` statements.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Helper Panel Apps Tab
// -----------------------------------------------------------------------------

/**
 * Initialize the Helper panel's Apps tab (`#htabApps`), binding app list
 * loading, search filtering (`#hmAppSearch`), and refresh (`#hmRefreshApps`).
 */
function _initHelperAppsTab(ctx) {
    async function hmLoadApps() {
        const list = document.getElementById('hmAppList');
        if (!list) {
            return;
        }
        list.innerHTML =
            '<div style="color:#555; text-align:center; padding:20px 0; font-size:11px;">Loading...</div>';
        try {
            const appsRes = await fetch(`${API}/apps`).then((r) => r.json());
            const apps = appsRes.apps || [];
            let html = '';
            apps.forEach((app) => {
                const bg = 'rgba(255,255,255,0.04)';
                const iconUrl = `${API}/app_icon?bid=${encodeURIComponent(app.bundleId)}`;
                html += `<div class="hm-app-item" data-bid="${app.bundleId}" data-name="${(app.name || '').toLowerCase()}" style="display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius:6px; cursor:pointer; background:${bg}; transition:background 0.15s; margin-bottom:2px;" onclick="hmCopyBid('${app.bundleId}')" onmouseenter="this.style.background='rgba(129,140,248,0.16)'" onmouseleave="this.style.background='${bg}'">
          <img src="${iconUrl}" style="width:32px; height:32px; border-radius:7px; flex-shrink:0; background:rgba(255,255,255,0.06);" onerror="this.style.visibility='hidden'">
          <div style="min-width:0; flex:1;">
            <div style="font-size:13px; color:var(--text-primary); font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; line-height:1.3;">${app.name || app.bundleId}</div>
            <div style="font-size:11px; color:var(--text-secondary); font-family:var(--font-mono); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:2px;">${app.bundleId}</div>
          </div>
        </div>`;
            });
            list.innerHTML = html;
        } catch (e) {
            list.innerHTML = `<div style="color:var(--red); text-align:center; padding:16px; font-size:13px;">Failed</div>`;
        }
    }

    ctx.hmLoadApps = hmLoadApps;
    window.hmCopyBid = copyBundleId;

    document.getElementById('hmAppSearch')?.addEventListener('input', (e) => {
        const q = e.target.value.toLowerCase();
        document.querySelectorAll('.hm-app-item').forEach((el) => {
            const name = el.dataset.name || '';
            const bid = el.dataset.bid || '';
            el.style.display = name.includes(q) || bid.includes(q) ? 'block' : 'none';
        });
    });

    document.getElementById('hmRefreshApps')?.addEventListener('click', () => hmLoadApps());
}

// -----------------------------------------------------------------------------
// Installed Applications Modal
// -----------------------------------------------------------------------------

/**
 * Open `#appsModal`, fetch installed applications from `/apps`, and render them.
 */
async function showAppsModal() {
    const modal = document.getElementById('appsModal');
    const list = document.getElementById('appsList');
    if (!modal || !list) {
        return;
    }
    modal.style.display = 'flex';
    list.innerHTML = '<div class="helper-empty">Loading apps...</div>';

    try {
        const appsRes = await fetch(`${API}/apps`).then((r) => r.json());
        const apps = (appsRes.apps || [])
            .map((a) => ({
                name: a.name || a.bundleId || a.bundle_id,
                bundle_id: a.bundleId || a.bundle_id,
            }))
            .filter((a) => a.bundle_id);
        renderApps(apps);
    } catch (e) {
        list.innerHTML = `<div class="helper-empty">⚠️ ${e.message || 'Failed'}</div>`;
    }
}

/**
 * Render sorted application rows inside `#appsList` with Copy and Insert buttons.
 */
function renderApps(apps) {
    const list = document.getElementById('appsList');
    if (!apps.length) {
        list.innerHTML = '<div class="helper-empty">No apps found</div>';
        return;
    }

    apps.sort((a, b) => (a.name || '').localeCompare(b.name || ''));

    list.innerHTML = apps
        .map((app) => {
            const name = app.name || app.bundle_id;
            const bid = app.bundle_id;
            const icon = getAppEmoji(bid);
            return `<div class="app-item" title="${bid}">
            <div class="app-icon">${icon}</div>
            <div class="app-details">
                <div class="app-name">${escapeHtml(name)}</div>
                <div class="app-bundle">${escapeHtml(bid)}</div>
            </div>
            <div class="app-actions hm-row-btns">
                <button type="button" class="hm-btn-copy" onclick="event.stopPropagation();copyBundleId('${bid}')">${_t('hmBtnCopy')}</button>
                <button type="button" class="hm-btn-insert" onclick="event.stopPropagation();insertAppRun('${bid}')">${_t('hmBtnInsert')}</button>
            </div>
        </div>`;
        })
        .join('');
}

/** Return a representative emoji icon for system `com.apple.*` bundle IDs. */
function getAppEmoji(bundleId) {
    const map = {
        'com.apple.Preferences': '⚙️',
        'com.apple.mobilesafari': '🧭',
        'com.apple.MobileSMS': '💬',
        'com.apple.mobilephone': '📞',
        'com.apple.camera': '📷',
        'com.apple.mobileslideshow': '🖼️',
        'com.apple.AppStore': '🏪',
        'com.apple.Maps': '🗺️',
        'com.apple.mobiletimer': '⏰',
        'com.apple.mobilenotes': '📝',
        'com.apple.mobilecal': '📅',
        'com.apple.mobilemail': '📧',
        'com.apple.Music': '🎵',
        'com.apple.Health': '❤️',
        'com.apple.weather': '🌤️',
        'com.apple.calculator': '🔢',
        'com.apple.Fitness': '🏃',
        'com.apple.shortcuts': '⚡',
    };
    return map[bundleId] || '📦';
}

/** Copy `bundleId` to the clipboard and log it to the console. */
function copyBundleId(bundleId) {
    _hmDoCopy(bundleId);
}

/** Insert a `switch_to_app("<bundleId>")` call into the editor and close `#appsModal`. */
function insertAppRun(bundleId) {
    insertEditorText(`switch_to_app(${_hmAlangStr(bundleId)})\n`);
    closeAppsModal();
}

/** Hide `#appsModal`. */
function closeAppsModal() {
    const modal = document.getElementById('appsModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

document.addEventListener('click', (e) => {
    if (e.target.id === 'appsModal') {
        closeAppsModal();
    }
});

document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') {
        return;
    }
    const m = document.getElementById('appsModal');
    if (m && m.style.display !== 'none') {
        closeAppsModal();
        return;
    }
    document
        .querySelectorAll('.modal-overlay.visible')
        .forEach((el) => el.classList.remove('visible'));
});

// -----------------------------------------------------------------------------
// Global Exports
// -----------------------------------------------------------------------------

window.showAppsModal = showAppsModal;
window.closeAppsModal = closeAppsModal;
window.copyBundleId = copyBundleId;
window.insertAppRun = insertAppRun;
