/**
 * @file helper.pickers.js — Interactive Helper value pickers: random list/email
 * generator, OCR text scanner, Safari DOM element picker/modal, and
 * Accessibility (AX) UI control scanner.
 *
 * Communicates with `POST /api/ocr`, `POST /api/safari/scan`, and
 * `POST /api/ax/scan`.
 *
 * Contract: docs/WORKFLOW-WEB-IDE-MODULAR-SPLIT-20261106.md
 */

// -----------------------------------------------------------------------------
// Random List & Random Email Expression Generator
// -----------------------------------------------------------------------------

/**
 * Open a popover anchored below `input` to configure either a random string
 * list (`random_pick([...])`) or a randomized email expression
 * (`random_string(...) .. "@" .. random_pick([...])`).
 */
function helperPickRandomList(input, fields, argName, updateCode) {
    const existing = document.getElementById('zxRandomDropdown');
    if (existing) {
        existing.remove();
    }
    const rect = input.getBoundingClientRect();
    const wrap = document.createElement('div');
    wrap.id = 'zxRandomDropdown';
    wrap.style.cssText = `position:fixed; left:${rect.left}px; top:${rect.bottom + 4}px; min-width:${Math.max(rect.width, 340)}px; max-width:500px; background:rgba(17,21,44,0.97); backdrop-filter:blur(20px); border:1px solid rgba(129,140,248,0.4); border-radius:8px; padding:10px; z-index:99999; box-shadow:0 8px 32px rgba(5,7,18,0.55); display:flex; flex-direction:column; gap:8px;`;
    wrap.innerHTML = `
    <div style="display:flex; gap:4px;">
      <button data-mode="list" class="zxRandTab" style="flex:1; padding:6px; background:var(--accent); color:#fff; border:none; border-radius:5px; font-size:11px; font-weight:600; cursor:pointer;">${_t('randTabList')}</button>
      <button data-mode="email" class="zxRandTab" style="flex:1; padding:6px; background:rgba(255,255,255,0.06); color:#94a3b8; border:none; border-radius:5px; font-size:11px; font-weight:600; cursor:pointer;">${_t('randTabEmail')}</button>
    </div>
    <div id="zxRandPanelList" style="display:flex; flex-direction:column; gap:6px;">
      <div style="font-size:11px; color:#94a3b8;">${_t('randListHint')}</div>
      <textarea id="zxRandomItems" rows="5" placeholder="abc\nxyz\nhello world" style="width:100%; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:8px 10px; color:var(--text-primary); font-family:var(--font-mono); font-size:13px; outline:none; resize:vertical; box-sizing:border-box;"></textarea>
    </div>
    <div id="zxRandPanelEmail" style="display:none; flex-direction:column; gap:6px;">
      <div style="font-size:11px; color:#94a3b8;">${_t('randPrefixHint')}</div>
      <textarea id="zxRandEmailCharset" rows="2" style="width:100%; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:8px 10px; color:var(--text-primary); font-family:var(--font-mono); font-size:13px; outline:none; resize:vertical; box-sizing:border-box;">abcdefghijklmnopqrstuvwxyz0123456789</textarea>
      <div style="display:flex; gap:6px; align-items:center;">
        <span style="font-size:11px; color:#94a3b8;">${_t('randLen')}</span>
        <input id="zxRandEmailLenMin" type="number" value="8" min="1" max="50" style="width:60px; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:6px; color:var(--text-primary); font-size:12px; box-sizing:border-box;">
        <span style="font-size:11px; color:#94a3b8;">→</span>
        <input id="zxRandEmailLenMax" type="number" value="15" min="1" max="50" style="width:60px; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:6px; color:var(--text-primary); font-size:12px; box-sizing:border-box;">
        <span style="font-size:11px; color:#94a3b8;">${_t('randChars')}</span>
      </div>
      <div style="font-size:11px; color:#94a3b8; margin-top:4px;">${_t('randDomainHint')}</div>
      <textarea id="zxRandEmailDom" rows="3" placeholder="gmail.com\nyahoo.com\noutlook.com" style="width:100%; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:8px 10px; color:var(--text-primary); font-family:var(--font-mono); font-size:13px; outline:none; resize:vertical; box-sizing:border-box;">gmail.com\nyahoo.com\noutlook.com</textarea>
    </div>
    <div style="display:flex; gap:6px; justify-content:flex-end;">
      <button id="zxRandomCancel" style="padding:6px 12px; background:transparent; border:1px solid var(--border-color); border-radius:6px; color:#94a3b8; font-size:12px; font-weight:600; cursor:pointer;">${_t('imgCancel')}</button>
      <button type="button" id="zxRandomOk" class="hm-btn-insert">${_t('hmBtnInsert')}</button>
    </div>`;
    document.body.appendChild(wrap);
    document.getElementById('zxRandEmailDom').value = 'gmail.com\nyahoo.com\noutlook.com';

    let mode = 'list';
    const panels = {
        list: document.getElementById('zxRandPanelList'),
        email: document.getElementById('zxRandPanelEmail'),
    };
    wrap.querySelectorAll('.zxRandTab').forEach((btn) => {
        btn.addEventListener('click', () => {
            mode = btn.dataset.mode;
            wrap.querySelectorAll('.zxRandTab').forEach((b) => {
                b.style.background = b === btn ? 'var(--accent)' : 'rgba(255,255,255,0.06)';
                b.style.color = b === btn ? '#fff' : '#94a3b8';
            });
            Object.entries(panels).forEach(([k, p]) => {
                p.style.display = k === mode ? 'flex' : 'none';
            });
        });
    });

    const qstr = (s) => '"' + s.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
    const pickExpr = (arr) =>
        arr.length === 1 ? qstr(arr[0]) : `random_pick([${arr.map(qstr).join(', ')}])`;
    const randExpr = (charset, mn, mx) =>
        mn === mx
            ? `random_string(${qstr(charset)}, ${mn})`
            : `random_string(${qstr(charset)}, ${mn}, ${mx})`;
    const close = () => wrap.remove();

    document.getElementById('zxRandomCancel').onclick = close;
    document.getElementById('zxRandomOk').onclick = () => {
        let expr = '';
        if (mode === 'list') {
            const items = document
                .getElementById('zxRandomItems')
                .value.split('\n')
                .map((s) => s.trim())
                .filter(Boolean);
            if (!items.length) {
                close();
                return;
            }
            expr = pickExpr(items);
        } else {
            const cs = document
                .getElementById('zxRandEmailCharset')
                .value.replace(/\n/g, '')
                .trim();
            const mn = parseInt(document.getElementById('zxRandEmailLenMin').value) || 8;
            const mx = parseInt(document.getElementById('zxRandEmailLenMax').value) || mn;
            const doms = document
                .getElementById('zxRandEmailDom')
                .value.split('\n')
                .map((s) => s.trim())
                .filter(Boolean);
            if (!cs || !doms.length) {
                close();
                return;
            }
            const letters = cs.replace(/[^a-zA-Z]/g, '') || cs;
            const lo = Math.min(mn, mx);
            const hi = Math.max(mn, mx);
            const headExpr = `random_string(${qstr(letters)}, 1)`;
            const tailExpr =
                lo === hi
                    ? `random_string(${qstr(cs)}, ${lo - 1})`
                    : `random_string(${qstr(cs)}, ${lo - 1}, ${hi - 1})`;
            expr = headExpr + ' .. ' + tailExpr + ' .. "@" .. ' + pickExpr(doms);
        }
        input.value = expr;
        fields[argName] = expr;
        if (updateCode) {
            updateCode();
        }
        close();
    };
}

// -----------------------------------------------------------------------------
// OCR, Safari DOM & Accessibility (AX) Dropdown Pickers
// -----------------------------------------------------------------------------

/**
 * Scan the full device screen via OCR (`POST /api/ocr`) and present recognized
 * text items in a dropdown below `input`.
 */
async function helperPickTextFromOcr(input, fields, argName, updateCode) {
    const screenW =
        (state.wdaPoints && state.wdaPoints.w) ||
        (state.screenInfo && state.screenInfo.pointWidth) ||
        390;
    const screenH =
        (state.wdaPoints && state.wdaPoints.h) ||
        (state.screenInfo && state.screenInfo.pointHeight) ||
        844;
    return _helperOcrShowDropdown(input, fields, argName, updateCode, {
        x: 0,
        y: 0,
        w: screenW,
        h: screenH,
    });
}

/**
 * Request OCR results for `region` from `POST /api/ocr` and populate `input`
 * when the user selects a recognized text line.
 */
async function _helperOcrShowDropdown(input, fields, argName, updateCode, region) {
    const existing = document.getElementById('zxOcrDropdown');
    if (existing) {
        existing.remove();
    }
    const dropdown = document.createElement('div');
    dropdown.id = 'zxOcrDropdown';
    const rect = input.getBoundingClientRect();
    dropdown.style.cssText = `position:fixed; left:${rect.left}px; top:${rect.bottom + 4}px; min-width:${rect.width}px; max-width:400px; max-height:280px; overflow:auto; background:rgba(17,21,44,0.96); backdrop-filter:blur(20px); border:1px solid rgba(129,140,248,0.4); border-radius:8px; padding:6px; z-index:99999; box-shadow:0 8px 32px rgba(5,7,18,0.55);`;
    dropdown.innerHTML = `<div style="padding:8px; color:#9aa5ce; font-size:12px;">📖 Đang quét vùng ${region.w}x${region.h}…</div>`;
    document.body.appendChild(dropdown);

    const closeDropdown = (e) => {
        if (e && (e.target === input || dropdown.contains(e.target))) {
            return;
        }
        dropdown.remove();
        document.removeEventListener('mousedown', closeDropdown, true);
    };
    setTimeout(() => document.addEventListener('mousedown', closeDropdown, true), 100);

    try {
        const res = await fetch(`${API}/api/ocr`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(region),
        });
        const data = await res.json();
        if (!data.ok) {
            dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${data.error || 'OCR fail'}</div>`;
            return;
        }
        const items = data.items || [];
        if (!items.length) {
            dropdown.innerHTML = `<div style="padding:8px; color:#9aa5ce; font-size:12px;">Không thấy chữ nào trên màn hình.</div>`;
            return;
        }
        dropdown.innerHTML = '';
        items.forEach((it) => {
            const opt = document.createElement('div');
            opt.style.cssText =
                'padding:8px 10px; color:#eef2ff; font-size:13px; cursor:pointer; border-radius:4px; display:flex; justify-content:space-between; align-items:center; gap:8px;';
            opt.innerHTML = `<span style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${it.text.replace(/</g, '&lt;')}</span><span style="color:#647099; font-size:10px; font-family:monospace;">${it.x},${it.y}</span>`;
            opt.onmouseenter = () => {
                opt.style.background = 'rgba(129,140,248,0.2)';
            };
            opt.onmouseleave = () => {
                opt.style.background = 'transparent';
            };
            opt.onclick = () => {
                const quoted = '"' + it.text.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
                input.value = quoted;
                fields[argName] = quoted;
                if (updateCode) {
                    updateCode();
                }
                dropdown.remove();
            };
            dropdown.appendChild(opt);
        });
    } catch (e) {
        dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${e.message}</div>`;
    }
}

/**
 * Scan interactive DOM elements on the active Safari page via
 * `POST /api/safari/scan` and populate `input` with the selected label.
 */
async function helperPickFromSafariDOM(input, fields, argName, updateCode, mode) {
    const existing = document.getElementById('zxDomDropdown');
    if (existing) {
        existing.remove();
    }
    const dropdown = document.createElement('div');
    dropdown.id = 'zxDomDropdown';
    const rect = input.getBoundingClientRect();
    dropdown.style.cssText = `position:fixed; left:${rect.left}px; top:${rect.bottom + 4}px; min-width:${Math.max(rect.width, 280)}px; max-width:480px; max-height:320px; overflow:auto; background:rgba(17,21,44,0.96); backdrop-filter:blur(20px); border:1px solid rgba(129,140,248,0.4); border-radius:8px; padding:6px; z-index:99999; box-shadow:0 8px 32px rgba(5,7,18,0.55);`;
    dropdown.innerHTML = `<div style="padding:8px; color:#9aa5ce; font-size:12px;">🌐 Đang quét trang Safari…</div>`;
    document.body.appendChild(dropdown);

    const closeDropdown = (e) => {
        if (e && (e.target === input || dropdown.contains(e.target))) {
            return;
        }
        dropdown.remove();
        document.removeEventListener('mousedown', closeDropdown, true);
    };
    setTimeout(() => document.addEventListener('mousedown', closeDropdown, true), 100);

    try {
        const res = await fetch(`${API}/api/safari/scan`, { method: 'POST' });
        const data = await res.json();
        if (!data.ok) {
            dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${data.error || 'Scan fail'}</div>`;
            return;
        }
        const items = data.items || [];
        if (!items.length) {
            dropdown.innerHTML = `<div style="padding:8px; color:#9aa5ce; font-size:12px;">Không thấy ô/nút nào — mở Safari + load 1 trang rồi thử lại.</div>`;
            return;
        }
        dropdown.innerHTML = '';
        const kindIcon = {
            email: '📧',
            password: '🔒',
            text: '📝',
            search: '🔎',
            tel: '📞',
            number: '#',
            checkbox: '☐',
            radio: '○',
            submit: '✅',
            button: '🔘',
            link: '🔗',
            textarea: '📄',
            select: '▾',
        };
        items.forEach((it) => {
            const opt = document.createElement('div');
            opt.style.cssText =
                'padding:8px 10px; color:#eef2ff; font-size:13px; cursor:pointer; border-radius:4px; display:flex; gap:8px; align-items:center;';
            const ic = kindIcon[it.kind] || '•';
            opt.innerHTML = `<span style="font-size:14px; width:18px;">${ic}</span><span style="flex:1; overflow:hidden;"><div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${(it.label || '(no label)').replace(/</g, '&lt;')}</div><div style="color:#647099; font-size:10px; font-family:monospace; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${(it.sel || '').replace(/</g, '&lt;')}</div></span>`;
            opt.onmouseenter = () => {
                opt.style.background = 'rgba(129,140,248,0.2)';
            };
            opt.onmouseleave = () => {
                opt.style.background = 'transparent';
            };
            opt.onclick = () => {
                const pick = it.label || '';
                const quoted = '"' + pick.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
                input.value = quoted;
                fields[argName] = quoted;
                if (updateCode) {
                    updateCode();
                }
                dropdown.remove();
            };
            dropdown.appendChild(opt);
        });
    } catch (e) {
        dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${e.message}</div>`;
    }
}

/**
 * Scan Accessibility (AX) controls in the foreground app via `POST /api/ax/scan`
 * and populate both `input` and the optional `byInput` (`"button"`, `"text"`,
 * `"field"`, or `"any"`).
 */
async function helperPickFromAX(input, fields, argName, updateCode, byInput) {
    // Render an interactive dropdown matching the OCR picker layout, displaying
    // control kind badges to disambiguate duplicate labels.
    const existing = document.getElementById('zxAxDropdown');
    if (existing) {
        existing.remove();
    }
    const dropdown = document.createElement('div');
    dropdown.id = 'zxAxDropdown';
    const rect = input.getBoundingClientRect();
    dropdown.style.cssText = `position:fixed; left:${rect.left}px; top:${rect.bottom + 4}px; min-width:${Math.max(rect.width, 320)}px; max-width:440px; max-height:320px; overflow:auto; background:rgba(30,36,46,0.96); backdrop-filter:blur(20px); border:1px solid rgba(255,255,255,0.12); border-radius:8px; padding:6px; z-index:99999; box-shadow:0 8px 32px rgba(0,0,0,0.42);`;
    dropdown.innerHTML = `<div style="padding:8px; color:#a3b1c6; font-size:12px;">👁 Đang quét UI…</div>`;
    document.body.appendChild(dropdown);

    const closeDropdown = (e) => {
        if (e && (e.target === input || dropdown.contains(e.target))) {
            return;
        }
        dropdown.remove();
        document.removeEventListener('mousedown', closeDropdown, true);
    };
    setTimeout(() => document.addEventListener('mousedown', closeDropdown, true), 100);

    try {
        const res = await fetch(`${API}/api/ax/scan`, { method: 'POST' });
        const data = await res.json();
        if (!data.ok) {
            dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${data.error || 'Scan fail'}</div>`;
            return;
        }
        const items = data.items || [];
        if (!items.length) {
            dropdown.innerHTML = `<div style="padding:8px; color:#9aa5ce; font-size:12px;">Không thấy nút/ô trên app đang mở.</div>`;
            return;
        }
        dropdown.innerHTML = '';
        const kindIcon = { button: '🔘', text: '📝', field: '✏️', other: '•' };
        const kindVi = { button: 'nút', text: 'chữ', field: 'ô', other: 'khác' };
        items.forEach((it) => {
            const text = (it.text || it.label || it.id || '').toString();
            if (!text.trim()) {
                return;
            }
            let kind = (it.kind || '').toString();
            if (!kind) {
                if (it.button) {
                    kind = 'button';
                } else if (it.field) {
                    kind = 'field';
                } else {
                    kind = 'other';
                }
            }
            const x = it.x ?? it.cx ?? 0;
            const y = it.y ?? it.cy ?? 0;
            const opt = document.createElement('div');
            opt.style.cssText =
                'padding:8px 10px; color:#eef2ff; font-size:13px; cursor:pointer; border-radius:4px; display:flex; align-items:center; gap:8px;';
            const ic = kindIcon[kind] || '•';
            const kv = kindVi[kind] || kind;
            opt.innerHTML =
                `<span style="font-size:14px; width:18px; flex-shrink:0;">${ic}</span>` +
                `<span style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${text.replace(/</g, '&lt;')}</span>` +
                `<span style="color:#a5b4fc; font-size:10px; flex-shrink:0;">${kv}</span>` +
                `<span style="color:#647099; font-size:10px; font-family:monospace; flex-shrink:0;">${x},${y}</span>`;
            opt.onmouseenter = () => {
                opt.style.background = 'rgba(129,140,248,0.2)';
            };
            opt.onmouseleave = () => {
                opt.style.background = 'transparent';
            };
            opt.onclick = () => {
                const pick = (it.label || it.text || it.id || '').toString().trim();
                const quoted = '"' + pick.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
                input.value = quoted;
                fields[argName] = quoted;
                const byTok =
                    kind === 'button' || kind === 'text' || kind === 'field' ? kind : 'any';
                const byQuoted = '"' + byTok + '"';
                fields.by = byQuoted;
                if (byInput) {
                    byInput.value = byQuoted;
                }
                if (updateCode) {
                    updateCode();
                }
                dropdown.remove();
            };
            dropdown.appendChild(opt);
        });
    } catch (e) {
        dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${e.message}</div>`;
    }
}

/**
 * Read-only native/WebView inventory of the foreground app. Selecting an entry
 * updates app_fill's locator/kind only; execution remains the user's next action.
 * Contract: docs/CONTRACT-APP-SELECTION-20261112.md.
 */
async function helperPickFromApp(input, fields, argName, updateCode, kindInput) {
    document.getElementById('zxAppDropdown')?._appClose?.();
    const dropdown = document.createElement('div');
    dropdown.id = 'zxAppDropdown';
    const rect = input.getBoundingClientRect();
    dropdown.style.cssText = `position:fixed; left:${rect.left}px; top:${rect.bottom + 4}px; min-width:${Math.max(rect.width, 320)}px; max-width:440px; max-height:320px; overflow:auto; background:rgba(30,36,46,0.96); backdrop-filter:blur(20px); border:1px solid rgba(255,255,255,0.12); border-radius:8px; padding:6px; z-index:99999; box-shadow:0 8px 32px rgba(0,0,0,0.42);`;
    const message = (text) => {
        const row = document.createElement('div');
        row.style.cssText = 'padding:8px; color:#a3b1c6; font-size:12px;';
        row.textContent = text;
        dropdown.appendChild(row);
    };
    message(_t('hmAppScanning'));
    document.body.appendChild(dropdown);
    const controller = new AbortController();
    const close = () => {
        controller.abort();
        dropdown.remove();
        document.removeEventListener('mousedown', outside, true);
    };
    dropdown._appClose = close;
    const outside = (event) => {
        if (event.target !== input && !dropdown.contains(event.target)) close();
    };
    document.addEventListener('mousedown', outside, true);
    try {
        const response = await fetch(`${API}/api/app/scan`, {
            method: 'POST',
            signal: controller.signal,
        });
        const data = await response.json();
        if (!dropdown.isConnected) return;
        dropdown.replaceChildren();
        if (!response.ok || !data.ok) {
            message(data.error || _t('hmAppError'));
            return;
        }
        const items = Array.isArray(data.items) ? data.items : [];
        if (!items.length) {
            message(_t('hmAppEmpty'));
            return;
        }
        if (items.some((item) => item.partial)) message(_t('hmAppPartial'));
        items.forEach((item) => {
            const row = document.createElement('button');
            row.type = 'button';
            row.disabled = !item.selectable;
            row.style.cssText =
                'display:block; width:100%; padding:8px 10px; text-align:left; color:#eef2ff; background:transparent; border:0; border-radius:4px; font-size:12px; cursor:pointer;';
            row.textContent = `${item.label} · ${item.source}${item.selectable ? '' : item.editable ? ' · ' + _t('hmAppAmbiguous') : ' · ' + _t('hmAppReadonly')}`;
            row.title = item.target || '';
            if (!item.selectable) row.style.opacity = '0.5';
            row.onmouseenter = () => {
                row.style.background = 'rgba(255,255,255,0.1)';
            };
            row.onmouseleave = () => {
                row.style.background = 'transparent';
            };
            row.onclick = () => {
                const literal = JSON.stringify(item.target);
                input.value = literal;
                fields[argName] = literal;
                fields.kind = JSON.stringify(item.kind);
                if (kindInput) kindInput.value = fields.kind;
                if (updateCode) updateCode();
                close();
            };
            dropdown.appendChild(row);
        });
    } catch (error) {
        if (error.name !== 'AbortError' && dropdown.isConnected) {
            dropdown.replaceChildren();
            message(error.message);
        }
    }
}

// -----------------------------------------------------------------------------
// Full Safari DOM Scanner Modal
// -----------------------------------------------------------------------------

/**
 * Open the standalone Safari DOM scanner modal (`#zxSafariModal`), allowing
 * the user to filter scanned inputs/buttons and insert `web_fill`, `web_click`,
 * `web_long_press`, or `web_wait` statements by label or CSS selector.
 */
async function openSafariScanModal() {
    const existing = document.getElementById('zxSafariModal');
    if (existing) {
        existing.remove();
    }
    const overlay = document.createElement('div');
    overlay.id = 'zxSafariModal';
    overlay.style.cssText =
        'position:fixed; inset:0; background:rgba(0,0,0,0.62); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;';
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            overlay.remove();
        }
    });

    const box = document.createElement('div');
    box.style.cssText =
        'background:rgba(30,36,46,0.98); border:1px solid rgba(255,255,255,0.12); border-radius:12px; width:min(720px,100%); max-height:80vh; display:flex; flex-direction:column; box-shadow:0 12px 48px rgba(0,0,0,0.48);';

    const head = document.createElement('div');
    head.style.cssText =
        'padding:14px 18px; border-bottom:1px solid rgba(255,255,255,0.08); display:flex; justify-content:space-between; align-items:center;';
    head.innerHTML = `<div style="color:#f1f5f9; font-size:15px; font-weight:600;">🌐 Quét Safari — Chọn ô/nút + hành động</div>`;
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '✕';
    closeBtn.style.cssText =
        'background:transparent; color:#a3b1c6; border:none; font-size:18px; cursor:pointer;';
    closeBtn.addEventListener('click', () => overlay.remove());
    head.appendChild(closeBtn);
    box.appendChild(head);

    const toolbar = document.createElement('div');
    toolbar.style.cssText =
        'padding:10px 18px; border-bottom:1px solid rgba(255,255,255,0.08); display:flex; gap:8px; align-items:center;';
    const refreshBtn = document.createElement('button');
    refreshBtn.textContent = '🔄 Quét lại';
    refreshBtn.className = 'hm-pick';
    const filterInput = document.createElement('input');
    filterInput.placeholder = 'Lọc theo tên/selector…';
    filterInput.style.cssText =
        'flex:1; background:rgba(22,27,34,0.8); border:1px solid rgba(255,255,255,0.12); color:#f1f5f9; border-radius:6px; padding:7px 10px; font-size:12px;';
    const advBtn = document.createElement('button');
    advBtn.textContent = '⚙️ Nâng cao';
    advBtn.title = 'Sinh code dùng selector (chính xác hơn khi có nhiều mục trùng tên)';
    advBtn.style.cssText =
        'background:rgba(129,140,248,0.08); color:#9aa5ce; border:1px solid rgba(129,140,248,0.2); border-radius:6px; padding:7px 12px; cursor:pointer; font-size:12px; font-weight:600;';
    advBtn.addEventListener('click', () => {
        advMode = !advMode;
        advBtn.style.background = advMode ? 'var(--accent)' : 'rgba(129,140,248,0.08)';
        advBtn.style.color = advMode ? '#fff' : '#9aa5ce';
        if (listBox._items) {
            render(listBox._items);
        }
    });
    toolbar.appendChild(refreshBtn);
    toolbar.appendChild(filterInput);
    toolbar.appendChild(advBtn);
    box.appendChild(toolbar);

    const listBox = document.createElement('div');
    listBox.style.cssText = 'overflow-y:auto; flex:1; padding:6px;';
    box.appendChild(listBox);
    overlay.appendChild(box);
    document.body.appendChild(overlay);

    const escTxt = (s) => (s || '').replace(/"/g, '\\"');
    const escSel = (s) => (s || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    const ACTIONS_INPUT_SIMPLE = [
        {
            label: () => _l('📝 Fill', '📝 Điền', '📝 填入'),
            code: (it) => `web_fill("${escTxt(it.label)}", "TEXT", "field")`,
        },
        {
            label: () => _l('⏳ Wait', '⏳ Chờ hiện', '⏳ 等待'),
            code: (it) => `web_wait("${escTxt(it.label)}", "field")`,
        },
    ];
    const ACTIONS_BUTTON_SIMPLE = [
        {
            label: () => _l('👆 Click', '👆 Bấm', '👆 点击'),
            code: (it) => `web_click("${escTxt(it.label)}", "button")`,
        },
        {
            label: () => _l('✊ Hold 10s', '✊ Giữ 10s', '✊ 长按10秒'),
            code: (it) => `web_long_press("${escTxt(it.label)}", 10)`,
        },
        {
            label: () => _l('✊ Until gone', '✊ Giữ đến mất', '✊ 按到消失'),
            code: (it) => `web_long_press("${escTxt(it.label)}", "gone", 20)`,
        },
        {
            label: () => _l('⏳ Wait', '⏳ Chờ hiện', '⏳ 等待'),
            code: (it) => `web_wait("${escTxt(it.label)}", "button")`,
        },
    ];
    const ACTIONS_INPUT_ADV = [
        {
            label: () => _l('📝 Fill', '📝 Điền', '📝 填入'),
            code: (it) => `web_fill("${escSel(it.sel)}", "TEXT", "field")`,
        },
        {
            label: () => _l('⏳ Wait', '⏳ Chờ hiện', '⏳ 等待'),
            code: (it) => `web_wait("${escSel(it.sel)}", "field")`,
        },
    ];
    const ACTIONS_BUTTON_ADV = [
        {
            label: () => _l('👆 Click', '👆 Bấm', '👆 点击'),
            code: (it) => `web_click("${escSel(it.sel)}", "button")`,
        },
        {
            label: () => _l('✊ Hold 10s', '✊ Giữ 10s', '✊ 长按10秒'),
            code: (it) => `web_long_press("${escSel(it.sel)}", 10)`,
        },
        {
            label: () => _l('✊ Until gone', '✊ Giữ đến mất', '✊ 按到消失'),
            code: (it) => `web_long_press("${escSel(it.sel)}", "gone", 20)`,
        },
        {
            label: () => _l('⏳ Wait', '⏳ Chờ hiện', '⏳ 等待'),
            code: (it) => `web_wait("${escSel(it.sel)}", "button")`,
        },
    ];
    let advMode = false;

    function render(items) {
        listBox.innerHTML = '';
        if (!items.length) {
            listBox.innerHTML = `<div style="padding:16px; color:#94a3b8; font-size:13px; text-align:center;">Không thấy ô/nút nào — mở Safari + load 1 trang rồi bấm Quét lại.</div>`;
            return;
        }
        const kindIcon = {
            email: '📧',
            password: '🔒',
            text: '📝',
            search: '🔎',
            tel: '📞',
            number: '#',
            checkbox: '☐',
            radio: '○',
            submit: '✅',
            button: '🔘',
            link: '🔗',
            textarea: '📄',
            select: '▾',
        };
        items.forEach((it) => {
            const row = document.createElement('div');
            row.style.cssText =
                'padding:10px 12px; border-bottom:1px solid rgba(129,140,248,0.08); display:flex; flex-direction:column; gap:6px;';
            const ic = kindIcon[it.kind] || '•';
            row.innerHTML = `<div style="display:flex; gap:8px; align-items:center;"><span style="font-size:14px; width:18px;">${ic}</span><div style="flex:1; min-width:0;"><div style="color:#eef2ff; font-size:13px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${(it.label || '(no label)').replace(/</g, '&lt;')}</div><div style="color:#647099; font-size:10px; font-family:monospace; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${(it.sel || '').replace(/</g, '&lt;')}</div></div></div>`;
            const btnRow = document.createElement('div');
            btnRow.style.cssText = 'display:flex; flex-wrap:wrap; gap:6px; padding-left:26px;';
            const isInput =
                [
                    'text',
                    'email',
                    'password',
                    'search',
                    'tel',
                    'number',
                    'textarea',
                    'select',
                    'field',
                ].indexOf(it.kind) >= 0;
            const actions = advMode
                ? isInput
                    ? ACTIONS_INPUT_ADV
                    : ACTIONS_BUTTON_ADV
                : isInput
                  ? ACTIONS_INPUT_SIMPLE
                  : ACTIONS_BUTTON_SIMPLE;
            actions.forEach((a) => {
                const b = document.createElement('button');
                b.textContent = typeof a.label === 'function' ? a.label() : a.label;
                b.style.cssText =
                    'background:rgba(129,140,248,0.18); color:#a5b4fc; border:1px solid rgba(129,140,248,0.34); border-radius:5px; padding:5px 9px; cursor:pointer; font-size:11px; font-weight:600;';
                b.addEventListener('click', () => {
                    insertEditorText(a.code(it));
                });
                btnRow.appendChild(b);
            });
            row.appendChild(btnRow);
            listBox.appendChild(row);
        });
    }

    async function loadScan() {
        listBox.innerHTML = `<div style="padding:16px; color:#94a3b8; font-size:13px; text-align:center;">🌐 Đang quét trang Safari…</div>`;
        try {
            const res = await fetch(`${API}/api/safari/scan`, { method: 'POST' });
            const data = await res.json();
            if (!data.ok) {
                listBox.innerHTML = `<div style="padding:16px; color:#f87171; font-size:13px;">❌ ${data.error || 'Scan fail'} — mở Safari + load 1 trang rồi thử lại.</div>`;
                return;
            }
            const items = data.items || [];
            listBox._items = items;
            render(items);
        } catch (e) {
            listBox.innerHTML = `<div style="padding:16px; color:#f87171; font-size:13px;">❌ ${e.message}</div>`;
        }
    }

    refreshBtn.addEventListener('click', loadScan);
    filterInput.addEventListener('input', () => {
        const q = filterInput.value.toLowerCase().trim();
        if (!listBox._items) {
            return;
        }
        render(
            q
                ? listBox._items.filter((it) =>
                      ((it.label || '') + ' ' + (it.sel || '')).toLowerCase().includes(q),
                  )
                : listBox._items,
        );
    });
    loadScan();
}
