/* Independent dropdown adapter. CONTRACT-APP-DROPDOWN-20261112.md.
 * Host drives asynchronous phases; only an owned option can receive a click.
 */
(function (request) {
    'use strict';
    const result = (extra) => Object.assign({ protocol: 'app_dropdown', version: 1 }, extra);
    const normalize = (value) =>
        String(value == null ? '' : value)
            .replace(/\s+/g, ' ')
            .trim();
    const equal = (left, right) => normalize(left).toLowerCase() === normalize(right).toLowerCase();
    const stateKey = '__iosautoDropdownV1';
    const states = window[stateKey] || new Map();
    if (!window[stateKey])
        Object.defineProperty(window, stateKey, { value: states, configurable: true });
    for (const [key, value] of states) if (value.expires <= Date.now()) states.delete(key);
    const fail = (error) => {
        states.delete(request.token);
        return result({ ok: false, error });
    };
    const done = (via) => {
        states.delete(request.token);
        return result({ ok: true, verified: true, via });
    };
    const pending = (next) => result({ ok: true, pending: true, next });
    if (Date.now() >= request.expires * 1000) return fail('expired');
    function visible(element) {
        if (!element || !element.isConnected || !element.getClientRects().length) return false;
        for (let node = element, depth = 0; node && depth < 64; depth++) {
            const style = node.ownerDocument.defaultView.getComputedStyle(node);
            if (
                style.display === 'none' ||
                style.visibility === 'hidden' ||
                Number(style.opacity) === 0 ||
                node.inert ||
                node.getAttribute('aria-hidden') === 'true'
            )
                return false;
            node = node.parentElement || node.getRootNode().host;
        }
        return true;
    }
    function disabled(element) {
        return !!(
            element.disabled ||
            element.readOnly ||
            element.getAttribute('aria-disabled') === 'true' ||
            element.getAttribute('aria-readonly') === 'true' ||
            element.closest('[inert],optgroup:disabled,[aria-disabled="true"]')
        );
    }
    function name(element) {
        const root = element.getRootNode();
        const labelled = (element.getAttribute('aria-labelledby') || '')
            .split(/\s+/)
            .map((id) => (root.getElementById ? root.getElementById(id) : null))
            .filter(Boolean);
        if (labelled.length) return normalize(labelled.map((node) => node.textContent).join(' '));
        if (element.getAttribute('aria-label'))
            return normalize(element.getAttribute('aria-label'));
        if (element.labels && element.labels.length)
            return normalize(
                Array.from(element.labels)
                    .map((label) => label.textContent)
                    .join(' '),
            );
        return normalize(
            element.getAttribute('placeholder') ||
                element.getAttribute('title') ||
                element.getAttribute('name') ||
                element.id,
        );
    }
    function text(element) {
        return normalize(element.tagName === 'INPUT' ? element.value : element.textContent);
    }
    function rank(element) {
        if (!['id', 'value'].includes(request.kind) && /^[#.\[:]/.test(request.label)) {
            try {
                if (element.matches(request.label) || element.closest(request.label)) return 0;
            } catch (_) {
                /* Ordinary label lookup remains available. */
            }
        }
        const keys =
            request.kind === 'id'
                ? [element.id]
                : request.kind === 'value'
                  ? [element.value, text(element)]
                  : [name(element), element.id, element.getAttribute('name')];
        if (keys.some((key) => normalize(key) && equal(key, request.label))) return 0;
        const query = normalize(request.label).toLowerCase();
        if (
            request.kind !== 'id' &&
            query.length >= 2 &&
            keys.some((key) => normalize(key).toLowerCase().includes(query))
        )
            return 1;
        return -1;
    }
    const candidates = [];
    const roots = new Set();
    let examined = 0,
        inaccessible = 0,
        truncated = false;
    function walk(root, depth) {
        if (roots.has(root)) return;
        if (depth > 8) {
            truncated = true;
            return;
        }
        roots.add(root);
        for (const element of root.querySelectorAll('*')) {
            if (++examined >= 10000) {
                truncated = true;
                return;
            }
            if (
                (element.tagName === 'SELECT' || element.getAttribute('role') === 'combobox') &&
                visible(element)
            ) {
                const score = rank(element);
                if (score >= 0) candidates.push({ element, score });
            }
            if (element.shadowRoot && visible(element)) walk(element.shadowRoot, depth + 1);
            if (element.tagName === 'IFRAME' && visible(element)) {
                try {
                    if (element.contentDocument) walk(element.contentDocument, depth + 1);
                    else inaccessible++;
                } catch (_) {
                    inaccessible++;
                }
            }
        }
    }
    if (request.phase === 'probe' || request.phase === 'activate') {
        if (!normalize(request.label)) return fail('empty_target');
        walk(document, 0);
        if (truncated) return fail('discovery_limit');
        const bestRank = candidates.some((item) => item.score === 0) ? 0 : 1;
        const best = candidates.filter((item) => item.score === bestRank);
        if (request.phase === 'probe')
            return result({ ok: true, matches: best.length, rank: bestRank, inaccessible });
        if (best.length !== 1)
            return fail(
                best.length
                    ? 'ambiguous_target'
                    : inaccessible
                      ? 'inaccessible_frame'
                      : 'not_found',
            );
        const element = best[0].element;
        if (disabled(element)) return fail('not_editable');
        if (element.tagName === 'SELECT') {
            if (element.multiple) return fail('unsupported_multiple_select');
            const options = Array.from(element.options).filter((option) => !disabled(option));
            const byValue = options.filter((option) => option.value === request.value);
            const matches = byValue.length
                ? byValue
                : options.filter((option) => equal(option.textContent, request.value));
            if (matches.length !== 1)
                return fail(matches.length ? 'ambiguous_option' : 'option_not_found');
            const selected = matches[0];
            const setter = Object.getOwnPropertyDescriptor(
                element.ownerDocument.defaultView.HTMLSelectElement.prototype,
                'value',
            ).set;
            setter.call(element, selected.value);
            const view = element.ownerDocument.defaultView;
            element.dispatchEvent(new view.Event('input', { bubbles: true }));
            element.dispatchEvent(new view.Event('change', { bubbles: true }));
            return element.isConnected && element.value === selected.value && selected.selected
                ? done('dom-select')
                : fail('verification_failed');
        }
        if (
            (element.tagName === 'BUTTON' && element.type !== 'button') ||
            (element.tagName === 'A' && element.hasAttribute('href'))
        )
            return fail('unsupported_combobox_button');
        if (!request.token || states.has(request.token) || states.size >= 16)
            return fail('invalid_operation');
        if (
            normalize(request.value) &&
            (element.value === request.value || equal(text(element), request.value))
        )
            return done('aria-unchanged');
        const state = {
            element,
            expires: Math.min(request.expires * 1000, Date.now() + 5000),
            stage: 'options',
        };
        states.set(request.token, state);
        if (element.getAttribute('aria-expanded') !== 'true') element.click();
        return pending('options');
    }
    const state = states.get(request.token);
    if (!state || Date.now() >= state.expires) return fail('expired');
    const element = state.element;
    if (!visible(element) || disabled(element)) return fail('target_changed');
    if (request.phase !== state.stage) return fail('invalid_phase');
    if (request.phase === 'options') {
        const ids = normalize(
            element.getAttribute('aria-controls') || element.getAttribute('aria-owns'),
        )
            .split(' ')
            .filter(Boolean);
        if (!ids.length) return pending('options');
        const containers = [];
        const scopes = new Set([element.getRootNode(), element.ownerDocument]);
        const seen = new Set();
        for (const scope of scopes)
            for (const node of scope.querySelectorAll('[id]')) {
                if (ids.includes(node.id) && !seen.has(node)) {
                    seen.add(node);
                    containers.push(node);
                }
            }
        const lists = containers.filter(
            (node) => node.getAttribute('role') === 'listbox' && visible(node),
        );
        if (lists.length !== 1)
            return lists.length ? fail('ambiguous_listbox') : pending('options');
        const list = lists[0];
        const all = Array.from(list.querySelectorAll('[role="option"]'));
        if (all.length > 4096) return fail('option_limit');
        const options = all.filter(
            (option) =>
                option.closest('[role="listbox"]') === list && visible(option) && !disabled(option),
        );
        const rawValue = (option) =>
            option.getAttribute('value') ?? option.getAttribute('data-value');
        const byValue = options.filter(
            (option) => rawValue(option) !== null && rawValue(option) === request.value,
        );
        const matches = byValue.length
            ? byValue
            : options.filter((option) =>
                  equal(option.getAttribute('aria-label') || option.textContent, request.value),
              );
        if (matches.length !== 1)
            return fail(matches.length ? 'ambiguous_option' : 'option_not_found');
        const option = matches[0];
        if (
            (option.tagName === 'BUTTON' && option.type !== 'button') ||
            (option.tagName === 'A' && option.hasAttribute('href'))
        )
            return fail('unsupported_option');
        state.expectedText = normalize(option.getAttribute('aria-label') || option.textContent);
        state.expectedValue = rawValue(option);
        state.stage = 'verify';
        option.click();
        return pending('verify');
    }
    if (request.phase === 'verify') {
        const valueMatches = state.expectedValue !== null && element.value === state.expectedValue;
        const textMatches = state.expectedText && equal(text(element), state.expectedText);
        return valueMatches || textMatches ? done('aria-option') : pending('verify');
    }
    return fail('unsupported_phase');
})(__IA_APP_SELECT_REQUEST__);
