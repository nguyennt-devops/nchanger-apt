/* app_fill v1: app-local DOM adapter. Contract: CONTRACT-APP-FILL-20261112.md.
 * Probe never focuses/writes. Commit reselects one editable target; it never submits.
 * The host supplies the request expression as JSON, never string interpolation.
 */
(function (request) {
    'use strict';
    const result = (extra) => Object.assign({ protocol: 'app_fill', version: 1 }, extra);
    const normalize = (value) =>
        String(value == null ? '' : value)
            .replace(/\s+/g, ' ')
            .trim();
    const query = normalize(request.label).toLowerCase();
    const candidates = [];
    const visited = new Set();
    let inaccessible = 0;
    let examined = 0;

    function visible(element) {
        if (!element || !element.isConnected || !element.getClientRects().length) return false;
        for (let current = element, depth = 0; current && depth < 64; depth++) {
            const style = current.ownerDocument.defaultView.getComputedStyle(current);
            if (
                style.display === 'none' ||
                style.visibility === 'hidden' ||
                Number(style.opacity) === 0 ||
                current.inert ||
                current.getAttribute('aria-hidden') === 'true'
            )
                return false;
            current = current.parentElement || (current.getRootNode && current.getRootNode().host);
        }
        return true;
    }

    function name(element) {
        const doc = element.ownerDocument;
        const labelled = (element.getAttribute('aria-labelledby') || '')
            .split(/\s+/)
            .map((id) => doc.getElementById(id))
            .filter(Boolean);
        if (labelled.length) return normalize(labelled.map((item) => item.textContent).join(' '));
        const aria = normalize(element.getAttribute('aria-label'));
        if (aria) return aria;
        if (element.labels && element.labels.length)
            return normalize(
                Array.from(element.labels)
                    .map((item) => item.textContent)
                    .join(' '),
            );
        return normalize(
            element.getAttribute('placeholder') ||
                element.getAttribute('title') ||
                element.getAttribute('name') ||
                element.id,
        );
    }

    function rank(element) {
        if (!['id', 'value'].includes(request.kind) && /^[#.\[:]/.test(request.label)) {
            try {
                if (element.matches(request.label) || element.closest(request.label)) return 0;
            } catch (_) {
                // Invalid CSS still gets the ordinary label/name/id lookup.
            }
        }
        let keys;
        if (request.kind === 'id') keys = [element.id];
        else if (request.kind === 'value')
            keys = [element.isContentEditable ? element.textContent : element.value];
        else keys = [name(element), element.id, element.getAttribute('name')];
        keys = keys
            .map(normalize)
            .filter(Boolean)
            .map((key) => key.toLowerCase());
        if (keys.some((key) => key === query)) return 0;
        if (request.kind !== 'id' && query.length >= 2 && keys.some((key) => key.includes(query)))
            return 1;
        return -1;
    }

    function walk(root, depth) {
        if (!root || depth > 8 || visited.has(root) || examined >= 10000) return;
        visited.add(root);
        const elements = root.querySelectorAll('*');
        for (let i = 0; i < elements.length && examined < 10000; i++) {
            const element = elements[i];
            examined++;
            const tag = element.tagName.toLowerCase();
            const textInput =
                tag === 'input' &&
                ![
                    'hidden',
                    'button',
                    'submit',
                    'reset',
                    'checkbox',
                    'radio',
                    'file',
                    'range',
                    'color',
                    'image',
                ].includes(element.type.toLowerCase());
            // Only the editing root is a candidate, not every nested editable span.
            const editable =
                element.isContentEditable &&
                !(element.parentElement && element.parentElement.isContentEditable);
            if (
                (textInput || tag === 'textarea' || tag === 'select' || editable) &&
                visible(element)
            ) {
                const score = request.phase === 'scan' ? 0 : rank(element);
                if (score >= 0) candidates.push({ element, score });
            }
            if (element.shadowRoot && visible(element)) walk(element.shadowRoot, depth + 1);
            if (tag === 'iframe' && visible(element)) {
                try {
                    const doc = element.contentDocument;
                    if (doc) walk(doc, depth + 1);
                    else inaccessible++;
                } catch (_) {
                    inaccessible++;
                }
            }
        }
    }

    // Inventory is metadata only. It shares discovery with fill but never reads
    // current values, focuses, scrolls, emits events or writes to the document.
    function inventory() {
        if (examined >= 10000) return result({ ok: false, error: 'discovery_limit' });
        if (candidates.length > 512) return result({ ok: false, error: 'inventory_limit' });
        const items = candidates.map(({ element }) => {
            let target = element.id;
            let kind = 'id';
            let unique =
                normalize(target) &&
                candidates.filter(
                    (item) =>
                        normalize(item.element.id).toLowerCase() ===
                        normalize(target).toLowerCase(),
                ).length === 1;
            if (!unique) {
                const path = [];
                for (let current = element; current; current = current.parentElement) {
                    const index = current.parentElement
                        ? Array.from(current.parentElement.children).indexOf(current) + 1
                        : Array.from(current.getRootNode().children || []).indexOf(current) + 1;
                    path.unshift(`:nth-child(${index})`);
                }
                target = path.join(' > ');
                kind = 'field';
                try {
                    unique =
                        candidates.filter(
                            (item) => item.element.matches(target) || item.element.closest(target),
                        ).length === 1;
                } catch (_) {
                    unique = false;
                }
            }
            const editable = !(
                element.disabled ||
                element.readOnly ||
                element.getAttribute('aria-disabled') === 'true' ||
                element.getAttribute('aria-readonly') === 'true'
            );
            return {
                label: (name(element) || element.tagName.toLowerCase()).slice(0, 4096),
                target: target.length <= 4096 ? target : '',
                kind,
                source: 'webview',
                editable,
                selectable: !!(editable && unique && target.length <= 4096),
            };
        });
        return result({ ok: true, items, inaccessible });
    }

    if (!query && request.phase !== 'scan')
        return result({ ok: false, error: 'empty_target', matches: 0 });
    if (Date.now() >= request.expires * 1000)
        return result({ ok: false, error: 'expired', matches: 0 });
    walk(document, 0);
    if (request.phase === 'scan') return inventory();
    const bestRank = candidates.some((item) => item.score === 0) ? 0 : 1;
    const best = candidates.filter((item) => item.score === bestRank);
    if (request.phase === 'probe')
        return result({
            ok: true,
            matches: best.length,
            rank: bestRank,
            inaccessible,
            truncated: examined >= 10000,
        });
    if (request.phase !== 'commit') return result({ ok: false, error: 'unsupported_phase' });
    if (examined >= 10000) return result({ ok: false, error: 'discovery_limit' });
    if (best.length !== 1)
        return result({
            ok: false,
            error: best.length
                ? 'ambiguous_target'
                : inaccessible
                  ? 'inaccessible_frame'
                  : 'not_found',
        });
    const element = best[0].element;
    if (
        element.disabled ||
        element.readOnly ||
        element.getAttribute('aria-disabled') === 'true' ||
        element.getAttribute('aria-readonly') === 'true'
    )
        return result({ ok: false, error: 'not_editable' });
    if (Date.now() >= request.expires * 1000) return result({ ok: false, error: 'expired' });
    const value = request.value;
    const view = element.ownerDocument.defaultView;
    const tag = element.tagName.toLowerCase();
    if (tag === 'input' && /[\r\n]/.test(value))
        return result({ ok: false, error: 'unsupported_linebreak' });
    try {
        element.scrollIntoView({ block: 'center', inline: 'nearest' });
        element.focus();
        const read = () => (element.isContentEditable ? element.textContent : element.value);
        if (read() === value)
            return result({ ok: true, verified: true, via: 'dom', unchanged: true });
        const before = new view.InputEvent('beforeinput', {
            bubbles: true,
            cancelable: true,
            data: value,
            inputType: 'insertReplacementText',
        });
        if (!element.dispatchEvent(before)) return result({ ok: false, error: 'edit_rejected' });
        if (Date.now() >= request.expires * 1000 || !element.isConnected)
            return result({ ok: false, error: 'target_changed' });
        if (tag === 'select') {
            const options = Array.from(element.options).filter(
                (option) =>
                    !option.disabled &&
                    (option.value === value ||
                        normalize(option.textContent).toLowerCase() ===
                            normalize(value).toLowerCase()),
            );
            if (options.length !== 1)
                return result({
                    ok: false,
                    error: options.length ? 'ambiguous_option' : 'option_not_found',
                });
            element.value = options[0].value;
            element.dispatchEvent(new view.Event('input', { bubbles: true }));
            element.dispatchEvent(new view.Event('change', { bubbles: true }));
            return result({
                ok: element.value === options[0].value,
                verified: element.value === options[0].value,
                via: 'dom-select',
            });
        }
        if (element.isContentEditable) element.textContent = value;
        else {
            const prototype =
                tag === 'textarea'
                    ? view.HTMLTextAreaElement.prototype
                    : view.HTMLInputElement.prototype;
            const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
            if (!descriptor || !descriptor.set)
                return result({ ok: false, error: 'unsupported_editor' });
            descriptor.set.call(element, value);
        }
        element.dispatchEvent(
            new view.InputEvent('input', {
                bubbles: true,
                data: value,
                inputType: 'insertReplacementText',
            }),
        );
        element.dispatchEvent(new view.Event('change', { bubbles: true }));
        const verified = element.isConnected && read() === value;
        return result({
            ok: verified,
            verified,
            via: 'dom',
            error: verified ? null : 'verification_failed',
        });
    } catch (_) {
        return result({ ok: false, error: 'dom_operation_failed' });
    }
})(__IA_APP_FILL_REQUEST__);
