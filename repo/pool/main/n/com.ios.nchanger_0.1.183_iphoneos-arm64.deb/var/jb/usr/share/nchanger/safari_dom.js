;(function () {
  try {
    var MARK = typeof Symbol === "function" && Symbol["for"] ? Symbol["for"]("dom") : "__zx_dom";
    var SKIP = typeof Symbol === "function" && Symbol["for"] ? Symbol["for"]("skr") : "__zx_skr";
    if (window[MARK]) return;
    try { Object.defineProperty(window, MARK, { configurable: true, value: 1 }); } catch (eMark) { try { window[MARK] = 1; } catch (eMark2) {} }
    var W = __ZXT_W__, H = __ZXT_H__, S = __ZXT_S__;
    // A bound function keeps the native `function name() { [native code] }`
    // shape. The caller passes a NAMED function so the printed name matches the
    // native accessor name.
    function G(self, fn, name) {
      var b = Function.prototype.bind.call(fn, self);
      try { Object.defineProperty(b, "name", { value: name, configurable: true }); } catch (eG) {}
      return b;
    }
    // Native attributes live on the prototype; defining on the instance would be
    // visible through Object.getOwnPropertyDescriptor(instance, key).
    function P(o, k, v, getter) {
      try {
        var target = o;
        try {
          var proto = o && Object.getPrototypeOf(o);
          if (proto && Object.getOwnPropertyDescriptor(proto, k)) target = proto;
        } catch (eH) {}
        Object.defineProperty(target, k, { configurable: true, enumerable: true, get: G(o, getter || function () { return v; }, String(k)) });
      } catch (e) {}
    }
    function patch(sc) {
      if (!sc) return;
      P(sc, "width", W, function width() { return W; });
      P(sc, "availWidth", W, function availWidth() { return W; });
      P(sc, "height", H, function height() { return H; });
      P(sc, "availHeight", H, function availHeight() { return H; });
    }
    function zxtMediaValue(query) {
      var text = String(query || "").toLowerCase();
      if (!/(device-width|device-height|resolution|dppx|device-pixel-ratio)/.test(text)) return null;
      var negate = false;
      var media = text.match(/^\s*(only\s+|not\s+)?(all|screen|print|speech)\s*(?:and\s+)?/);
      if (media) {
        if (media[2] !== "all" && media[2] !== "screen") return null;
        negate = /^\s*not\s+/.test(media[0]);
        text = text.slice(media[0].length);
      }
      text = text.replace(/^\s+|\s+$/g, "");
      if (!text) return null;
      var parts = text.split(/\s+and\s+/), ok = true;
      for (var i = 0; i < parts.length; i++) {
        var part = parts[i].replace(/^\s+|\s+$/g, ""), m;
        if ((m = part.match(/^\(\s*min-device-width\s*:\s*([0-9.]+)px\s*\)$/))) ok = ok && W >= parseFloat(m[1]);
        else if ((m = part.match(/^\(\s*max-device-width\s*:\s*([0-9.]+)px\s*\)$/))) ok = ok && W <= parseFloat(m[1]);
        else if ((m = part.match(/^\(\s*device-width\s*:\s*([0-9.]+)px\s*\)$/))) ok = ok && W === parseFloat(m[1]);
        else if ((m = part.match(/^\(\s*min-device-height\s*:\s*([0-9.]+)px\s*\)$/))) ok = ok && H >= parseFloat(m[1]);
        else if ((m = part.match(/^\(\s*max-device-height\s*:\s*([0-9.]+)px\s*\)$/))) ok = ok && H <= parseFloat(m[1]);
        else if ((m = part.match(/^\(\s*device-height\s*:\s*([0-9.]+)px\s*\)$/))) ok = ok && H === parseFloat(m[1]);
        else if ((m = part.match(/^\(\s*min-resolution\s*:\s*([0-9.]+)\s*(dppx|x|dpi)\s*\)$/))) ok = ok && S >= (m[2] === "dpi" ? parseFloat(m[1]) / 96 : parseFloat(m[1]));
        else if ((m = part.match(/^\(\s*max-resolution\s*:\s*([0-9.]+)\s*(dppx|x|dpi)\s*\)$/))) ok = ok && S <= (m[2] === "dpi" ? parseFloat(m[1]) / 96 : parseFloat(m[1]));
        else if ((m = part.match(/^\(\s*resolution\s*:\s*([0-9.]+)\s*(dppx|x|dpi)\s*\)$/))) ok = ok && Math.abs(S - (m[2] === "dpi" ? parseFloat(m[1]) / 96 : parseFloat(m[1]))) < 0.001;
        else if ((m = part.match(/^\(\s*-webkit-min-device-pixel-ratio\s*:\s*([0-9.]+)\s*\)$/))) ok = ok && S >= parseFloat(m[1]);
        else if ((m = part.match(/^\(\s*-webkit-max-device-pixel-ratio\s*:\s*([0-9.]+)\s*\)$/))) ok = ok && S <= parseFloat(m[1]);
        else return null;
      }
      return negate ? !ok : ok;
    }
    function zxtInstallMediaFallback() {
      var nativeMatchMedia = window.matchMedia;
      if (typeof nativeMatchMedia !== "function") return;
      try {
        var patched = new Proxy(nativeMatchMedia, {
          apply: function (target, self, args) {
            var list = Reflect.apply(target, window, args);
            var value = zxtMediaValue(args[0]);
            if (value === null || !list) return list;
            try {
              Object.defineProperty(list, "matches", { configurable: true, get: G(list, function matches() { return value; }, "matches") });
            } catch (eM) {}
            return list;
          }
        });
        var bound = Function.prototype.bind.call(patched, window);
        try { Object.defineProperty(bound, "name", { value: "matchMedia", configurable: true }); } catch (eN) {}
        Object.defineProperty(window, "matchMedia", { configurable: true, enumerable: true, writable: true, value: bound });
      } catch (eMM) {}
    }
    var skipScr = (typeof window !== "undefined" && window[SKIP]);
    if (!skipScr) {
      patch(typeof screen !== "undefined" ? screen : null);
      if (typeof window !== "undefined") {
        P(window, "devicePixelRatio", S, function devicePixelRatio() { return S; });
        P(window, "outerWidth", W, function outerWidth() { return W; });
        P(window, "outerHeight", H, function outerHeight() { return H; });
        if (window.screen) patch(window.screen);
        zxtInstallMediaFallback();
      }
    }
    (function () {
      var Orig = window.RegExp;
      try { new Orig("(?<=a)"); return; } catch (e3) {}
      function stripLB(s) {
        s = String(s);
        var out = "", i = 0;
        while (i < s.length) {
          if (s.charAt(i) === "(" && s.slice(i, i + 3) === "(?<" &&
              (s.charAt(i + 3) === "=" || s.charAt(i + 3) === "!")) {
            var depth = 1, j = i + 4;
            while (j < s.length && depth) {
              var ch = s.charAt(j);
              if (ch === "\\" ) { j += 2; continue; }
              if (ch === "(") depth++;
              else if (ch === ")") depth--;
              j++;
            }
            i = j;
            continue;
          }
          out += s.charAt(i);
          i++;
        }
        return out;
      }
      function ZXTRe(p, f) {
        if (p instanceof Orig) return f === undefined ? new Orig(p) : new Orig(p, f);
        if (typeof p === "string" && p.indexOf("(?<") !== -1) {
          try { return f === undefined ? new Orig(p) : new Orig(p, f); }
          catch (e4) { p = stripLB(p); }
        }
        return f === undefined ? new Orig(p) : new Orig(p, f);
      }
      ZXTRe.prototype = Orig.prototype;
      ZXTRe.__zxtRe = 1;
      try {
        Object.defineProperty(window, "RegExp", {
          configurable: true, writable: true, value: ZXTRe
        });
      } catch (e5) {
        try { window.RegExp = ZXTRe; } catch (e6) {}
      }
    })();
  } catch (e) {}
})();
