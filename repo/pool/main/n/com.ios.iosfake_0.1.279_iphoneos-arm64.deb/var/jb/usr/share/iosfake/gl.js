/* IOSFake WebGL native v2 - native API behavior with an explicit renderer label. */
;(function () {
  "use strict";
  var root = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : null;
  if (!root) return;
  var bootConfig = __NCHANGER_GL_CONFIG__;
  var hasSymbols = typeof Symbol === "function" && Symbol.for;
  var key = hasSymbols ? Symbol.for("IOSFake.WebGL.native.v2") : "__IOSFakeWebGLNative_v2";
  var version = "iosfake-webgl-native-2";
  var existing = Object.getOwnPropertyDescriptor(root, key);
  if (existing) {
    if (existing.value && existing.value.version === version && typeof existing.value.apply === "function") existing.value.apply(bootConfig);
    return;
  }
  var entry = Object.getOwnPropertyDescriptor(root, "zxApplyGl");
  var legacyKey = hasSymbols ? Symbol.for("IOSFake.LegacyWebGL.v1") : "__IOSFakeLegacyWebGL_v1";
  var legacyDescriptor = Object.getOwnPropertyDescriptor(root, legacyKey);
  var legacy = legacyDescriptor && legacyDescriptor.value;
  var knownLegacy = legacy && legacy.version === "iosfake-legacy-webgl-1" && typeof legacy.apply === "function";
  if (entry && (!knownLegacy || entry.value !== legacy.apply || !entry.configurable)) return;
  // The recognized old owner can restore its own buffer/parameter methods.
  // Opaque or foreign owners are never guessed or replaced.
  if (knownLegacy) legacy.apply({ vendor: "Apple Inc.", renderer: "Apple GPU", enabled: false });
  if (entry) delete root.zxApplyGl;

  var apply = Reflect.apply;
  var state = { enabled: false, vendor: "Apple Inc.", prototypes: new WeakMap(), wrappers: new WeakMap() };
  function prototypes() {
    var result = [];
    for (var type of [root.WebGLRenderingContext, root.WebGL2RenderingContext]) {
      var prototype = type && type.prototype;
      if (prototype && (typeof prototype === "object" || typeof prototype === "function") && result.indexOf(prototype) < 0) result.push(prototype);
    }
    return result;
  }
  function sameDescriptor(left, right) {
    if (!left || !right) return left === right;
    return left.value === right.value && left.get === right.get && left.set === right.set && left.configurable === right.configurable && left.writable === right.writable && left.enumerable === right.enumerable;
  }
  function restore(prototype, descriptor) {
    if (descriptor) Object.defineProperty(prototype, "getParameter", descriptor);
    else delete prototype.getParameter;
  }
  function disable() {
    state.enabled = false;
    for (var prototype of prototypes()) {
      var record = state.prototypes.get(prototype), current = Object.getOwnPropertyDescriptor(prototype, "getParameter");
      if (record && current && current.value === record.wrapper) {
        // A page may lock its prototype. Retained/locked wrappers still delegate OFF.
        try { restore(prototype, record.original); } catch (error) { }
      }
    }
  }
  function parameterWrapper(original) {
    return {
      getParameter(pname) {
        if (!state.enabled || !arguments.length) return apply(original, this, arguments);
        var input = pname, inputType = typeof input, converted = false, enumValue, result;
        if ((input !== null && inputType === "object") || inputType === "function") {
          var args = { __proto__: null, length: arguments.length };
          for (var index = 0; index < arguments.length; index++) args[index] = arguments[index];
          // Native checks the receiver before coercing an object enum. Observe
          // that conversion once; never invoke the caller's coercion twice.
          args[0] = { __proto__: null, valueOf: function () {
            var number = +input;
            enumValue = number >>> 0;
            converted = true;
            return number;
          } };
          result = apply(original, this, args);
        } else {
          // Ordinary queries reach the captured delegate with their exact
          // receiver and arguments, including native Symbol/BigInt errors.
          result = apply(original, this, arguments);
          if (!state.enabled || typeof result !== "string") return result;
          if (inputType === "number" || inputType === "string") {
            enumValue = (+input) >>> 0;
            converted = true;
          }
        }
        // Native context loss, extension admission, errors and return types win.
        if (!state.enabled || !converted || typeof result !== "string") return result;
        if (enumValue === 7937 || enumValue === 37446) return "Apple GPU";
        if (enumValue === 37445) return state.vendor;
        return result;
      }
    }.getParameter;
  }
  function install(prototype, changes) {
    var current = Object.getOwnPropertyDescriptor(prototype, "getParameter");
    var visible = prototype.getParameter, record = state.prototypes.get(prototype);
    var oldAdapterKey = hasSymbols ? Symbol.for("zxApplyGl") : "__zxApplyGl";
    if (visible && visible[oldAdapterKey]) return;
    if (record) {
      if (current && current.value === record.wrapper) return;
      if (!sameDescriptor(current, record.original)) return;
      if (!current && visible !== record.native) return;
    } else {
      if (typeof visible !== "function") return;
      // An inherited owned method already delegates for the derived receiver.
      if (!current && state.wrappers.has(visible)) return;
      record = { original: current, native: visible, wrapper: parameterWrapper(visible) };
    }
    Object.defineProperty(prototype, "getParameter", current ? { value: record.wrapper } : { value: record.wrapper, configurable: true, writable: true, enumerable: true });
    changes.push({ prototype: prototype, before: current, wrapper: record.wrapper });
    state.prototypes.set(prototype, record);
    state.wrappers.set(record.wrapper, record.native);
  }
  function zxApplyGl(config) {
    if (!config) { disable(); return; }
    var vendor = config.vendor;
    if (typeof vendor !== "string") { disable(); return; }
    var renderer = config.renderer;
    if (typeof renderer !== "string") { disable(); return; }
    var enabled = config.enabled;
    if ((enabled !== undefined && typeof enabled !== "boolean") || enabled === false) { disable(); return; }
    var wasEnabled = state.enabled, changes = [];
    try {
      for (var prototype of prototypes()) install(prototype, changes);
    } catch (error) {
      for (var index = changes.length - 1; index >= 0; index--) {
        var change = changes[index], current = Object.getOwnPropertyDescriptor(change.prototype, "getParameter");
        if (current && current.value === change.wrapper) {
          try { restore(change.prototype, change.before); } catch (rollbackError) { }
        }
      }
      state.enabled = wasEnabled;
      throw error;
    }
    state.vendor = vendor;
    state.enabled = true;
  }
  Object.defineProperty(root, "zxApplyGl", { configurable: true, writable: true, value: zxApplyGl });
  try { Object.defineProperty(root, key, { value: Object.freeze({ version: version, apply: zxApplyGl }) }); }
  catch (error) { if (root.zxApplyGl === zxApplyGl) delete root.zxApplyGl; throw error; }
  zxApplyGl(bootConfig);
})();
