/* Gọi IOS Fake từ app khác. Cùng tên hàm với script IOS Auto.
 * Dylib rootless: /var/jb/usr/lib/libiosfake.dylib
 * Dylib roothide: /usr/lib/libiosfake.dylib (qua jbroot)
 * Chuỗi trả về do malloc — gọi free khi xong.
 * 0;; là xong. -1;; là lỗi.
 */
#ifndef IOSFAKE_H
#define IOSFAKE_H

#ifdef __cplusplus
extern "C" {
#endif

char *reset_app_data(const char *bundle_id);
char *clear_app_data(const char *bundle_id);
char *change_data(const char *bundle_id);
char *backup_app(const char *bundle_id);
char *restore_app(const char *bundle_id);
char *clone_app(const char *bundle_id, int nth);
char *spoof_reload(const char *bundle_ids);

#ifdef __cplusplus
}
#endif

#endif
