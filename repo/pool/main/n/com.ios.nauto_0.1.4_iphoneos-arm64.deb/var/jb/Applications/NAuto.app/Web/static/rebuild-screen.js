(() => {
    'use strict';

    // Original client: startPaint/paintFrame/bindInput. Intentional bounded ACK and
    // lifecycle extensions: docs/WORKFLOW-LIVE-SCREEN-CLIENT-CONTRACT.md.
    // Hidden-page persistence: docs/WORKFLOW-SCREEN-PERSISTENCE-CONTRACT.md.
    const canvas = document.getElementById('image');
    const textInput = document.getElementById('text-input');
    const status = document.getElementById('status');
    const context = canvas.getContext('2d', { alpha: false });
    const MAX_PENDING_INPUT = 32;
    const MAX_TEXT_BYTES = 4096;
    const INPUT_TIMEOUT_MS = 3000;
    const CONNECT_TIMEOUT_MS = 15000;
    const FRAME_TIMEOUT_MS = 10000;
    const MAX_FRAME_BYTES = 4 * 1024 * 1024;
    // Browser network state does not describe a loopback USB tunnel. A host
    // without Wi-Fi/Ethernet can still reach the phone through Apple usbmux.
    // LAN viewers retain their existing online/offline lifecycle contract.
    const loopbackTransport =
        location.hostname === '127.0.0.1' || location.hostname === 'localhost';
    // Page lifetime owns its input session. Simultaneous viewers cannot move
    // or release another viewer's active gesture in the independent backend.
    const inputSession =
        typeof crypto.randomUUID === 'function'
            ? crypto.randomUUID()
            : Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) =>
                  byte.toString(16).padStart(2, '0'),
              ).join('');

    let socket = null;
    let generation = 0;
    let retryTimer = 0;
    let watchdogTimer = 0;
    let retryAttempt = 0;
    let suspended = false;
    let ready = false;
    let helloReceived = false;
    let visibilityControl = false;
    let sentVisibility = null;
    let lastFrameAt = 0;
    let paintJob = null;
    let pendingFrame = null;

    let inputEpoch = 0;
    let inputInFlight = null;
    let inputQueue = [];
    let gesture = null;
    let moveFrame = 0;
    let movePoint = null;
    let composing = false;
    let compositionCommit = null;
    let compositionTimer = 0;
    let beforeInputCommit = null;
    let namedKeyCommit = null;
    let inputWindowFocused = true;

    function say(message) {
        status.textContent = message;
        status.hidden = !message;
    }

    function wantsConnection() {
        return !suspended && (loopbackTransport || navigator.onLine !== false);
    }

    function isCurrent(peer, token) {
        return socket === peer && generation === token && wantsConnection();
    }

    function clearRetry() {
        clearTimeout(retryTimer);
        retryTimer = 0;
    }

    function closePaint(job) {
        if (!job) return;
        job.cancelled = true;
        if (job.cancelDecode) job.cancelDecode();
        if (job.cancelPaint) job.cancelPaint();
    }

    // Animation frames may stop in background tabs. Release the admitted frame
    // once without waiting for a paint; an uncancellable decode keeps its owner
    // until it settles and closes its bitmap in runPaint's finally block.
    function releaseHiddenPaint() {
        pendingFrame = null;
        const job = paintJob;
        if (!job || job.cancelled) return;
        closePaint(job);
        acknowledge(job.peer, job.token);
    }

    function clearWatchdog() {
        clearTimeout(watchdogTimer);
        watchdogTimer = 0;
    }

    function scheduleRetry() {
        if (!wantsConnection() || retryTimer || socket) return;

        const base = Math.min(8000, 400 * 2 ** Math.min(retryAttempt, 5));
        const delay = Math.round(base * (0.8 + Math.random() * 0.4));
        retryAttempt++;
        retryTimer = setTimeout(() => {
            retryTimer = 0;
            connect();
        }, delay);
    }

    // Invalidate ownership before closing: late socket/decode callbacks cannot
    // retire, draw into or acknowledge the replacement connection.
    function disconnect(message, reconnect) {
        generation++;
        const previous = socket;
        socket = null;
        ready = false;
        helloReceived = false;
        visibilityControl = false;
        sentVisibility = null;
        pendingFrame = null;
        clearRetry();
        clearWatchdog();
        closePaint(paintJob);
        // createImageBitmap has no cancellation API. Keep its cancelled owner
        // until it settles, so reconnects cannot accumulate decoder jobs.
        cancelInput();

        if (previous) {
            previous.onopen = null;
            previous.onclose = null;
            previous.onerror = null;
            previous.onmessage = null;
            try {
                previous.close();
            } catch (_) {
                // A CONNECTING socket can reject close in older engines.
            }
        }

        say(message);
        if (reconnect) scheduleRetry();
    }

    function armWatchdog(peer, token, openedAt) {
        clearWatchdog();
        watchdogTimer = setTimeout(() => {
            watchdogTimer = 0;
            if (!isCurrent(peer, token)) return;

            // Negotiated hidden video is intentionally idle. Protocol ping/pong
            // keeps the socket healthy without forcing captures or JS heartbeats.
            if (helloReceived && visibilityControl && document.hidden) {
                armWatchdog(peer, token, openedAt);
                return;
            }

            const limit = helloReceived ? FRAME_TIMEOUT_MS : CONNECT_TIMEOUT_MS;
            const activity = helloReceived ? lastFrameAt || openedAt : openedAt;
            if (performance.now() - activity >= limit) {
                disconnect('Đang kết nối lại…', true);
                return;
            }
            armWatchdog(peer, token, openedAt);
        }, 1000);
    }

    function acknowledge(peer, token) {
        if (!isCurrent(peer, token) || peer.readyState !== WebSocket.OPEN) return;
        try {
            peer.send(JSON.stringify({ type: 'ack' }));
        } catch (_) {
            disconnect('Đang kết nối lại…', true);
        }
    }

    function syncVisibility(peer, token) {
        if (!visibilityControl || !isCurrent(peer, token) || peer.readyState !== WebSocket.OPEN)
            return;
        const visible = !document.hidden;
        if (sentVisibility === visible) return;
        try {
            peer.send(JSON.stringify({ type: 'visibility', visible }));
            sentVisibility = visible;
        } catch (_) {
            disconnect('Đang kết nối lại…', true);
        }
    }

    // Image fallback owns its URL until load/error/cancel; ImageBitmap ownership
    // stays with runPaint, including a bitmap that arrives after disconnection.
    function decodeJPEG(blob, job) {
        if (typeof createImageBitmap === 'function') return createImageBitmap(blob);

        return new Promise((resolve, reject) => {
            const image = new Image();
            const url = URL.createObjectURL(blob);
            let settled = false;

            function finish(error) {
                if (settled) return;
                settled = true;
                URL.revokeObjectURL(url);
                image.onload = null;
                image.onerror = null;
                job.cancelDecode = null;
                if (error) {
                    image.src = '';
                    reject(error);
                } else {
                    resolve(image);
                }
            }

            job.cancelDecode = () => finish(new Error('Cancelled image decode'));
            image.onload = () => finish(null);
            image.onerror = () => finish(new Error('Invalid JPEG'));
            image.src = url;
        });
    }

    function paintOnNextFrame(image, job) {
        return new Promise((resolve, reject) => {
            const frame = requestAnimationFrame(() => {
                job.cancelPaint = null;
                if (job.cancelled || !isCurrent(job.peer, job.token)) {
                    resolve(false);
                    return;
                }

                try {
                    const width = image.width || image.naturalWidth;
                    const height = image.height || image.naturalHeight;
                    if (!(width > 0 && height > 0)) throw new Error('Empty JPEG');

                    if (canvas.width !== width || canvas.height !== height) {
                        canvas.width = width;
                        canvas.height = height;
                    }
                    context.drawImage(image, 0, 0);
                    resolve(true);
                } catch (error) {
                    reject(error);
                }
            });

            job.cancelPaint = () => {
                cancelAnimationFrame(frame);
                job.cancelPaint = null;
                resolve(false);
            };
        });
    }

    async function runPaint(job) {
        let image = null;
        try {
            const blob = new Blob([job.data], { type: 'image/jpeg' });
            image = await decodeJPEG(blob, job);
            if (job.cancelled || !isCurrent(job.peer, job.token)) return;

            if (await paintOnNextFrame(image, job)) {
                ready = true;
                retryAttempt = 0;
                say('');
            }
        } catch (_) {
            if (isCurrent(job.peer, job.token)) say('Đang chờ hình ảnh…');
        } finally {
            if (image && typeof image.close === 'function') image.close();

            // Failed decodes also release the server's one-frame admission gate.
            if (!job.cancelled) acknowledge(job.peer, job.token);
            if (paintJob === job) {
                paintJob = null;
                const next = pendingFrame;
                pendingFrame = null;
                if (next) receiveFrame(next.peer, next.token, next.data);
            }
        }
    }

    function receiveFrame(peer, token, data) {
        if (!isCurrent(peer, token)) return;
        if (document.hidden) {
            // Consume background frames without allocating image/paint work.
            // ACK keeps the producer's single-frame gate and this socket live.
            acknowledge(peer, token);
            return;
        }
        if (paintJob) {
            // Defensive only: the ACK protocol normally permits no second frame.
            pendingFrame = { peer, token, data };
            return;
        }

        paintJob = { peer, token, data, cancelled: false };
        void runPaint(paintJob);
    }

    function connect() {
        if (!wantsConnection() || socket || retryTimer) return;
        if (!context) {
            say('Trình duyệt không hỗ trợ hiển thị màn hình');
            return;
        }

        say('Đang kết nối…');
        const token = ++generation;
        const openedAt = performance.now();
        const scheme = location.protocol === 'https:' ? 'wss:' : 'ws:';
        let peer;
        try {
            peer = new WebSocket(scheme + '//' + location.host + '/screen/ws');
        } catch (_) {
            scheduleRetry();
            return;
        }

        socket = peer;
        peer.binaryType = 'arraybuffer';
        armWatchdog(peer, token, openedAt);
        peer.onopen = () => {
            if (isCurrent(peer, token)) say('Đang chờ hình ảnh…');
        };
        peer.onclose = peer.onerror = () => {
            if (isCurrent(peer, token)) disconnect('Đang kết nối lại…', true);
        };
        peer.onmessage = (event) => {
            if (!isCurrent(peer, token)) return;
            if (typeof event.data === 'string') {
                try {
                    const message = JSON.parse(event.data);
                    if (message.type === 'hello') {
                        if (message.video !== 'jpeg') {
                            disconnect('Định dạng màn hình chưa được hỗ trợ', true);
                            return;
                        }
                        helloReceived = true;
                        visibilityControl = message.visibilityControl === true;
                        lastFrameAt = performance.now();
                        syncVisibility(peer, token);
                    } else if (message.type === 'ping' && peer.readyState === WebSocket.OPEN) {
                        peer.send(JSON.stringify({ type: 'pong' }));
                    }
                } catch (_) {
                    // Unknown/malformed status messages cannot stall frame ACKs.
                }
                return;
            }

            if (!helloReceived) {
                disconnect('Đang kết nối lại…', true);
                return;
            }
            const bytes = event.data.byteLength ?? event.data.size ?? 0;
            if (!(bytes > 0 && bytes <= MAX_FRAME_BYTES)) {
                disconnect('Khung hình vượt giới hạn', true);
                return;
            }
            lastFrameAt = performance.now();
            receiveFrame(peer, token, event.data);
        };
    }

    function point(event) {
        const bounds = canvas.getBoundingClientRect();
        if (!(bounds.width > 0 && bounds.height > 0)) return null;
        return {
            x: Math.max(0, Math.min(1, (event.clientX - bounds.left) / bounds.width)),
            y: Math.max(0, Math.min(1, (event.clientY - bounds.top) / bounds.height)),
        };
    }

    function touchPayload(phase, position) {
        return { type: 'touch', phase, id: 0, ...position };
    }

    function releasePointer(current) {
        if (!current) return;
        current.active = false;
        try {
            if (canvas.hasPointerCapture(current.pointerId)) {
                canvas.releasePointerCapture(current.pointerId);
            }
        } catch (_) {
            // Pointer cancellation may have already released browser capture.
        }
    }

    function clearMove() {
        if (moveFrame) cancelAnimationFrame(moveFrame);
        moveFrame = 0;
        movePoint = null;
    }

    // One HTTP input request is admitted at a time. Local abort cannot prove
    // remote cancellation, so a potentially submitted down owns a final up.
    function cancelInput() {
        clearMove();
        resetTextInput();
        inputQueue = [];
        releasePointer(gesture);
        if (inputInFlight && inputInFlight.bestEffort) return;

        inputEpoch++;
        if (inputInFlight) inputInFlight.controller.abort();
        if (gesture && gesture.submitted) {
            inputQueue.push({
                payload: touchPayload('up', gesture.position),
                current: gesture,
                bestEffort: true,
                epoch: inputEpoch,
            });
        } else {
            gesture = null;
        }
        void pumpInput();
    }

    async function pumpInput() {
        if (inputInFlight || inputQueue.length === 0) return;

        const item = inputQueue.shift();
        const controller = new AbortController();
        item.controller = controller;
        inputInFlight = item;
        if (item.payload.phase === 'down') item.current.submitted = true;

        const timeout = setTimeout(() => controller.abort(), INPUT_TIMEOUT_MS);
        try {
            const response = await fetch('/api/input', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...item.payload, session: inputSession }),
                signal: controller.signal,
                keepalive: item.bestEffort === true,
                cache: 'no-store',
            });
            const result = await response.json();
            if (!response.ok || result.ok === false) throw new Error('Input unavailable');

            if (item.payload.phase === 'up' && gesture === item.current) gesture = null;
        } catch (_) {
            if (item.epoch === inputEpoch && !item.bestEffort) {
                say('Điều khiển tạm ngắt');
                cancelInput();
            }
        } finally {
            clearTimeout(timeout);
            if (item.bestEffort && gesture === item.current) gesture = null;
            inputInFlight = null;
            void pumpInput();
        }
    }

    function enqueueInput(payload, current = null) {
        if (inputQueue.length >= MAX_PENDING_INPUT) return false;
        inputQueue.push({ payload, current, epoch: inputEpoch });
        void pumpInput();
        return true;
    }

    function flushMove() {
        moveFrame = 0;
        if (!gesture || !gesture.active || !movePoint) return;
        const payload = touchPayload('move', movePoint);
        movePoint = null;

        const queued = inputQueue.find(
            (item) => item.current === gesture && item.payload.phase === 'move',
        );
        if (queued) {
            queued.payload = payload;
        } else {
            enqueueInput(payload, gesture);
        }
    }

    canvas.onpointerdown = (event) => {
        if (!ready || document.hidden || !wantsConnection() || gesture || event.button !== 0)
            return;
        const position = point(event);
        if (!position || inputQueue.length >= MAX_PENDING_INPUT) return;

        event.preventDefault();
        (textInput || canvas).focus({ preventScroll: true });
        gesture = { pointerId: event.pointerId, position, active: true, submitted: false };
        canvas.setPointerCapture(event.pointerId);
        enqueueInput(touchPayload('down', position), gesture);
    };
    canvas.onpointermove = (event) => {
        if (!gesture || !gesture.active || event.pointerId !== gesture.pointerId) return;
        const events = event.getCoalescedEvents ? event.getCoalescedEvents() : [];
        const position = point(events.length ? events[events.length - 1] : event);
        if (!position) return;

        event.preventDefault();
        gesture.position = position;
        movePoint = position;
        if (!moveFrame) moveFrame = requestAnimationFrame(flushMove);
    };
    canvas.onpointerup = (event) => {
        if (!gesture || !gesture.active || event.pointerId !== gesture.pointerId) return;
        event.preventDefault();
        if (moveFrame) cancelAnimationFrame(moveFrame);
        flushMove();
        const current = gesture;
        current.position = point(event) || current.position;
        releasePointer(current);

        // A full keyboard queue must not prevent a gesture's terminal release.
        inputQueue = inputQueue.filter((item) => item.current === current);
        enqueueInput(touchPayload('up', current.position), current);
    };
    canvas.onpointercancel = canvas.onlostpointercapture = (event) => {
        if (gesture && gesture.active && event.pointerId === gesture.pointerId) cancelInput();
    };

    const keys = {
        Enter: 'enter',
        Backspace: 'backspace',
        Delete: 'delete',
        Tab: 'tab',
        Escape: 'escape',
        ArrowLeft: 'arrowleft',
        ArrowRight: 'arrowright',
        ArrowUp: 'arrowup',
        ArrowDown: 'arrowdown',
    };
    function acceptsTextInput() {
        const focused = document.activeElement;
        return (
            ready &&
            !document.hidden &&
            inputWindowFocused &&
            wantsConnection() &&
            (focused === canvas || focused === textInput)
        );
    }

    function resetTextInput() {
        composing = false;
        compositionCommit = null;
        beforeInputCommit = null;
        namedKeyCommit = null;
        clearTimeout(compositionTimer);
        compositionTimer = 0;
        if (textInput) textInput.value = '';
    }

    function validText(value) {
        // Every valid UTF16 code unit requires at least one UTF8 byte. Reject
        // huge clipboard strings before scanning or allocating their encoding.
        if (value.length > MAX_TEXT_BYTES) return false;
        // Blob UTF8 encoding replaces isolated surrogates. Reject those first
        // so the bounded JSON carrier never changes the requested characters.
        for (let index = 0; index < value.length; index++) {
            const unit = value.charCodeAt(index);
            if (unit >= 0xd800 && unit <= 0xdbff) {
                const next = value.charCodeAt(++index);
                if (!(next >= 0xdc00 && next <= 0xdfff)) return false;
            } else if (unit >= 0xdc00 && unit <= 0xdfff) {
                return false;
            }
        }
        return new Blob([value]).size <= MAX_TEXT_BYTES;
    }

    function enqueueText(type, value) {
        if (!acceptsTextInput() || typeof value !== 'string' || !value.length) return;
        if (!validText(value)) {
            say('Văn bản không hợp lệ hoặc vượt quá 4096 byte');
            return;
        }
        // One commit is admitted atomically. Splitting a paste could leave a
        // partial edit or reorder clipboard writes around another input.
        if (!enqueueInput({ type, s: value })) say('Hàng đợi điều khiển đã đầy');
    }

    function keyDown(event) {
        if (!acceptsTextInput() || event.isComposing || composing) return;
        if (event.ctrlKey || event.metaKey || event.altKey) return;
        // A later real keystroke is not the trailing input event generated by
        // the preceding composition commit, even if its character is identical.
        compositionCommit = null;
        beforeInputCommit = null;
        namedKeyCommit = null;
        if (keys[event.key]) {
            event.preventDefault();
            namedKeyCommit = {
                Enter: 'insertLineBreak',
                Backspace: 'deleteContentBackward',
                Delete: 'deleteContentForward',
            }[event.key];
            if (!enqueueInput({ type: 'key', name: keys[event.key] }))
                say('Hàng đợi điều khiển đã đầy');
        } else if (event.currentTarget !== textInput && event.key.length === 1) {
            // Canvas keyboard focus remains usable for accessibility and for
            // clients without an editable IME sink. The sink uses input below,
            // so keydown and input can never submit the same printable twice.
            event.preventDefault();
            enqueueText('text', event.key);
        }
    }

    function paste(event) {
        if (!acceptsTextInput()) return;
        const value = event.clipboardData?.getData('text/plain') || '';
        event.preventDefault();
        resetTextInput();
        enqueueText('paste', value);
    }

    canvas.onkeydown = keyDown;
    canvas.onpaste = paste;
    if (textInput) {
        textInput.onkeydown = keyDown;
        textInput.onpaste = paste;
        textInput.oncompositionstart = () => {
            resetTextInput();
            composing = acceptsTextInput();
        };
        textInput.oncompositionend = (event) => {
            // Blur/visibility cancellation invalidates an unfinished IME
            // transaction. A late compositionend must not type stale text.
            if (!composing || !acceptsTextInput()) {
                resetTextInput();
                return;
            }
            composing = false;
            const value = event.data || '';
            textInput.value = '';
            enqueueText('text', value);
            // Chrome can emit the final input after compositionend. Suppress
            // that one duplicate, without suppressing a subsequent keydown.
            compositionCommit = value || null;
            clearTimeout(compositionTimer);
            compositionTimer = setTimeout(() => {
                compositionCommit = null;
                compositionTimer = 0;
            }, 0);
        };
        textInput.onbeforeinput = (event) => {
            if (!acceptsTextInput() || composing || event.isComposing) return;
            if (
                event.inputType === 'insertCompositionText' ||
                event.inputType === 'insertFromComposition'
            ) {
                // The complete IME commit belongs to compositionend. Some
                // engines report another final editing event afterward.
                return;
            }
            if (compositionCommit !== null && compositionCommit === event.data) {
                event.preventDefault();
                beforeInputCommit = { type: event.inputType, data: event.data };
                compositionCommit = null;
                return;
            }
            compositionCommit = null;
            beforeInputCommit = null;
            const editingKeys = {
                insertLineBreak: 'enter',
                insertParagraph: 'enter',
                deleteContentBackward: 'backspace',
                deleteContentForward: 'delete',
            };
            const key = editingKeys[event.inputType];
            if (key) {
                event.preventDefault();
                beforeInputCommit = { type: event.inputType, data: event.data };
                const duplicateKey =
                    namedKeyCommit === event.inputType ||
                    (namedKeyCommit === 'insertLineBreak' && event.inputType === 'insertParagraph');
                namedKeyCommit = null;
                if (duplicateKey) return;
                if (!enqueueInput({ type: 'key', name: key })) say('Hàng đợi điều khiển đã đầy');
            } else if (event.inputType === 'insertText' && typeof event.data === 'string') {
                event.preventDefault();
                namedKeyCommit = null;
                beforeInputCommit = { type: event.inputType, data: event.data };
                enqueueText('text', event.data);
            }
        };
        textInput.onkeyup = () => {
            namedKeyCommit = null;
        };
        textInput.oninput = (event) => {
            if (composing || event.isComposing) return;
            const value = event.data ?? textInput.value;
            textInput.value = '';
            if (!acceptsTextInput()) return;
            if (
                event.inputType === 'insertCompositionText' ||
                event.inputType === 'insertFromComposition'
            ) {
                compositionCommit = null;
                return;
            }
            if (
                beforeInputCommit &&
                beforeInputCommit.type === event.inputType &&
                beforeInputCommit.data === event.data
            ) {
                beforeInputCommit = null;
                return;
            }
            beforeInputCommit = null;
            if (compositionCommit !== null && compositionCommit === value) {
                compositionCommit = null;
                return;
            }
            compositionCommit = null;
            if (event.inputType === 'insertFromPaste') return;
            enqueueText('text', value);
        };
        textInput.onblur = resetTextInput;
    }

    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            ready = false;
            cancelInput();
            releaseHiddenPaint();
        } else {
            // A browser scheduling pause is not evidence of a failed link.
            // Allow fresh frames before the existing watchdog judges a stall.
            if (socket && helloReceived) lastFrameAt = performance.now();
            connect();
        }
        syncVisibility(socket, generation);
    });
    window.addEventListener('offline', () => {
        if (!loopbackTransport) disconnect('Mất kết nối', false);
    });
    window.addEventListener('online', connect);
    window.addEventListener('pagehide', () => {
        suspended = true;
        disconnect('Đã tạm dừng', false);
    });
    window.addEventListener('pageshow', () => {
        suspended = false;
        connect();
    });
    window.addEventListener('blur', () => {
        inputWindowFocused = false;
        cancelInput();
    });
    window.addEventListener('focus', () => {
        inputWindowFocused = true;
    });

    connect();
})();
