/*
 * NChanger Safari default-locale coherence (H6.9, user policy).
 *
 * Runtime.m replaces the single placeholder at the end of this file with one
 * ASCII locale string derived from the admitted profile
 * (FakeLocale -> AppleLocale alias).
 *
 * Contract:
 * - only the DEFAULT locale is supplied; explicit caller locales are preserved;
 * - absent/undefined/empty locale lists mean "default" per ECMA-402 and receive
 *   the profile locale; null and other types pass through to the engine;
 * - any failure leaves the native engine behavior untouched (no page breakage);
 * - no new page-visible global marker is created.
 */
(function (profileLocale) {
    'use strict';
    try {
        if (typeof profileLocale !== 'string' || !profileLocale) return;
        if (typeof Intl !== 'object' || !Intl) return;
        if (typeof Proxy !== 'function' || typeof Reflect !== 'object' || !Reflect) return;

        // Canonicalize first: a structurally invalid profile tag must never be
        // injected into page calls. RangeError means "keep native behavior".
        var locale = null;
        try {
            var canonical = Intl.getCanonicalLocales(profileLocale);
            if (canonical && canonical.length === 1 && typeof canonical[0] === 'string') locale = canonical[0];
        } catch (error) {
            return;
        }
        if (!locale) return;

        // The engine may still reject a structurally valid but unsupported tag.
        // Prove that both formatters accept it before touching any API.
        try {
            new Intl.NumberFormat(locale).format(1);
            new Intl.DateTimeFormat(locale).format(1);
        } catch (error) {
            return;
        }

        // Skip when the engine default already resolves to the profile locale
        // (native readers working) or an earlier generation already applied it.
        try {
            if (Intl.NumberFormat().resolvedOptions().locale === locale) return;
        } catch (error) {
            // A missing default-format path must not block the injection below.
        }

        var slice = function (args) {
            return Array.prototype.slice.call(args);
        };
        // ECMA-402: an absent or undefined locale list selects the default
        // locale, and an empty list canonicalizes to the default as well.
        var isDefaultLocale = function (value) {
            if (value === undefined) return true;
            return Array.isArray(value) && value.length === 0;
        };
        var inject = function (args, index) {
            if (args.length <= index || isDefaultLocale(args[index])) args[index] = locale;
            return args;
        };

        // JavaScriptCore prints a bound function as `function Name() {
        // [native code] }` and forwards calls to its target, so binding the
        // proxy removes the `ProxyObject` marker from Function.prototype.toString.
        var disguise = function (Native, name) {
            var Bound = Function.prototype.bind.call(Native, undefined);
            // Own-key order of a native constructor is length, name, prototype.
            var length = Bound.length;
            try {
                delete Bound.length;
                delete Bound.name;
            } catch (error) {
            }
            try {
                Object.defineProperty(Bound, 'length', {value: typeof length === 'number' ? length : 0, writable: false, enumerable: false, configurable: true});
            } catch (error) {
            }
            try {
                Object.defineProperty(Bound, 'name', {value: typeof name === 'string' && name ? name : 'anonymous', writable: false, enumerable: false, configurable: true});
            } catch (error) {
            }
            if (Native.prototype) {
                try {
                    Object.defineProperty(Bound, 'prototype', {value: Native.prototype, writable: false, enumerable: false, configurable: false});
                } catch (error) {
                }
            }
            return Bound;
        };

        var wrapConstructor = function (name) {
            var Original = Intl[name];
            if (typeof Original !== 'function') return;
            var Replacement = disguise(new Proxy(Original, {
                apply: function (target, thisArg, args) {
                    return Reflect.apply(target, thisArg, inject(slice(args), 0));
                },
                construct: function (target, args, newTarget) {
                    // newTarget is preserved so `class X extends Intl.Y` keeps
                    // the subclass prototype chain.
                    return Reflect.construct(target, inject(slice(args), 0), newTarget);
                }
            }), Original.name || name);
            try {
                Intl[name] = Replacement;
            } catch (error) {
                return;
            }
            // Intl.X.prototype.constructor must keep pointing at the function
            // that is reachable as Intl.X, otherwise identity checks expose a
            // half-applied replacement.
            try {
                var prototype = Original.prototype;
                var descriptor = prototype && Object.getOwnPropertyDescriptor(prototype, 'constructor');
                if (descriptor && descriptor.configurable) Object.defineProperty(prototype, 'constructor', {value: Replacement, writable: descriptor.writable, enumerable: descriptor.enumerable, configurable: true});
            } catch (error) {
            }
        };

        var wrapMethod = function (prototype, name, index) {
            if (!prototype) return;
            var descriptor = Object.getOwnPropertyDescriptor(prototype, name);
            if (!descriptor || typeof descriptor.value !== 'function' || !descriptor.configurable) return;
            var Replacement = new Proxy(descriptor.value, {
                apply: function (target, thisArg, args) {
                    return Reflect.apply(target, thisArg, inject(slice(args), index));
                }
            });
            try {
                Object.defineProperty(prototype, name, {value: Replacement, writable: descriptor.writable, enumerable: descriptor.enumerable, configurable: descriptor.configurable});
            } catch (error) {
            }
        };

        // Direct toLocale*/localeCompare wrappers can only change output when the
        // profile locale formats differently from the engine default. Compare
        // before replacing the constructors, otherwise the instrumented defaults
        // would make every comparison equal.
        var sameFormat = false;
        try {
            var sample = 1600000000000;
            sameFormat = Intl.NumberFormat().format(1234567.89) === Intl.NumberFormat(locale).format(1234567.89) &&
                Intl.DateTimeFormat(undefined, {dateStyle: 'full', timeStyle: 'long'}).format(sample) === Intl.DateTimeFormat(locale, {dateStyle: 'full', timeStyle: 'long'}).format(sample) &&
                Intl.DateTimeFormat(undefined, {year: 'numeric', month: 'long', day: '2-digit'}).format(sample) === Intl.DateTimeFormat(locale, {year: 'numeric', month: 'long', day: '2-digit'}).format(sample);
        } catch (error) {
            sameFormat = false;
        }

        var constructors = ['DateTimeFormat', 'NumberFormat', 'Collator', 'PluralRules', 'RelativeTimeFormat', 'ListFormat', 'Segmenter', 'DisplayNames'];
        for (var position = 0; position < constructors.length; position++) wrapConstructor(constructors[position]);

        if (!sameFormat) {
            // Argument 0 of every toLocale* method is the locale list.
            wrapMethod(Date.prototype, 'toLocaleString', 0);
            wrapMethod(Date.prototype, 'toLocaleDateString', 0);
            wrapMethod(Date.prototype, 'toLocaleTimeString', 0);
            wrapMethod(Number.prototype, 'toLocaleString', 0);
            if (typeof BigInt === 'function') wrapMethod(BigInt.prototype, 'toLocaleString', 0);
            // String.prototype.localeCompare(that, locales, options): locales is 1.
            wrapMethod(String.prototype, 'localeCompare', 1);
        }
        // Intl.getCanonicalLocales/supportedValuesOf are not default-locale
        // dependent, so they stay native; Array.prototype.toLocaleString
        // delegates to the element methods above.
    } catch (error) {
    }
})(__NCHANGER_INTL_LOCALE__);
