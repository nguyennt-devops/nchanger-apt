/**
 * Web IDE classic-script entry point.
 *
 * Sections follow the existing evaluation order: shared state, startup,
 * preferences, editor/runtime controls, files, SDK catalog, helper forms and
 * live-screen/DOM tools. Keep global handler names used by HTML compatible.
 * Cleanup changes layout and verified helper boundaries only; API payloads,
 * localization, browser storage, request order and fallback behavior remain.
 */

// -----------------------------------------------------------------------------
// Shared state and configuration
// State remains shared with the existing handlers. Keep persisted key IDs stable.
// -----------------------------------------------------------------------------

const state = {
    currentDevice: null,
    devices: [],
    runningTaskId: null,
    logPollInterval: null,
    lastLogIndex: 0,
    screenScale: { x: 1, y: 1 },
    screenSize: { w: 390, h: 844 },
    wdaPoints: { w: 390, h: 844 },
    deviceScale: 3,
    editor: null,
    helperActive: false,
    helperMode: 'single',
    pickedColors: [],
    regionStart: null,
    currentFileName: null,
    recording: false,
    recordedGestures: [],
    openTabs: [],
    activeTabId: null,
};

const API = '';

/** Alang /api/tap|/color dùng points — screenshot overlay trả pixel. */
// -----------------------------------------------------------------------------
// Coordinate conversion
// Screen overlays use pixels; device input APIs consume points.
// -----------------------------------------------------------------------------

/** Use the reported positive device scale; retain the existing fallback of 3. */
function _deviceScale() {
    const scale = Number(state.deviceScale);
    return scale > 0 ? scale : 3;
}

/** Round screenshot pixels to device points with the existing Math.round behavior. */
function _pxToPt(x, y) {
    const scale = _deviceScale();
    return { x: Math.round(Number(x) / scale), y: Math.round(Number(y) / scale) };
}

/** Convert rectangle origin and dimensions independently; preserve component order. */
function _pxRectToPt(rx, ry, rw, rh) {
    const scale = _deviceScale();
    return [
        Math.round(Number(rx) / scale),
        Math.round(Number(ry) / scale),
        Math.round(Number(rw) / scale),
        Math.round(Number(rh) / scale),
    ];
}

// -----------------------------------------------------------------------------
// Browser preferences and console icons
// -----------------------------------------------------------------------------

const STORAGE_KEYS = {
    theme: 'nauto-theme',
    lang: 'nauto-lang',
};

const EMOJI_MAP = {
    '📱': 'smartphone',
    '📐': 'ruler',
    '📺': 'monitor',
    '✅': 'check-circle',
    '❌': 'x-circle',
    '⚠️': 'alert-triangle',
    '▶️': 'play',
    '⏹️': 'square',
    '🔄': 'refresh-cw',
    '⬇️': 'arrow-down-to-line',
    '💾': 'save',
    '🗑️': 'trash-2',
    '📂': 'folder-open',
    '📋': 'clipboard',
    '📸': 'camera',
    '🔧': 'wrench',
    '⏱️': 'timer',
    '✏️': 'pencil',
    '🎯': 'crosshair',
    '⌨️': 'keyboard',
    '🔥': 'flame',
    '🔍': 'search',
    '🎨': 'palette',
    '💡': 'lightbulb',
};

// -----------------------------------------------------------------------------
// Shared formatting utilities
// -----------------------------------------------------------------------------

function formatTime(date) {
    return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}:${date.getSeconds().toString().padStart(2, '0')}`;
}

function capConsoleDOMLines(container, maxLines) {
    const allLines = container.querySelectorAll('.console-line');
    if (allLines.length > maxLines) {
        const toRemove = allLines.length - maxLines;
        for (let i = 0; i < toRemove; i++) {
            allLines[i].remove();
        }
    }
}

function generateScriptName(prefix = 'script_') {
    const date = new Date();
    return `${prefix}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}_${String(date.getHours()).padStart(2, '0')}${String(date.getMinutes()).padStart(2, '0')}`;
}

// Trạng thái nút chạy script — 1 nguồn sự thật duy nhất.
// "idle"    = chưa chạy → hiện nút Bắt đầu
// "running" = đang chạy → hiện nút Dừng
// "pending" = vừa bấm, đang chờ daemon xác nhận → nút mờ + chữ "Đang xử lý…"
// -----------------------------------------------------------------------------
// Script run state and initial page startup
// Preserve the listener registration order and the existing pending/running gates.
// -----------------------------------------------------------------------------

let _runBtnMode = null; // nhớ trạng thái nút hiện tại để tránh đổi/redraw thừa
let _runRequestBusy = false;

function _syncRunRequestButton() {
    const runBtn = document.getElementById('runBtn');
    if (!runBtn) {
        return;
    }
    const pending = _runRequestBusy || _runBtnMode === 'pending';
    runBtn.disabled = pending;
    runBtn.style.opacity = pending ? '0.5' : '1';
}

/** Admit one run request at a time and keep the pending button synchronized. */
function _beginRunRequest() {
    if (_runRequestBusy) {
        appendLog(_l('A run request is already pending', 'Đang chờ yêu cầu chạy trước'), 'warn');
        return false;
    }
    _runRequestBusy = true;
    _syncRunRequestButton();
    return true;
}

function _endRunRequest() {
    _runRequestBusy = false;
    _syncRunRequestButton();
}

/** Keep boolean-call compatibility and avoid redrawing an unchanged run state. */
function setRunButtonsState(mode) {
    // Tương thích ngược: gọi với true/false cũng hiểu được
    if (mode === true) {
        mode = 'running';
    } else if (mode === false) {
        mode = 'idle';
    }
    if (mode === _runBtnMode) {
        return;
    } // không đổi gì → bỏ qua (chống nhấp nháy)
    _runBtnMode = mode;
    const runBtn = document.getElementById('runBtn');
    const stopBtn = document.getElementById('stopBtn');
    const running = mode === 'running';
    const pending = mode === 'pending';
    if (runBtn) {
        runBtn.style.display = running ? 'none' : 'flex';
        runBtn.disabled = pending;
        runBtn.style.opacity = pending ? '0.5' : '1';
    }
    if (stopBtn) {
        stopBtn.style.display = running ? 'flex' : 'none';
        stopBtn.disabled = pending;
        stopBtn.style.opacity = pending ? '0.5' : '1';
    }
    _syncRunRequestButton();
}

document.addEventListener('DOMContentLoaded', () => {
    const safeInit = (name, fn) => {
        try {
            fn();
        } catch (e) {
            console.warn(`⚠️ ${name} failed:`, e);
        }
    };
    safeInit('theme', initIDETheme);
    safeInit('lang', initIDELang);
    safeInit('tabs', initTabs);
    safeInit('monaco', initMonacoEditor);
    safeInit('liveScreen', initLiveScreen);
    safeInit('console', initConsole);
    safeInit('modals', initModals);
    safeInit('shortcuts', initKeyboardShortcuts);
    safeInit('sdkCatalog', initSdkCatalog);
    safeInit('helperEdge', initHelperEdgeResizer);
    refreshDevices();
    safeInit('setup', checkSystemSetup);
    checkRunningScript();
    // Pre-load scripts so they're ready when user clicks Files tab
    loadScriptFiles().catch((e) => console.warn('Pre-load scripts failed:', e));
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
});

// -----------------------------------------------------------------------------
// Helper panel layout, clipboard and toast
// -----------------------------------------------------------------------------

function initHelperEdgeResizer() {
    const resizer = document.getElementById('helperEdgeResizer');
    const panel = document.getElementById('helperModal');
    if (!resizer || !panel) {
        return;
    }

    const sync = () => resizer.classList.toggle('visible', panel.classList.contains('helper-open'));
    sync();
    new MutationObserver(sync).observe(panel, { attributes: true, attributeFilter: ['class'] });

    let startX;
    let startW;
    resizer.addEventListener('mousedown', (e) => {
        if (e.target.closest('#helperToggleBtn')) {
            return;
        }
        if (!panel.classList.contains('helper-open')) {
            return;
        }
        startX = e.clientX;
        startW = panel.offsetWidth;
        resizer.classList.add('dragging');
        const onMove = (ev) => {
            const w = startW + (ev.clientX - startX);
            if (w >= 240 && w <= window.innerWidth * 0.8) {
                panel.style.width = w + 'px';
                if (state.editor) {
                    state.editor.layout();
                }
            }
        };
        const onUp = () => {
            resizer.classList.remove('dragging');
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
        e.preventDefault();
    });
}

window.toggleHelperPanel = function () {
    const m = document.getElementById('helperModal');
    if (!m) {
        return;
    }
    if (m.classList.contains('helper-open')) {
        if (typeof window._closeHelperPanel === 'function') {
            window._closeHelperPanel();
        } else {
            m.classList.remove('helper-open');
        }
    } else {
        if (typeof window._openHelperPanel === 'function') {
            window._openHelperPanel();
        } else {
            m.classList.add('helper-open');
            if (typeof window._buildHelperAccordion === 'function') {
                window._buildHelperAccordion();
            }
        }
    }
    setTimeout(() => {
        if (state.editor) {
            state.editor.layout();
        }
    }, 350);
};

function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        return navigator.clipboard.writeText(text);
    }
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;left:-9999px;top:-9999px;';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    return Promise.resolve();
}

function _hmDoCopy(text) {
    const copiedText = text == null ? '' : String(text);
    copyToClipboard(copiedText);
    appendLog(_t('copyLog') + (copiedText.split('\n')[0] || ''), 'success');
}

function show_toast(message, duration = 1500) {
    const existing = document.getElementById('ideToast');
    if (existing) {
        existing.remove();
    }
    const toast = document.createElement('div');
    toast.id = 'ideToast';
    toast.textContent = message;
    toast.style.cssText = `
    position: fixed; bottom: 24px; right: 24px; z-index: 99999;
    background: var(--accent-gradient); color: #fff;
    padding: 10px 20px; border-radius: 8px;
    font-size: 13px; font-weight: 600; font-family: var(--font-sans);
    box-shadow: 0 4px 20px rgba(99,102,241,0.4);
    opacity: 0; transform: translateY(10px);
    transition: opacity 0.2s ease, transform 0.2s ease;
    pointer-events: none;
  `;
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    });
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(() => toast.remove(), 200);
    }, duration);
}

// -----------------------------------------------------------------------------
// Theme preferences
// -----------------------------------------------------------------------------

let ideTheme =
    (localStorage.getItem(STORAGE_KEYS.theme) ?? localStorage.getItem('iosauto-theme')) || 'dark';

function _applyServerTheme(data) {
    const serverTheme = data && data.theme;
    if (serverTheme !== 'light' && serverTheme !== 'dark') {
        return;
    }
    if (serverTheme === ideTheme) {
        return;
    }
    ideTheme = serverTheme;
    applyIDETheme();
}

function initIDETheme() {
    applyIDETheme();
    document.getElementById('ideThemeToggle')?.addEventListener('click', () => {
        ideTheme = ideTheme === 'dark' ? 'light' : 'dark';
        applyIDETheme();
        fetch(`${API}/api/theme`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ theme: ideTheme }),
        }).catch(() => {});
    });
}

function applyIDETheme() {
    document.documentElement.setAttribute('data-theme', ideTheme);
    const icon = document.getElementById('ideThemeIcon');
    if (icon) {
        icon.innerHTML = `<i data-lucide="${ideTheme === 'dark' ? 'moon' : 'sun'}" style="width:16px;height:16px;"></i>`;
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }
    localStorage.setItem(STORAGE_KEYS.theme, ideTheme);
    if (window.monaco) {
        monaco.editor.setTheme(ideTheme === 'dark' ? 'na-dark' : 'vs');
    }
}

// -----------------------------------------------------------------------------
// Language preferences and interface translations
// -----------------------------------------------------------------------------

const IDE_LANGS = ['en', 'vi', 'zh'];
let ideLang =
    (localStorage.getItem(STORAGE_KEYS.lang) ?? localStorage.getItem('iosauto-lang')) || 'en';
if (!IDE_LANGS.includes(ideLang)) {
    ideLang = 'en';
}

const IDE_I18N = {
    en: {
        screen: 'Screen',
        helper: 'Helper',
        noDevice: 'No device connected',
        scriptEditor: 'Write Code',
        files: 'Files',
        images: 'Images',
        console: 'Console',
        consoleLbl: 'Console',
        run: 'Run',
        stop: 'Stop',
        save: 'Save',
        clear: 'Clear',
        quickCmd: 'Run quick command',
        images: 'Images',
        hTabFunctions: 'Functions',
        searchFunctions: '🔍 Search functions (e.g. tap, color, app...)',
        screenPreview: 'Screen Preview',
        connectDevice: 'Connect a device to see screen',
        output: 'Log',
        welcomeTitle: 'Welcome to <strong>NAuto IDE</strong>',
        welcomeConnect: 'Connect an iPhone via USB to get started.',
        welcomeRun:
            'Write scripts in the editor and press <kbd>Run</kbd> or <kbd>Ctrl+Enter</kbd>.',
        saveScriptTitle: 'Save Script',
        scriptName: 'Script Name',
        saveBtn: 'Save',
        imgGalleryTitle: 'Image Gallery',
        imgGalleryDesc: 'Manage images on iPhone · Crop & save · Copy path to script',
        imgOnDevice: 'Images on device',
        imgNone: 'No images yet',
        imgHint: 'Press <b>Capture</b> or <b>Vol Up ×3</b> on iPhone',
        imgCrop: 'Crop',
        imgCapture: 'Capture',
        imgCropTitle: 'Drag to select crop area',
        imgCancel: 'Cancel',
        imgSaveToPhone: 'Save to iPhone',
        installedApps: 'Installed Apps',
        searchApps: 'Search apps...',
        loadingApps: 'Loading apps...',
        clickConnect: 'Click <b>Connect</b> to stream',
        vncLive: 'VNC Live',
        helperTools: 'Helper Tools',
        modeControl: 'Control',
        modePick: 'Write Code',
        newScript: 'New',
        newFolder: 'Folder',
        encTitle: 'Encrypt',
        encHint: 'Encrypt script to .aios — any device with NAuto can run.',
        encBtn: 'Encrypt',
        noScripts: 'No saved scripts yet',
        copy: 'Copy',
        editor: 'Editor',
        smartConvert: 'Smart Convert',
        paste: 'Paste',
        deviceInfo: 'Device Information',
        noDeviceInfo: 'No device connected',
        screenshot: 'Screenshot',
        close: 'Close',
        loadingScreenshot: 'Loading screenshot...',
        hTabColor: 'Color',
        hTabImage: 'Image',
        hTabApps: 'Apps',
        searchApps2: 'Search apps...',
        hmSearchPlaceholder: '🔍 Find function (e.g. tap, color, app...)',
        hmPickPoint: '👉 Click 1 point on screen',
        hmPickRegion: '👉 Click 2 points: top-left and bottom-right of region',
        hmPickPointTooltip: 'Click on screen to capture coordinates',
        hmPickRegionTooltip: 'Drag to select region',
        hmBtnDom: 'Scan',
        hmBtnDomTip: 'Scan Safari page → pick a field/button',
        hmBtnAx: '👁 Scan UI',
        hmBtnAxTip: 'Scan on-screen controls in the foreground app → pick (like OCR)',
        hmBtnOcr: '📖 Scan text',
        hmBtnOcrTip: 'Scan text from current screen → pick',
        hmBtnRandom: '🎲 Random',
        hmBtnRandomTip: 'Enter a list → script picks one at random when run',
        hmBtnCrop: '✂️ Crop image',
        hmBtnCropTip: 'Crop image from current screen — saves PNG to images folder',
        hmBtnPickPoint: '📍 Pick point',
        hmBtnPickRegion: '📍 Pick region',
        hmBtnPickColor: '🎨 Pick color from screen',
        hmBtnCopy: 'Copy',
        hmBtnInsert: '➕ Add to Script',
        hintX: 'X position (left→right)',
        hintY: 'Y position (top→bottom)',
        hintDuration: 'seconds, e.g. 0.3',
        hintSeconds: 'seconds, e.g. 1',
        hintTimeout: 'max wait (seconds)',
        hintInterval: 'check every (seconds)',
        hintDelaySec: 'delay between keys (sec), e.g. 0.08–0.15',
        hintType: '1=red 2=yellow 3=white 4=green',
        hintText: 'text to show',
        hintTitle: 'title',
        hintMessage: 'description',
        hintUrl: 'https://...',
        hintPath: 'file path',
        hintBundle: 'app id, e.g. com.apple...',
        hintLabel: 'field/button name',
        hintValue: 'value to fill',
        hintCommand: 'shell command',
        hintSize: 'pixels',
        hintFinger: '1-5',
        hintMatch: '0.9 or 90 — OCR match ratio',
        hmLoadingSdk: '⏳ Loading SDK...',
        catTouch: 'Touch',
        catKeyboard: 'Keyboard',
        catClipboard: 'Clipboard',
        catColor: 'Color',
        catImage: 'Image',
        catVCam: 'VCam',
        catOCR: 'OCR',
        catSystem: 'System',
        catApp: 'App',
        catFile: 'File',
        catNetwork: 'Network',
        catSleep: 'Sleep',
        catUI: 'Feedback',
        catPower: 'Screen',
        catRecording: 'Recording',
        catCron: 'Schedule',
        catScript: 'Script',
        catSafari: 'Safari Web',
        catLang: 'Language',
        imgUpload: 'Script folder',
        imgCountLabel: 'images',
        albumImport: 'Phone Photos',
        albumImportOk: 'Saved to Photos: ',
        albumImportFail: 'Photos save failed: ',
        albumImportDone: 'Photos done ',
        vcamImport: 'VCam',
        vcamImportOk: 'VCam on: ',
        vcamImportFail: 'VCam failed: ',
        imgEmpty: 'No images — click Upload to add',
        imgCopied: 'Copied: ',
        imgDeleteConfirm: 'Delete image ',
        imgDeleteLabel: 'Delete image',
        imgDeleteFail: '❌ Delete failed: ',
        imgUploadOk: '✓ Uploaded ',
        imgUploadFail: '❌ Upload failed: ',
        imgLoadErr: 'Error loading images: ',
        insertLog: '⬇️ Inserted: ',
        copyLog: 'Copied: ',
        hmTitle: 'Title',
        hmContent: 'Text',
        hmDuration: 'Duration',
        hmColor: 'Color',
        hmBg: 'Background',
        hmFg: 'Text color',
        hmToastPh: 'Toast text',
        hmCopiedToast: 'Copied',
        hmDefault: 'Default',
        hmButtons: 'Buttons',
        hmBtnBg: 'Button bg',
        hmBtnFg: 'Button text',
        randTabList: 'List',
        randTabEmail: 'Email',
        randListHint: 'One item per line — script picks one at run',
        randPrefixHint: 'Prefix (before @) — built from charset',
        randLen: 'Length',
        randChars: 'chars',
        randDomainHint: 'Domain (after @) — one per line',
    },
    vi: {
        screen: 'M.Hình',
        helper: 'Trợ giúp',
        noDevice: 'Chưa kết nối',
        scriptEditor: 'Viết lệnh',
        files: 'Tệp',
        images: 'Ảnh',
        console: 'Bảng đk',
        consoleLbl: 'Bảng đk',
        run: 'Chạy',
        stop: 'Dừng',
        save: 'Lưu',
        clear: 'Xoá',
        quickCmd: 'Chạy lệnh ngắn',
        images: 'Ảnh',
        hTabFunctions: 'Hàm',
        searchFunctions: '🔍 Tìm hàm (vd: tap, color, app...)',
        screenPreview: 'Xem màn hình',
        connectDevice: 'Kết nối thiết bị để xem',
        output: 'Nhật ký',
        welcomeTitle: 'Chào mừng đến <strong>NAuto IDE</strong>',
        welcomeConnect: 'Kết nối iPhone qua USB để bắt đầu.',
        welcomeRun:
            'Viết script trong trình soạn thảo và nhấn <kbd>Chạy</kbd> hoặc <kbd>Ctrl+Enter</kbd>.',
        saveScriptTitle: 'Lưu Script',
        scriptName: 'Tên Script',
        saveBtn: 'Lưu',
        imgGalleryTitle: 'Thư viện ảnh',
        imgGalleryDesc: 'Quản lý ảnh trên iPhone · Cắt & lưu · Copy đường dẫn vào script',
        imgOnDevice: 'Ảnh trên thiết bị',
        imgNone: 'Chưa có ảnh',
        imgHint: 'Bấm <b>Chụp</b> hoặc <b>Vol Up ×3</b> trên iPhone',
        imgCrop: 'Cắt',
        imgCapture: 'Chụp',
        imgCropTitle: 'Kéo chọn vùng cần cắt',
        imgCancel: 'Huỷ',
        imgSaveToPhone: 'Lưu vào iPhone',
        installedApps: 'Ứng dụng đã cài',
        searchApps: 'Tìm ứng dụng...',
        loadingApps: 'Đang tải...',
        clickConnect: 'Bấm <b>Kết nối</b> để xem',
        vncLive: 'Trực tiếp',
        helperTools: 'Công cụ hỗ trợ',
        modeControl: 'Điều khiển',
        modePick: 'Viết lệnh',
        newScript: 'Tạo mới',
        newFolder: 'Thư mục',
        encTitle: 'Mã hoá',
        encHint: 'Mã hoá script thành .aios — máy nào có NAuto đều chạy được.',
        encBtn: 'Mã hoá',
        noScripts: 'Chưa có script nào',
        copy: 'Copy',
        editor: 'Editor',
        smartConvert: 'Chuyển đổi thông minh',
        paste: 'Dán',
        deviceInfo: 'Thông tin thiết bị',
        noDeviceInfo: 'Chưa kết nối thiết bị',
        screenshot: 'Chụp màn hình',
        close: 'Đóng',
        loadingScreenshot: 'Đang tải ảnh...',
        hTabColor: 'Màu',
        hTabImage: 'Ảnh',
        hTabApps: 'Ứng dụng',
        searchApps2: 'Tìm ứng dụng...',
        hmSearchPlaceholder: '🔍 Tìm hàm (vd: tap, color, app...)',
        hmPickPoint: '👉 Click 1 điểm trên ảnh',
        hmPickRegion: '👉 Click 2 điểm: góc trên-trái và dưới-phải của vùng',
        hmPickPointTooltip: 'Click trên màn hình để lấy toạ độ',
        hmPickRegionTooltip: 'Kéo chọn vùng',
        hmBtnDom: 'Quét',
        hmBtnDomTip: 'Quét trang Safari → chọn ô/nút có sẵn',
        hmBtnAx: '👁 Quét UI',
        hmBtnAxTip: 'Quét nút/ô trên app đang mở → chọn (giống Quét chữ)',
        hmBtnOcr: '📖 Quét chữ',
        hmBtnOcrTip: 'Quét chữ từ màn hình hiện tại → chọn',
        hmBtnRandom: '🎲 Ngẫu nhiên',
        hmBtnRandomTip: 'Nhập danh sách → script chọn ngẫu nhiên 1 mục khi chạy',
        hmBtnCrop: '✂️ Cắt ảnh',
        hmBtnCropTip: 'Cắt ảnh từ màn hình hiện tại — lưu PNG vào thư mục images',
        hmBtnPickPoint: '📍 Chọn điểm',
        hmBtnPickRegion: '📍 Chọn vùng',
        hmBtnPickColor: '🎨 Lấy màu từ màn hình',
        hmBtnCopy: 'Copy',
        hmBtnInsert: '➕ Thêm vào lệnh',
        hintX: 'Toạ độ X (trái→phải)',
        hintY: 'Toạ độ Y (trên→dưới)',
        hintDuration: 'giây, vd: 0.3',
        hintSeconds: 'giây, vd: 1',
        hintTimeout: 'chờ tối đa (giây)',
        hintInterval: 'kiểm tra mỗi (giây)',
        hintDelaySec: 'nghỉ giữa ký tự (giây), vd: 0.08–0.15',
        hintType: '1=đỏ 2=vàng 3=trắng 4=xanh',
        hintText: 'nội dung hiển thị',
        hintTitle: 'tiêu đề',
        hintMessage: 'mô tả',
        hintUrl: 'https://...',
        hintPath: 'đường dẫn tệp',
        hintBundle: 'id app, vd: com.apple...',
        hintLabel: 'tên ô/nút',
        hintValue: 'giá trị cần điền',
        hintCommand: 'lệnh shell',
        hintSize: 'pixel',
        hintFinger: '1-5',
        hintMatch: '0.9 hoặc 90 — tỉ lệ khớp OCR',
        hmLoadingSdk: '⏳ Đang tải SDK...',
        catTouch: 'Chạm/Vuốt',
        catKeyboard: 'Bàn phím',
        catClipboard: 'Bộ nhớ tạm',
        catColor: 'Màu',
        catImage: 'Ảnh',
        catVCam: 'VCam',
        catOCR: 'Đọc chữ',
        catSystem: 'Hệ thống',
        catApp: 'Ứng dụng',
        catFile: 'Tệp',
        catNetwork: 'Mạng',
        catSleep: 'Nghỉ',
        catUI: 'Thông báo',
        catPower: 'Màn hình',
        catRecording: 'Ghi',
        catCron: 'Lịch',
        catScript: 'Kịch bản',
        catSafari: 'Safari Web',
        catLang: 'Ngôn ngữ',
        imgUpload: 'Thư mục script',
        imgCountLabel: 'ảnh',
        albumImport: 'Ảnh máy',
        albumImportOk: 'Đã vào Ảnh: ',
        albumImportFail: 'Lưu Ảnh thất bại: ',
        albumImportDone: 'Xong Ảnh ',
        vcamImport: 'Camera ảo',
        vcamImportOk: 'Đã bật VCam: ',
        vcamImportFail: 'VCam lỗi: ',
        imgEmpty: 'Chưa có ảnh — bấm Upload để tải lên',
        imgCopied: 'Copied: ',
        imgDeleteConfirm: 'Xoá ảnh ',
        imgDeleteLabel: 'Xoá ảnh',
        imgDeleteFail: '❌ Xoá ảnh thất bại: ',
        imgUploadOk: '✓ Tải lên ',
        imgUploadFail: '❌ Tải lên thất bại: ',
        imgLoadErr: 'Lỗi tải ảnh: ',
        insertLog: '⬇️ Đã chèn: ',
        copyLog: 'Copied: ',
        hmTitle: 'Tiêu đề',
        hmContent: 'Nội dung',
        hmDuration: 'Thời gian',
        hmColor: 'Màu',
        hmBg: 'Màu nền',
        hmFg: 'Màu chữ',
        hmToastPh: 'Nội dung toast',
        hmCopiedToast: 'Copied',
        hmDefault: 'Mặc định',
        hmButtons: 'Nút',
        hmBtnBg: 'Nút nền',
        hmBtnFg: 'Nút chữ',
        randTabList: 'Danh sách',
        randTabEmail: 'Email',
        randListHint: 'Mỗi dòng 1 mục — script chọn ngẫu nhiên khi chạy',
        randPrefixHint: 'Phần trước @ — ghép từ bộ ký tự',
        randLen: 'Độ dài',
        randChars: 'ký tự',
        randDomainHint: 'Phần sau @ — mỗi dòng 1 domain',
    },
    zh: {
        screen: '屏幕',
        helper: '助手',
        noDevice: '未连接设备',
        scriptEditor: '写脚本',
        files: '文件',
        images: '图片',
        console: '控制台',
        consoleLbl: '控制台',
        run: '运行',
        stop: '停止',
        save: '保存',
        clear: '清除',
        quickCmd: '运行快捷命令',
        hTabFunctions: '函数',
        searchFunctions: '🔍 搜索函数（如 tap、color、app）',
        screenPreview: '屏幕预览',
        connectDevice: '连接设备后可查看屏幕',
        output: '日志',
        welcomeTitle: '欢迎使用 <strong>NAuto IDE</strong>',
        welcomeConnect: '通过 USB 连接 iPhone 即可开始。',
        welcomeRun: '在编辑器中写脚本，按 <kbd>运行</kbd> 或 <kbd>Ctrl+Enter</kbd>。',
        saveScriptTitle: '保存脚本',
        scriptName: '脚本名称',
        saveBtn: '保存',
        imgGalleryTitle: '图片库',
        imgGalleryDesc: '管理 iPhone 上的图片 · 裁剪保存 · 复制路径到脚本',
        imgOnDevice: '设备上的图片',
        imgNone: '暂无图片',
        imgHint: '点 <b>截图</b> 或在 iPhone 上 <b>音量+ ×3</b>',
        imgCrop: '裁剪',
        imgCapture: '截图',
        imgCropTitle: '拖选裁剪区域',
        imgCancel: '取消',
        imgSaveToPhone: '保存到 iPhone',
        installedApps: '已安装应用',
        searchApps: '搜索应用…',
        loadingApps: '加载中…',
        clickConnect: '点击 <b>连接</b> 开始推流',
        vncLive: 'VNC 实时',
        helperTools: '辅助工具',
        modeControl: '控制',
        modePick: '写脚本',
        newScript: '新建',
        newFolder: '文件夹',
        encTitle: '加密',
        encHint: '加密为 .aios — 任何安装 NAuto 的设备都能运行。',
        encBtn: '加密',
        noScripts: '还没有已保存的脚本',
        copy: 'Copy',
        editor: '编辑器',
        smartConvert: '智能转换',
        paste: '粘贴',
        deviceInfo: '设备信息',
        noDeviceInfo: '未连接设备',
        screenshot: '截图',
        close: '关闭',
        loadingScreenshot: '正在加载截图…',
        hTabColor: '颜色',
        hTabImage: '图片',
        hTabApps: '应用',
        searchApps2: '搜索应用…',
        hmSearchPlaceholder: '🔍 查找函数（如 tap、color、app）',
        hmPickPoint: '👉 在屏幕上点 1 个位置',
        hmPickRegion: '👉 点 2 个位置：区域左上和右下',
        hmPickPointTooltip: '点击屏幕获取坐标',
        hmPickRegionTooltip: '拖选区域',
        hmBtnDom: '扫描',
        hmBtnDomTip: '扫描 Safari 页面 → 选择输入框/按钮',
        hmBtnAx: '👁 扫描界面',
        hmBtnAxTip: '扫描前台应用控件 → 选择（类似 OCR）',
        hmBtnOcr: '📖 扫描文字',
        hmBtnOcrTip: '从当前屏幕识别文字 → 选择',
        hmBtnRandom: '🎲 随机',
        hmBtnRandomTip: '输入列表 → 运行时随机选一项',
        hmBtnCrop: '✂️ 裁剪图片',
        hmBtnCropTip: '从当前屏幕裁剪 — 保存 PNG 到 images',
        hmBtnPickPoint: '📍 选点',
        hmBtnPickRegion: '📍 选区域',
        hmBtnPickColor: '🎨 从屏幕取色',
        hmBtnCopy: 'Copy',
        hmBtnInsert: '➕ 插入脚本',
        hintX: 'X 坐标（左→右）',
        hintY: 'Y 坐标（上→下）',
        hintDuration: '秒，例如 0.3',
        hintSeconds: '秒，例如 1',
        hintTimeout: '最长等待（秒）',
        hintInterval: '检查间隔（秒）',
        hintDelaySec: '按键间隔（秒），例如 0.08–0.15',
        hintType: '1=红 2=黄 3=白 4=绿',
        hintText: '要显示的文字',
        hintTitle: '标题',
        hintMessage: '说明',
        hintUrl: 'https://...',
        hintPath: '文件路径',
        hintBundle: '应用 ID，例如 com.apple...',
        hintLabel: '控件/按钮名称',
        hintValue: '要填入的值',
        hintCommand: 'shell 命令',
        hintSize: '像素',
        hintFinger: '1-5',
        hintMatch: '0.9 或 90 — OCR 匹配度',
        hmLoadingSdk: '⏳ 正在加载 SDK…',
        catTouch: '触摸/滑动',
        catKeyboard: '键盘',
        catClipboard: '剪贴板',
        catColor: '颜色',
        catImage: '图片',
        catVCam: '虚拟摄像头',
        catOCR: '识字',
        catSystem: '系统',
        catApp: '应用',
        catFile: '文件',
        catNetwork: '网络',
        catSleep: '等待',
        catUI: '提示',
        catPower: '屏幕',
        catRecording: '录制',
        catCron: '计划',
        catScript: '脚本',
        catSafari: 'Safari 网页',
        catLang: '语言',
        imgUpload: '脚本目录',
        imgCountLabel: '张图片',
        albumImport: '手机相册',
        albumImportOk: '已保存到相册: ',
        albumImportFail: '保存相册失败: ',
        albumImportDone: '相册完成 ',
        vcamImport: '虚拟摄像头',
        vcamImportOk: '已开 VCam: ',
        vcamImportFail: 'VCam 失败: ',
        imgEmpty: '暂无图片 — 点上传添加',
        imgCopied: '📋 已复制：',
        imgDeleteConfirm: '删除图片 ',
        imgDeleteLabel: '删除图片',
        imgDeleteFail: '❌ 删除失败：',
        imgUploadOk: '✓ 已上传 ',
        imgUploadFail: '❌ 上传失败：',
        imgLoadErr: '加载图片出错：',
        insertLog: '⬇️ 已插入：',
        copyLog: '📋 已复制：',
        hmTitle: '标题',
        hmContent: '内容',
        hmDuration: '时长',
        hmColor: '颜色',
        hmBg: '背景',
        hmFg: '文字色',
        hmToastPh: '提示文字',
        hmCopiedToast: '已复制',
        hmDefault: '默认',
        hmButtons: '按钮',
        hmBtnBg: '按钮背景',
        hmBtnFg: '按钮文字',
        randTabList: '列表',
        randTabEmail: '邮箱',
        randListHint: '每行一项 — 运行时随机选一项',
        randPrefixHint: '@ 前缀 — 由字符集生成',
        randLen: '长度',
        randChars: '字符',
        randDomainHint: '@ 后缀 — 每行一个域名',
    },
};

function _t(key, fallback) {
    const translations = IDE_I18N[ideLang] || IDE_I18N.en;
    return translations[key] || fallback || key;
}

function _l(en, vi, zh) {
    if (ideLang === 'vi') {
        return vi;
    }
    if (ideLang === 'zh') {
        return zh != null && zh !== '' ? zh : en;
    }
    return en;
}

function _displaySig(sig) {
    return String(sig || '()')
        .replace(/\s*(—|\/\/).*$/, '')
        .trim();
}

/** Select the current language table, then retain the unqualified-name and caller fallbacks. */
function _sdkDoc(name, fallback) {
    const descriptions =
        ideLang === 'vi'
            ? window._sdkVIDoc
            : ideLang === 'zh'
              ? window._sdkZHDoc
              : window._sdkENDoc;
    if (!descriptions) {
        return fallback || '';
    }
    if (descriptions[name]) {
        return descriptions[name];
    }
    const unqualifiedName = name.replace(/^(string|math)\./, '');
    return descriptions[unqualifiedName] || fallback || '';
}

function _applyServerLang(data) {
    const lang = data && data.lang;
    if (!lang || !IDE_LANGS.includes(lang) || lang === ideLang) {
        return;
    }
    ideLang = lang;
    applyIDELang();
}

function initIDELang() {
    applyIDELang();
    const sel = document.getElementById('ideLangSelect');
    if (!sel) {
        return;
    }
    sel.value = ideLang;
    sel.addEventListener('change', () => {
        if (!IDE_LANGS.includes(sel.value)) {
            return;
        }
        ideLang = sel.value;
        applyIDELang();
        fetch(`${API}/api/lang`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ lang: ideLang }),
        }).catch(() => {});
    });
}

function applyIDELang() {
    const s = IDE_I18N[ideLang] || IDE_I18N.en;
    const sel = document.getElementById('ideLangSelect');
    if (sel) {
        sel.value = ideLang;
    }
    localStorage.setItem(STORAGE_KEYS.lang, ideLang);

    document.querySelectorAll('[data-i18n-ide]').forEach((el) => {
        const key = el.getAttribute('data-i18n-ide');
        if (s[key]) {
            if (el.tagName === 'INPUT') {
                el.placeholder = s[key];
            } else {
                el.innerHTML = s[key];
            }
        }
    });
    document.querySelectorAll('[data-i18n-ide-placeholder]').forEach((el) => {
        const key = el.getAttribute('data-i18n-ide-placeholder');
        if (s[key]) {
            el.placeholder = s[key];
        }
    });

    if (typeof initSdkCatalog === 'function') {
        initSdkCatalog();
    }
    if (typeof window._buildHelperAccordion === 'function') {
        window._buildHelperAccordion();
    }
    if (
        typeof loadImagesTab === 'function' &&
        document.querySelector('.tab[data-tab="images"].active')
    ) {
        loadImagesTab();
    }
}

// -----------------------------------------------------------------------------
// Device selection and input commands
// -----------------------------------------------------------------------------

async function refreshDevices() {
    try {
        const res = await fetch(`${API}/api/ping`);
        const data = await res.json();
        _applyServerLang(data);
        _applyServerTheme(data);
        if (data.status === 'ok') {
            if (data.token) {
                state.apiToken = data.token;
            }
            state.devices = [{ udid: 'local', name: 'iPhone', ip: data.ip }];
            if (!state.currentDevice) {
                connectDevice('local');
            }
        } else {
            appendLog(_l('Could not connect to iPhone', 'Không kết nối được iPhone'), 'error');
        }
    } catch (e) {
        appendLog(_l('Could not connect to iPhone', 'Không kết nối được iPhone'), 'error');
    }
}

async function connectDevice(udid) {
    try {
        state.currentDevice = udid || 'local';

        try {
            const screenRes = await fetch(`${API}/screen_info`);
            const screenData = await screenRes.json();
            if (screenData.width) {
                const sc = screenData.scale || 3;
                state.screenSize = { w: screenData.width, h: screenData.height };
                state.wdaPoints = {
                    w: screenData.pointWidth || Math.round(screenData.width / sc),
                    h: screenData.pointHeight || Math.round(screenData.height / sc),
                };
                state.deviceScale = sc;
                state.screenInfo = {
                    width: screenData.width,
                    height: screenData.height,
                    scale: sc,
                    pointWidth: state.wdaPoints.w,
                    pointHeight: state.wdaPoints.h,
                };
            }
        } catch (e) {}
    } catch (e) {
        appendLog(_l('Could not connect to iPhone', 'Không kết nối được iPhone'), 'error');
    }
}

async function sendPress(button) {
    const key = (button || 'home').toString().toLowerCase();
    try {
        const res = await fetch(`${API}/key?key=${encodeURIComponent(key)}`);
        const data = await res.json().catch(() => ({}));
        if (data.ok === false) {
            appendLog(`⌨️ Key failed: ${data.error || key}`, 'error');
            return;
        }
        appendLog(_l(`⌨️ Pressed: ${key}`, `⌨️ Đã nhấn: ${key}`), 'success');
    } catch (e) {
        appendLog('⌨️ ' + e.message, 'error');
    }
}

function quickSwipe(direction) {
    const udid = state.currentDevice;
    if (!udid) {
        return;
    }
    if (!state.wdaPoints || !state.wdaPoints.w || !state.wdaPoints.h) {
        appendLog(
            _l('⚠️ Screen size not initialized', '⚠️ Chưa lấy được kích thước màn hình'),
            'error',
        );
        return;
    }

    const w = state.wdaPoints.w;
    const h = state.wdaPoints.h;
    const cx = Math.round(w / 2);
    const cy = Math.round(h / 2);

    let x1;
    let y1;
    let x2;
    let y2;
    let duration;
    switch (direction) {
        case 'up':
            x1 = cx;
            y1 = Math.round(h * 0.7);
            x2 = cx;
            y2 = Math.round(h * 0.3);
            duration = 0.4;
            break;
        case 'down':
            x1 = cx;
            y1 = Math.round(h * 0.3);
            x2 = cx;
            y2 = Math.round(h * 0.7);
            duration = 0.4;
            break;
        case 'left':
            x1 = Math.round(w * 0.8);
            y1 = cy;
            x2 = Math.round(w * 0.2);
            y2 = cy;
            duration = 0.3;
            break;
        case 'right':
            x1 = Math.round(w * 0.2);
            y1 = cy;
            x2 = Math.round(w * 0.8);
            y2 = cy;
            duration = 0.3;
            break;
    }

    fetch(`${API}/swipe?x1=${x1}&y1=${y1}&x2=${x2}&y2=${y2}&duration=${duration}`).catch((e) =>
        appendLog('⚠️ Swipe network error: ' + e.message, 'error'),
    );
    appendLog(_l(`📱 Swipe ${direction} (${duration}s)`, `📱 Vuốt ${direction} (${duration}s)`));
}

window.sendPress = sendPress;
window.quickSwipe = quickSwipe;

// -----------------------------------------------------------------------------
// Workspace tabs and interaction modes
// -----------------------------------------------------------------------------

function initTabs() {
    document.querySelectorAll('.tab').forEach((tab) => {
        tab.addEventListener('click', () => {
            const target = tab.dataset.tab;

            document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
            tab.classList.add('active');

            document.querySelectorAll('.tab-content').forEach((c) => c.classList.remove('active'));
            document.getElementById(`${target}Tab`)?.classList.add('active');

            if (target === 'files') {
                loadScriptFiles();
            }
            if (target === 'images') {
                loadImagesTab();
            }
            if (target === 'console') {
                const badge = document.getElementById('consoleBadge');
                if (badge) {
                    badge.textContent = '0';
                    badge.style.display = 'none';
                }
            }
        });
    });

    document.querySelectorAll('.vstrip-tab').forEach((vt) => {
        vt.addEventListener('click', () => {
            const target = vt.dataset.vtab;
            document.querySelectorAll('.vstrip-tab').forEach((b) => b.classList.remove('active'));
            vt.classList.add('active');
            document.querySelector(`.tab[data-tab="${target}"]`)?.click();
        });
    });

    const controlBtn = document.getElementById('modeControlBtn');
    const pickBtn = document.getElementById('modePickBtn');
    const helperModal = document.getElementById('helperModal');
    function syncMode() {
        const open = helperModal?.classList.contains('helper-open');
        controlBtn?.classList.toggle('active', !open);
        pickBtn?.classList.toggle('active', !!open);
    }
    function setMode(mode) {
        const open = helperModal?.classList.contains('helper-open');
        if (mode === 'pick' && !open) {
            if (typeof window._openHelperPanel === 'function') {
                window._openHelperPanel();
            }
        }
        if (mode === 'control' && open) {
            if (typeof window._closeHelperPanel === 'function') {
                window._closeHelperPanel();
            }
        }
        syncMode();
    }
    controlBtn?.addEventListener('click', () => setMode('control'));
    pickBtn?.addEventListener('click', () => setMode('pick'));
    if (helperModal) {
        new MutationObserver(syncMode).observe(helperModal, {
            attributes: true,
            attributeFilter: ['class'],
        });
    }
    // Tab visibility and Pick mode retain the mounted viewer. Its own lifecycle
    // releases input while hidden; only explicit Disconnect unloads the iframe.
}

// -----------------------------------------------------------------------------
// Monaco language definition and snippets
// -----------------------------------------------------------------------------

const _MONACO_SNIPPET_TEMPLATES = [
    {
        label: '⚡ while true loop',
        insert: 'while true do\n    sleep(${1:1})\nend',
        detail: 'Vòng lặp vô hạn',
        doc: 'Lặp mãi với sleep.',
    },
    {
        label: '⚡ for loop',
        insert: 'for ${1:i} = 1, ${2:10} do\n    print(${1:i})\n    sleep(${3:0.5})\nend',
        detail: 'Lặp từ 1 → N',
        doc: 'Numeric for loop.',
    },
    {
        label: '⚡ find and tap',
        insert: 'let rect = image_match("${1:btn.png}")\nif rect then\n    tap(rect["x"], rect["y"])\n    print("Tapped!")\nelse\n    print("Not found")\nend',
        detail: 'Find → tap',
        doc: 'Find image and tap.',
    },
    {
        label: '⚡ wait and tap',
        insert: 'let rect = wait_for_image("${1:btn.png}", 0.9, ${2:30})\nif rect then\n    tap(rect["x"], rect["y"])\n    print("OK")\nelse\n    print("Timeout")\nend',
        detail: 'Wait → tap',
        doc: 'Wait for image then tap.',
    },
    {
        label: '⚡ color check',
        insert: 'while true do\n    let c = pick_color(${1:100}, ${2:200})\n    if c and c["red"] == ${3:255} then\n        tap(${1:100}, ${2:200})\n        break\n    end\n    sleep(0.5)\nend',
        detail: 'Color check',
        doc: 'Wait for color match.',
    },
    {
        label: '⚡ app launch',
        insert: 'switch_to_app("${1:com.apple.mobilesafari}")\nsleep(2)\nprint("App:", get_front_app())',
        detail: 'Launch app',
        doc: 'Launch and verify.',
    },
    {
        label: '⚡ if / else',
        insert: 'if ${1:cond} then\n    ${2:}\nelse\n    ${3:}\nend',
        detail: 'If/else',
        doc: 'Conditional.',
    },
    {
        label: '⚡ function',
        insert: 'fn ${1:my_func}(${2:})\n    ${3:}\nend',
        detail: 'Function',
        doc: 'Function definition.',
    },
    {
        label: '⚡ HTTP + JSON',
        insert: 'let resp = http_get("${1:https://api.example.com}")\nprint(resp)',
        detail: 'HTTP + JSON',
        doc: 'GET and parse JSON.',
    },
    {
        label: '⚡ scroll down',
        insert: 'for i = 1, ${1:3} do\n    swipe(207, 600, 207, 300, 0.3)\n    sleep(0.5)\nend',
        detail: 'Scroll down',
        doc: 'Swipe up to scroll.',
    },
    {
        label: '⚡ multi-step',
        insert: 'switch_to_app("${1:com.apple.mobilesafari}")\nsleep(2)\n\ntap(${2:207}, ${3:400})\nsleep(1)\n\ninsert_text("${4:hello}", ${5:0.1})\n\nprint("Done!")',
        detail: 'Multi-step',
        doc: 'Multi-step automation template.',
    },
];

function _defineMonacoTheme(monaco) {
    monaco.editor.defineTheme('na-dark', {
        base: 'vs-dark',
        inherit: true,
        rules: [
            { token: 'comment', foreground: '6A9955', fontStyle: 'italic' },
            { token: 'keyword', foreground: 'C586C0' },
            { token: 'string', foreground: 'CE9178' },
            { token: 'number', foreground: 'B5CEA8' },
            { token: 'type', foreground: '4EC9B0' },
            { token: 'identifier', foreground: '9CDCFE' },
            { token: 'delimiter', foreground: 'D4D4D4' },
        ],
        colors: {
            'editor.background': '#0D1117',
            'editor.foreground': '#E6EDF3',
            'editor.lineHighlightBackground': '#161B22',
            'editor.selectionBackground': '#264F78',
            'editorLineNumber.foreground': '#484F58',
            'editorLineNumber.activeForeground': '#E6EDF3',
            'editor.inactiveSelectionBackground': '#1A2332',
            'editorCursor.foreground': '#79C0FF',
            'editorIndentGuide.background': '#21262D',
            'editorIndentGuide.activeBackground': '#30363D',
            'editorWidget.background': '#161B22',
            'editorWidget.border': '#30363D',
            'editorSuggestWidget.background': '#161B22',
            'editorSuggestWidget.border': '#30363D',
            'editorSuggestWidget.selectedBackground': '#1F6FEB33',
            'minimap.background': '#0D1117',
            'scrollbar.shadow': '#00000000',
            'scrollbarSlider.background': '#484F5833',
            'scrollbarSlider.hoverBackground': '#484F5855',
            'scrollbarSlider.activeBackground': '#484F5888',
        },
    });
}

function _registerALangLanguage(monaco) {
    if (monaco.languages.getLanguages().find((l) => l.id === 'alang')) {
        return;
    }
    monaco.languages.register({ id: 'alang', extensions: ['.a'], aliases: ['a', 'alang'] });
    monaco.languages.setMonarchTokensProvider('alang', {
        keywords: [
            'let',
            'fn',
            'end',
            'if',
            'then',
            'else',
            'elseif',
            'for',
            'in',
            'do',
            'while',
            'repeat',
            'until',
            'return',
            'break',
            'continue',
            'true',
            'false',
            'nil',
            'and',
            'or',
            'not',
        ],
        operators: [
            '+',
            '-',
            '*',
            '/',
            '%',
            '^',
            '==',
            '!=',
            '<',
            '>',
            '<=',
            '>=',
            '=',
            '+=',
            '-=',
            '*=',
            '/=',
            '..',
        ],
        tokenizer: {
            root: [
                [/--\[\[/, 'comment', '@blockcomment'],
                [/--.*$/, 'comment'],
                [/[a-zA-Z_]\w*/, { cases: { '@keywords': 'keyword', '@default': 'identifier' } }],
                [/\d+\.\d+([eE][+\-]?\d+)?/, 'number.float'],
                [/0[xX][0-9a-fA-F]+/, 'number.hex'],
                [/\d+/, 'number'],
                [/"([^"\\]|\\.)*"/, 'string'],
                [/'([^'\\]|\\.)*'/, 'string'],
                [/\.\./, 'operator'],
                [/[=!<>+\-*/%^]+/, 'operator'],
                [/[{}()\[\]]/, '@brackets'],
                [/[,.:;]/, 'delimiter'],
                [/\s+/, 'white'],
            ],
            blockcomment: [
                [/]]/, 'comment', '@pop'],
                [/./, 'comment'],
            ],
        },
    });
    monaco.languages.setLanguageConfiguration('alang', {
        comments: { lineComment: '--', blockComment: ['--[[', ']]'] },
        brackets: [
            ['{', '}'],
            ['[', ']'],
            ['(', ')'],
        ],
        autoClosingPairs: [
            { open: '{', close: '}' },
            { open: '[', close: ']' },
            { open: '(', close: ')' },
            { open: '"', close: '"' },
            { open: "'", close: "'" },
        ],
    });
}

/** Register only the completion provider; the caller controls registration order. */
// -----------------------------------------------------------------------------
// Monaco completion, hover and signature help
// -----------------------------------------------------------------------------

function registerAlangCompletionItems(monaco) {
    monaco.languages.registerCompletionItemProvider('alang', {
        triggerCharacters: ['.', '(', '"', "'"],
        provideCompletionItems: function (model, position) {
            const word = model.getWordUntilPosition(position);
            const range = {
                startLineNumber: position.lineNumber,
                endLineNumber: position.lineNumber,
                startColumn: word.startColumn,
                endColumn: word.endColumn,
            };

            const suggestions = [];

            const linePrefix = model.getValueInRange({
                startLineNumber: position.lineNumber,
                startColumn: 1,
                endLineNumber: position.lineNumber,
                endColumn: position.column,
            });
            const libHit = linePrefix.match(/\b(string|math)\.(\w*)$/);
            const LIB_MEMBERS = {
                string: [
                    'upper',
                    'lower',
                    'trim',
                    'split',
                    'join',
                    'replace',
                    'contains',
                    'starts_with',
                    'ends_with',
                    'len',
                ],
                math: ['abs', 'floor', 'ceil', 'round', 'sqrt', 'pow', 'min', 'max', 'random'],
            };

            const sdk = window._sdkMethods || [];
            const sdkSeen = new Set();
            sdk.forEach((fn, i) => {
                if (sdkSeen.has(fn.name)) {
                    return;
                }
                sdkSeen.add(fn.name);
                let insertName = fn.name;
                if (libHit) {
                    const members = LIB_MEMBERS[libHit[1]] || [];
                    const bare = fn.name.replace(/^(string|math)\./, '');
                    if (members.indexOf(bare) < 0) {
                        return;
                    }
                    if (fn.name.indexOf('.') >= 0 && fn.name !== libHit[1] + '.' + bare) {
                        return;
                    }
                    insertName = bare;
                }
                const sig = (fn.sig || '()').replace(/^\(|\)$/g, '');
                const args = sig
                    .split(',')
                    .map((a) => a.trim())
                    .filter((a) => a && a !== 'self');
                const positional = args.filter((a) => !a.includes('='));
                const snippetArgs = positional.map((a, idx) => {
                    const display = a.includes(':') ? a.split(':')[0].trim() : a;
                    return '${' + (idx + 1) + ':' + display + '}';
                });
                const callSnippet = `${insertName}(${snippetArgs.join(', ')})`;
                const rawDocOne = (fn.doc || '').split('\n')[0].slice(0, 80);
                const docOne = _sdkDoc(fn.name, rawDocOne);
                suggestions.push({
                    label: { label: insertName, detail: '(' + sig + ')', description: docOne },
                    filterText: insertName,
                    kind: monaco.languages.CompletionItemKind.Function,
                    insertText: callSnippet,
                    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                    detail: docOne,
                    documentation: {
                        value: '```a\n' + fn.name + '(' + sig + ')\n```\n\n' + docOne,
                    },
                    sortText: '0' + String(i).padStart(3, '0'),
                    range,
                });
            });

            _MONACO_SNIPPET_TEMPLATES.forEach((tpl, i) => {
                const filterText = tpl.label.replace(/^⚡\s*/, '');
                suggestions.push({
                    label: tpl.label,
                    kind: monaco.languages.CompletionItemKind.Snippet,
                    insertText: tpl.insert,
                    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                    detail: tpl.detail,
                    documentation: { value: tpl.doc },
                    filterText: filterText,
                    sortText: '1' + String(i).padStart(3, '0'),
                    range,
                });
            });

            ['KEY_HOME', 'KEY_POWER', 'KEY_VOLUME_UP', 'KEY_VOLUME_DOWN'].forEach((k) => {
                suggestions.push({
                    label: k,
                    kind: monaco.languages.CompletionItemKind.Constant,
                    insertText: k,
                    detail: 'Key constant',
                    sortText: '2' + k,
                    range,
                });
            });

            const fullText = model.getValue();
            const funcRegex = /def\s+([a-zA-Z_]\w*)\s*\(([^)]*)\)/g;
            let match;
            const seen = new Set();
            while ((match = funcRegex.exec(fullText)) !== null) {
                const fname = match[1];
                const params = match[2].trim();
                if (seen.has(fname)) {
                    continue;
                }
                seen.add(fname);
                const beforeFunc = fullText.substring(0, match.index);
                const lines = beforeFunc.split('\n');
                let docLines = [];
                for (let i = lines.length - 1; i >= 0; i--) {
                    const trimmed = lines[i].trim();
                    if (trimmed.startsWith('#')) {
                        docLines.unshift(trimmed.replace(/^#\s?/, ''));
                    } else if (trimmed === '') {
                        if (docLines.length > 0) {
                            break;
                        }
                    } else {
                        break;
                    }
                }
                const doc = docLines.length > 0 ? docLines.join('\n') : 'User-defined function';
                const paramList = params
                    ? params
                          .split(',')
                          .map((p, idx) => `\${${idx + 1}:${p.trim()}}`)
                          .join(', ')
                    : '';
                suggestions.push({
                    label: fname,
                    kind: monaco.languages.CompletionItemKind.Function,
                    insertText: fname + '(' + paramList + ')',
                    insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
                    detail: `${fname}(${params}) — script`,
                    documentation: {
                        value: '```a\ndef ' + fname + '(' + params + ')\n```\n\n' + doc,
                    },
                    sortText: '00' + fname,
                    range,
                });
            }

            const varRegex = /(?:^|[\n;])\s*([a-zA-Z_]\w*)\s*=/g;
            while ((match = varRegex.exec(fullText)) !== null) {
                const vname = match[1];
                if (
                    seen.has(vname) ||
                    [
                        'if',
                        'else',
                        'elif',
                        'for',
                        'while',
                        'return',
                        'def',
                        'class',
                        'True',
                        'False',
                        'None',
                        'and',
                        'or',
                        'not',
                        'import',
                        'from',
                        'as',
                        'with',
                        'try',
                        'except',
                        'finally',
                        'pass',
                        'break',
                        'continue',
                        'lambda',
                        'yield',
                        'global',
                        'nonlocal',
                    ].includes(vname)
                ) {
                    continue;
                }
                seen.add(vname);
                suggestions.push({
                    label: vname,
                    kind: monaco.languages.CompletionItemKind.Variable,
                    insertText: vname,
                    detail: 'variable',
                    sortText: '01' + vname,
                    range,
                });
            }

            return { suggestions };
        },
    });
}

/** Register only the hover provider; the caller controls registration order. */
function registerAlangHover(monaco) {
    monaco.languages.registerHoverProvider('alang', {
        provideHover: function (model, position) {
            const word = model.getWordAtPosition(position);
            if (!word) {
                return null;
            }
            const sdk = window._sdkMethods || [];
            const fn = sdk.find((f) => f.name === word.word);
            if (!fn) {
                return null;
            }
            const sig = (fn.sig || '()').replace(/^\(|\)$/g, '');
            const hoverDoc = _sdkDoc(fn.name, fn.doc || '');
            return {
                range: new monaco.Range(
                    position.lineNumber,
                    word.startColumn,
                    position.lineNumber,
                    word.endColumn,
                ),
                contents: [
                    { value: '```a\nd.' + fn.name + '(' + sig + ')\n```' },
                    { value: hoverDoc },
                ],
            };
        },
    });
}

/** Register only the signature help provider; the caller controls registration order. */
function registerAlangSignatureHelp(monaco) {
    monaco.languages.registerSignatureHelpProvider('alang', {
        signatureHelpTriggerCharacters: ['(', ','],
        provideSignatureHelp: function (model, position) {
            const lineContent = model.getLineContent(position.lineNumber);
            const textBefore = lineContent.substring(0, position.column - 1);

            let depth = 0;
            let parenPos = -1;
            for (let i = textBefore.length - 1; i >= 0; i--) {
                if (textBefore[i] === ')') {
                    depth++;
                } else if (textBefore[i] === '(') {
                    if (depth === 0) {
                        parenPos = i;
                        break;
                    }
                    depth--;
                }
            }
            if (parenPos < 0) {
                return null;
            }

            const beforeParen = textBefore.substring(0, parenPos).trimEnd();
            const funcMatch = beforeParen.match(/(\w+)$/);
            if (!funcMatch) {
                return null;
            }

            const sdk = window._sdkMethods || [];
            const fn = sdk.find((f) => f.name === funcMatch[1]);
            if (!fn) {
                return null;
            }
            const sig = (fn.sig || '()').replace(/^\(|\)$/g, '');
            const params = sig
                .split(',')
                .map((a) => a.trim())
                .filter((a) => a && a !== 'self');

            const insideParen = textBefore.substring(parenPos + 1);
            let commaCount = 0;
            let d = 0;
            for (const ch of insideParen) {
                if (ch === '(') {
                    d++;
                } else if (ch === ')') {
                    d--;
                } else if (ch === ',' && d === 0) {
                    commaCount++;
                }
            }

            const sigDoc = _sdkDoc(fn.name, fn.doc || '');
            return {
                value: {
                    signatures: [
                        {
                            label: fn.name + '(' + sig + ')',
                            documentation: sigDoc,
                            parameters: params.map((p) => ({ label: p, documentation: p })),
                        },
                    ],
                    activeSignature: 0,
                    activeParameter: Math.min(commaCount, fn.params.length - 1),
                },
                dispose: () => {},
            };
        },
    });
}

/** Register providers synchronously in the original completion/hover/signature order. */
function _registerALangCompletion(monaco) {
    registerAlangCompletionItems(monaco);
    registerAlangHover(monaco);
    registerAlangSignatureHelp(monaco);
}

// -----------------------------------------------------------------------------
// Monaco editor creation and actions
// -----------------------------------------------------------------------------

function _createMonacoEditor(monaco, defaultCode) {
    state.editor = monaco.editor.create(document.getElementById('codeEditor'), {
        value: defaultCode,
        language: 'alang',
        theme: ideTheme === 'dark' ? 'na-dark' : 'vs',
        fontSize: 13,
        fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Consolas', monospace",
        fontLigatures: true,
        lineNumbers: 'on',
        minimap: { enabled: true, scale: 1, size: 'proportional' },
        scrollBeyondLastLine: false,
        automaticLayout: true,
        tabSize: 4,
        insertSpaces: true,
        wordWrap: 'off',
        renderWhitespace: 'selection',
        bracketPairColorization: { enabled: true },
        guides: { bracketPairs: true, indentation: true },
        suggestOnTriggerCharacters: true,
        quickSuggestions: { other: 'on', comments: false, strings: false },
        quickSuggestionsDelay: 10,
        wordBasedSuggestions: 'off',
        suggest: {
            filterGraceful: true,
            snippetsPreventQuickSuggestions: false,
            localityBonus: true,
            shareSuggestSelections: true,
        },
        acceptSuggestionOnCommitCharacter: true,
        autoClosingBrackets: 'always',
        autoClosingQuotes: 'always',
        autoIndent: 'full',
        formatOnPaste: true,
        formatOnType: true,
        smoothScrolling: true,
        cursorBlinking: 'smooth',
        cursorSmoothCaretAnimation: 'on',
        padding: { top: 12, bottom: 12 },
        roundedSelection: true,
        renderLineHighlight: 'all',
        occurrencesHighlight: 'singleFile',
        folding: true,
        foldingHighlight: true,
        showFoldingControls: 'mouseover',
        matchBrackets: 'always',
        contextmenu: true,
        mouseWheelZoom: true,
    });
}

function _bindMonacoActions(monaco) {
    state.editor.addAction({
        id: 'run-script',
        label: 'Run Script',
        keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter],
        run: () => {
            if (state.runningTaskId) {
                stopScript();
            } else {
                runScript();
            }
        },
    });

    let suggestTimer = null;
    state.editor.onDidChangeModelContent((e) => {
        if (suggestTimer) {
            clearTimeout(suggestTimer);
        }
        if (e.changes.some((c) => c.text.length > 0 && /[a-zA-Z_]/.test(c.text))) {
            suggestTimer = setTimeout(() => {
                state.editor.trigger('auto', 'editor.action.triggerSuggest', {});
            }, 50);
        }
    });

    state.editor.addAction({
        id: 'save-script',
        label: 'Save Script',
        keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS],
        run: () => {
            if (state.currentFileName) {
                saveScriptAs(state.currentFileName);
                return;
            }
            document.getElementById('saveModal').classList.add('visible');
            const inp = document.getElementById('scriptNameInput');
            if (!inp.value) {
                inp.value = generateScriptName();
            }
            setTimeout(() => {
                inp.focus();
                inp.select();
            }, 100);
        },
    });

    document.getElementById('runBtn')?.addEventListener('click', runScript);
    document.getElementById('stopBtn')?.addEventListener('click', stopScript);
    document.getElementById('newScriptBtn')?.addEventListener('click', () => {
        const defaultCode =
            document.getElementById('defaultCode')?.textContent?.trim() || '-- New script\n';
        const autoName = generateScriptName() + '.a';
        if (!openTab(autoName, defaultCode)) {
            return;
        }
        state._dirty = true;
        const newTab = state.openTabs.find((t) => t.id === state.activeTabId);
        if (newTab) {
            newTab.dirty = true;
        }
        renderEditorTabs();
        document.getElementById('scriptNameInput').value = autoName;
        document.querySelector('.tab[data-tab="editor"]')?.click();
        appendLog(_l('📝 New script created', '📝 Đã tạo script mới'));
    });
    document.getElementById('newFolderBtn')?.addEventListener('click', () => {
        if (typeof createFolder === 'function') {
            createFolder();
        }
    });
    document.getElementById('saveBtn')?.addEventListener('click', () => {
        document.getElementById('saveModal').classList.add('visible');
        const inp = document.getElementById('scriptNameInput');
        if (!inp.value) {
            inp.value = generateScriptName();
        }
        setTimeout(() => {
            inp.focus();
            inp.select();
        }, 100);
    });

    state._dirty = false;
    state._initDone = true;
    state.editor.onDidChangeModelContent(() => {
        if (state._initDone) {
            state._dirty = true;
        }
    });
}

function initMonacoEditor() {
    require.config({
        paths: { vs: '/static/monaco/vs' },
    });

    require(['vs/editor/editor.main'], function () {
        _defineMonacoTheme(monaco);
        const defaultCode =
            document.getElementById('defaultCode')?.textContent?.trim() ||
            '-- Write your script here\n';
        _registerALangCompletion(monaco);
        _registerALangLanguage(monaco);
        _createMonacoEditor(monaco, defaultCode);
        _bindMonacoActions(monaco);
    });
}

function getEditorValue() {
    if (state.editor) {
        return state.editor.getValue();
    }
    return '';
}

function setEditorValue(code) {
    if (state.editor) {
        state.editor.setValue(code);
        state._dirty = false;
    }
}

// -----------------------------------------------------------------------------
// Editor tabs and unsaved changes
// Public handler names stay compatible with the existing HTML and generated markup.
// -----------------------------------------------------------------------------

function generateTabId() {
    return 'tab_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
}

function _tabHasUnsavedChanges(tab) {
    return !!tab && (tab.id === state.activeTabId ? !!state._dirty : !!tab.dirty);
}

/** Prompt only for the existing dirty-tab cases; retain the caller-selected action. */
function _confirmDiscardTab(tab, action) {
    if (!_tabHasUnsavedChanges(tab)) {
        return true;
    }
    return window.confirm(
        _l(
            `Unsaved changes in "${tab.name}". ${action} and discard them?`,
            `Có thay đổi chưa lưu trong "${tab.name}". ${action} và bỏ thay đổi?`,
        ),
    );
}

function _hasUnsavedChanges() {
    return !!state._dirty || state.openTabs.some((tab) => _tabHasUnsavedChanges(tab));
}

window.addEventListener('beforeunload', (event) => {
    if (!_hasUnsavedChanges()) {
        return;
    }
    event.preventDefault();
    event.returnValue = '';
});

function openTab(name, code, encrypted = false) {
    const readOnly = !!encrypted || /\.aios$/i.test(name || '');
    const existing = state.openTabs.find((t) => t.name === name);
    if (existing) {
        // Reload nội dung từ disk/API — không giữ bản cũ/mặc định
        if (typeof code === 'string' && existing.model) {
            if (!_confirmDiscardTab(existing, _l('Reload', 'Tải lại'))) {
                return false;
            }
            existing.model.setValue(code);
            existing.code = code;
            existing.dirty = false;
            if (existing.id === state.activeTabId) {
                state._dirty = false;
            }
        }
        existing.readOnly = readOnly;
        switchTab(existing.id);
        state.editor?.updateOptions?.({ readOnly });
        return true;
    }
    saveCurrentTabState();
    const model = monaco.editor.createModel(code, 'alang');
    const tab = { id: generateTabId(), name, code, dirty: false, viewState: null, model, readOnly };
    state.openTabs.push(tab);
    state.activeTabId = tab.id;
    state.currentFileName = name;
    if (state.editor) {
        state.editor.setModel(model);
        state.editor.updateOptions({ readOnly });
    }
    state._dirty = false;
    renderEditorTabs();
    return true;
}

function switchTab(tabId) {
    if (state.activeTabId === tabId) {
        return;
    }
    saveCurrentTabState();
    const tab = state.openTabs.find((t) => t.id === tabId);
    if (!tab) {
        return;
    }
    state.activeTabId = tabId;
    state.currentFileName = tab.name;
    if (state.editor) {
        state.editor.setModel(tab.model);
        state.editor.updateOptions({ readOnly: !!tab.readOnly });
        if (tab.viewState) {
            state.editor.restoreViewState(tab.viewState);
        }
        state.editor.focus();
    }
    state._dirty = tab.dirty;
    document.getElementById('scriptNameInput').value = tab.name || '';
    renderEditorTabs();
}

function closeTab(tabId, evt) {
    if (evt) {
        evt.stopPropagation();
    }
    const idx = state.openTabs.findIndex((t) => t.id === tabId);
    if (idx === -1) {
        return false;
    }
    if (!_confirmDiscardTab(state.openTabs[idx], _l('Close', 'Đóng'))) {
        return false;
    }
    if (state.activeTabId === tabId) {
        saveCurrentTabState();
    }
    const closedTab = state.openTabs[idx];
    if (closedTab.model) {
        closedTab.model.dispose();
    }
    state.openTabs.splice(idx, 1);
    if (state.activeTabId === tabId) {
        if (state.openTabs.length > 0) {
            const newIdx = Math.min(idx, state.openTabs.length - 1);
            const newTab = state.openTabs[newIdx];
            state.activeTabId = newTab.id;
            state.currentFileName = newTab.name;
            if (state.editor) {
                state.editor.setModel(newTab.model);
                state.editor.updateOptions({ readOnly: !!newTab.readOnly });
                if (newTab.viewState) {
                    state.editor.restoreViewState(newTab.viewState);
                }
                state.editor.focus();
            }
            state._dirty = newTab.dirty;
            document.getElementById('scriptNameInput').value = newTab.name || '';
        } else {
            state.activeTabId = null;
            state.currentFileName = null;
            if (state.editor) {
                state.editor.setModel(monaco.editor.createModel('', 'alang'));
                state.editor.updateOptions({ readOnly: false });
            }
            state._dirty = false;
            document.getElementById('scriptNameInput').value = '';
        }
    }
    renderEditorTabs();
    return true;
}

function saveCurrentTabState() {
    if (!state.activeTabId) {
        return;
    }
    const tab = state.openTabs.find((t) => t.id === state.activeTabId);
    if (tab && state.editor) {
        tab.code = state.editor.getValue();
        tab.dirty = state._dirty;
        tab.viewState = state.editor.saveViewState();
    }
}

function renderEditorTabs() {
    const bar = document.getElementById('editorTabBar');
    if (!bar) {
        return;
    }
    if (state.openTabs.length === 0) {
        bar.innerHTML =
            '<div style="padding:5px 12px; font-size:11px; color:var(--text-secondary); opacity:0.5;">No files open</div>';
        return;
    }
    bar.innerHTML = state.openTabs
        .map((t) => {
            const isActive = t.id === state.activeTabId;
            const isRunning = state.runningFileName === t.name;
            const icon = isRunning ? 'flame' : 'file-code';
            const iconColor = isRunning ? 'color:#f97316;' : 'opacity:0.4;';
            const idJS = escJS(t.id);
            return `<div class="editor-tab ${isActive ? 'active' : ''}" onclick="switchTab('${idJS}')">
      <i data-lucide="${icon}" style="width:12px;height:12px;flex-shrink:0;${iconColor}"></i>
      <span class="tab-name">${escapeHtml(t.name)}</span>
      <span class="tab-dot ${t.dirty ? 'dirty' : ''}"></span>
      <span class="tab-close" onclick="closeTab('${idJS}', event)">×</span>
    </div>`;
        })
        .join('');
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

window.switchTab = switchTab;
window.closeTab = closeTab;

// -----------------------------------------------------------------------------
// Script execution, cancellation and encryption
// -----------------------------------------------------------------------------

async function checkRunningScript() {
    try {
        const res = await fetch(`${API}/api/scripts/state?since=999999999`);
        const data = await res.json();
        if (data.running) {
            state.runningTaskId = data.taskId || '__quickpanel__';
            state.runningFileName = data.scriptName || null;
            state.lastLogIndex = 0;
            setRunButtonsState(true);
            const source = data.source === 'quickpanel' ? ' (Quick Panel)' : '';
            appendLog(
                _l(
                    `🔄 Script "${data.scriptName || 'unknown'}" is running${source}`,
                    `🔄 Script "${data.scriptName || 'unknown'}" đang chạy${source}`,
                ),
            );
        }
    } catch (e) {}
}

async function runScript() {
    if (!_beginRunRequest()) {
        return;
    }
    try {
        if (state.runningTaskId) {
            try {
                const chk = await fetch(`${API}/api/scripts/state?since=999999999`);
                const cs = await chk.json();
                if (!cs.running) {
                    state.runningTaskId = null;
                    state.runningFileName = null;
                } else {
                    appendLog(
                        _l(
                            `⚠️ Script "${state.runningFileName || 'unknown'}" is still running. Stop it first!`,
                            `⚠️ Script "${state.runningFileName || 'unknown'}" vẫn đang chạy. Dừng trước đã!`,
                        ),
                        'error',
                    );
                    return;
                }
            } catch (_) {
                state.runningTaskId = null;
            }
        }
        const code = getEditorValue();
        if (!code.trim()) {
            appendLog(_l('⚠️ No code to run', '⚠️ Không có code để chạy'), 'error');
            return;
        }

        if (typeof toggleConsolePanel === 'function') {
            toggleConsolePanel(true);
        }

        const helperModal = document.getElementById('helperModal');
        state._panelStateBeforeRun = {
            helperWasOpen: helperModal && helperModal.classList.contains('helper-open'),
        };
        if (state._dirty) {
            if (state.currentFileName) {
                try {
                    const res = await fetch(`${API}/api/scripts/save`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ name: state.currentFileName, code }),
                    });
                    const data = await res.json();
                    if (res.ok && data.success) {
                        state._dirty = false;
                        appendLog(
                            _l(
                                `💾 Auto-saved: ${state.currentFileName}`,
                                `💾 Tự lưu: ${state.currentFileName}`,
                            ),
                            'success',
                        );
                    } else {
                        appendLog(
                            '❌ Auto-save failed: ' + (data.error || `HTTP ${res.status}`),
                            'error',
                        );
                        return;
                    }
                } catch (e) {
                    appendLog('⚠️ Auto-save failed: ' + e.message, 'warn');
                    return;
                }
            } else {
                state._runAfterSave = true;
                document.getElementById('saveModal').classList.add('visible');
                const inp = document.getElementById('scriptNameInput');
                if (!inp.value) {
                    inp.value = generateScriptName();
                }
                setTimeout(() => {
                    inp.focus();
                    inp.select();
                }, 100);
                appendLog('💾 Đặt tên file trước khi chạy...', 'info');
                return;
            }
        }

        const udid = state.currentDevice || 'local';

        try {
            const isEnc = state.currentFileName && state.currentFileName.endsWith('.aios');
            const bodyObj = isEnc
                ? { udid, scriptName: state.currentFileName }
                : { code: code, udid, scriptName: state.currentFileName || '' };

            const res = await fetch(`${API}/api/scripts/run`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bodyObj),
            });
            const data = await res.json();

            if (data.success) {
                state.runningTaskId = data.taskId;
                state.lastLogIndex = 0;
                state.runningFileName = state.currentFileName || null;

                setRunButtonsState(true);

                appendLog(
                    _l(
                        `▶️ Script started (task: ${data.taskId})`,
                        `▶️ Đã chạy script (task: ${data.taskId})`,
                    ),
                );

                loadScriptFiles();
            } else {
                const errMsg = data.detail || data.error || 'Failed to start';
                appendLog('❌ ' + errMsg, 'error');
                if (/license|premium|hết hạn|expir|cooldown|kích hoạt/i.test(errMsg)) {
                    if (!state._licenseExpiredShown) {
                        state._licenseExpiredShown = true;
                        if (typeof showToast === 'function') {
                            showToast(
                                _l(
                                    'Premium expired — open app to renew',
                                    'Premium hết hạn — mở app gia hạn',
                                ),
                                'error',
                            );
                        }
                    }
                }
            }
        } catch (e) {
            appendLog('❌ ' + e.message, 'error');
        }
    } finally {
        _endRunRequest();
    }
}

async function runFileScript(fileName) {
    if (!_beginRunRequest()) {
        return;
    }
    try {
        if (state.runningTaskId) {
            appendLog(
                _l(
                    `⚠️ Script "${state.runningFileName || 'unknown'}" is still running. Stop it first!`,
                    `⚠️ Script "${state.runningFileName || 'unknown'}" vẫn đang chạy. Dừng trước đã!`,
                ),
                'error',
            );
            return;
        }

        if (typeof toggleConsolePanel === 'function') {
            toggleConsolePanel(true);
        }

        try {
            const isEnc = fileName.endsWith('.aios');
            const res = await fetch(`${API}/api/scripts/load?name=${encodeURIComponent(fileName)}`);
            const data = await res.json();
            if (!data.success) {
                appendLog(`❌ Failed to load ${fileName}`, 'error');
                return;
            }
            if (!openTab(fileName, data.code, data.encrypted)) {
                return;
            }
            document.getElementById('scriptNameInput').value = fileName;

            const udid = state.currentDevice || 'local';
            const bodyObj = isEnc
                ? { udid, scriptName: fileName }
                : { code: data.code, udid, scriptName: fileName };

            const runRes = await fetch(`${API}/api/scripts/run`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bodyObj),
            });
            const runData = await runRes.json();
            if (runData.success) {
                state.runningTaskId = runData.taskId;
                state.runningFileName = fileName;
                state.lastLogIndex = 0;
                setRunButtonsState(true);
                appendLog(
                    _l(
                        `▶️ Running: ${fileName} (task: ${runData.taskId})`,
                        `▶️ Đang chạy: ${fileName} (task: ${runData.taskId})`,
                    ),
                );
                loadScriptFiles();
            } else {
                appendLog('❌ ' + (runData.detail || runData.error || 'Failed to start'), 'error');
            }
        } catch (e) {
            appendLog('❌ ' + e.message, 'error');
        }
    } finally {
        _endRunRequest();
    }
}

async function stopScript() {
    // Chỉ gửi lệnh dừng + đặt nút "đang xử lý". Poll trạng thái daemon là nguồn
    // DUY NHẤT đổi nút về Bắt đầu khi script thật sự dừng → không đá nhau, không giật.
    const taskId = state.runningTaskId;
    setRunButtonsState('pending');
    if (state._panelStateBeforeRun) {
        if (state._panelStateBeforeRun.helperWasOpen) {
            if (typeof window._openHelperPanel === 'function') {
                window._openHelperPanel();
            } else {
                document.getElementById('helperToggleBtn')?.click();
            }
        }
        state._panelStateBeforeRun = null;
    }
    try {
        const res = await fetch(`${API}/api/scripts/stop`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ taskId: taskId }),
        });
        const data = await res.json();
        if (!res.ok || data.ok === false || data.success === false) {
            throw new Error(data.detail || data.error || `HTTP ${res.status}`);
        }
        appendLog(
            _l(
                '⏹️ Stop requested; waiting for device state',
                '⏹️ Đã gửi yêu cầu dừng; đang chờ trạng thái thiết bị',
            ),
        );
    } catch (e) {
        appendLog('❌ ' + e.message, 'error');
        setRunButtonsState(state.runningTaskId ? 'running' : 'idle');
    }
}

async function encrypt_script(fileName) {
    if (!fileName) {
        fileName = state.currentFileName;
    }
    if (!fileName || !fileName.endsWith('.a')) {
        appendLog('⚠️ Can only encrypt .a files', 'error');
        return;
    }

    document.getElementById('encryptFileName').textContent = fileName;
    document.getElementById('encryptModal').classList.add('visible');

    return new Promise((resolve) => {
        const btn = document.getElementById('confirmEncryptBtn');
        const modal = document.getElementById('encryptModal');
        let cleanup = null;
        const handler = async () => {
            cleanup && cleanup();
            modal.classList.remove('visible');
            try {
                const res = await fetch(`${API}/api/scripts/encrypt`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: fileName }),
                });
                const data = await res.json();
                if (data.success) {
                    appendLog(
                        _l(
                            `🔒 Encrypted: ${fileName} → ${data.name}`,
                            `🔒 Đã mã hoá: ${fileName} → ${data.name}`,
                        ),
                        'success',
                    );
                    loadScriptFiles();
                } else {
                    appendLog(
                        '❌ ' +
                            _l('Encrypt failed: ', 'Mã hoá lỗi: ') +
                            (data.error || 'Unknown error'),
                        'error',
                    );
                }
            } catch (e) {
                appendLog('❌ ' + _l('Encrypt failed: ', 'Mã hoá lỗi: ') + e.message, 'error');
            }
            resolve();
        };
        const cancel = () => {
            cleanup && cleanup();
            modal.classList.remove('visible');
            resolve();
        };
        const onOverlay = (e) => {
            if (e.target === modal) {
                cancel();
            }
        };
        const onEsc = (e) => {
            if (e.key === 'Escape' && modal.classList.contains('visible')) {
                cancel();
            }
        };
        const closeX = modal.querySelector('.modal-close, [data-modal-close]');
        cleanup = () => {
            btn.removeEventListener('click', handler);
            modal.removeEventListener('click', onOverlay);
            document.removeEventListener('keydown', onEsc);
            if (closeX) {
                closeX.removeEventListener('click', cancel);
            }
        };
        btn.addEventListener('click', handler);
        modal.addEventListener('click', onOverlay);
        document.addEventListener('keydown', onEsc);
        if (closeX) {
            closeX.addEventListener('click', cancel);
        }
    });
}
window.encrypt_script = encrypt_script;

/** Keep the shared run admission, request and completion/error sequence. */
async function _runScriptUnified(bodyObj) {
    if (!_beginRunRequest()) {
        return { ok: false, error: 'Run request already pending' };
    }
    try {
        const res = await fetch(`${API}/api/scripts/run`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyObj),
        });
        const data = await res.json();
        if (data.success) {
            return { ok: true, taskId: data.taskId, data };
        }
        const errMsg = data.detail || data.error || 'Failed to start';
        appendLog('❌ ' + errMsg, 'error');
        if (/license|premium|hết hạn|expir|cooldown|kích hoạt/i.test(errMsg)) {
            if (!state._licenseExpiredShown) {
                state._licenseExpiredShown = true;
                if (typeof showToast === 'function') {
                    showToast(
                        _l(
                            'Premium expired — open app to renew',
                            'Premium hết hạn — mở app gia hạn',
                        ),
                        'error',
                    );
                }
            }
        }
        return { ok: false, error: data.error || errMsg, data };
    } catch (e) {
        appendLog('❌ ' + e.message, 'error');
        return { ok: false, error: e.message };
    } finally {
        _endRunRequest();
    }
}

// -----------------------------------------------------------------------------
// Console output and quick commands
// -----------------------------------------------------------------------------

function initConsole() {
    document.getElementById('clearConsole')?.addEventListener('click', () => {
        const output = document.getElementById('consoleOutput');
        output.innerHTML = '';
        state._consoleLogCount = 0;
        state._consoleTotalLines = 0;
        fetch(`${API}/api/console/clear`, { method: 'POST' }).catch(() => {});
        appendLog(_l('🗑️ Console cleared', '🗑️ Đã xoá console'));
    });

    state._consoleLogCount = 0;
    state._consoleRunId = 0;
    // A poll admitted before a tab hides can finish while animation callbacks
    // are suspended. Give that pending display batch its own explicit bound.
    // Retain only the newest display events, matching the existing300-line batch
    // DOM bound; device logs and polling cursors keep their separate ownership.
    // Contract: docs/WORKFLOW-SCREEN-RESOURCE-CONTRACT.md.
    const pendingConsoleLimit = 300;
    let _ssePending = [];
    let _sseRafScheduled = false;

    function _sseFlush() {
        _sseRafScheduled = false;
        if (_ssePending.length === 0) {
            return;
        }

        const output = document.getElementById('consoleOutput');
        const welcome = output.querySelector('.console-welcome');
        if (welcome) {
            welcome.remove();
        }

        const frag = document.createDocumentFragment();
        const ts = formatTime(new Date());

        for (const msg of _ssePending) {
            if (typeof msg === 'string' && msg.includes('__TOAST__|')) {
                const parts = msg.split('__TOAST__|')[1].split('|');
                show_toast(parts[0] || 'Toast', (parseFloat(parts[1]) || 2.0) * 1000);
                continue;
            }

            const line = document.createElement('div');
            let type = '';
            if (msg.includes('❌') || msg.includes('Error')) {
                type = 'error';
            } else if (msg.includes('✅')) {
                type = 'success';
            } else if (msg.includes('▶️') || msg.includes('📋')) {
                type = 'info';
            }
            line.className = `console-line ${type}`;

            line.innerHTML = `<span class="timestamp">${ts}</span>${_formatLogMsg(msg)}`;
            frag.appendChild(line);
        }

        const batchSize = _ssePending.length;
        _ssePending = [];
        output.appendChild(frag);

        capConsoleDOMLines(output, 300);

        if (typeof lucide !== 'undefined') {
            lucide.createIcons({ attrs: {}, nameAttr: 'data-lucide' });
        }
        output.scrollTop = output.scrollHeight;

        _incrementConsoleBadge(batchSize);
    }

    function _sseSchedule(msg) {
        _ssePending.push(msg);
        if (_ssePending.length > pendingConsoleLimit) {
            _ssePending.splice(0, _ssePending.length - pendingConsoleLimit);
        }
        if (!_sseRafScheduled) {
            _sseRafScheduled = true;
            requestAnimationFrame(_sseFlush);
        }
    }

    let _stateSince = 0;
    let _stateRunId = 0;
    let _stateBusy = false;
    let _stateTimer = null;

    async function _pollState() {
        if (_stateBusy) {
            return;
        }
        if (document.visibilityState !== 'visible') {
            return;
        }
        _stateBusy = true;
        try {
            const res = await fetch(`${API}/api/scripts/state?since=${_stateSince}`);
            const data = await res.json();
            if (!data.ok) {
                _stateBusy = false;
                return;
            }
            const isNewRun = data.runId !== _stateRunId;
            if (isNewRun) {
                _stateRunId = data.runId;
                _stateSince = 0;
            } else {
                for (const entry of data.logs || []) {
                    const m = entry.msg || '';
                    if (m.length) {
                        _sseSchedule(m);
                    }
                }
                if (typeof data.total === 'number') {
                    _stateSince = data.total;
                }
            }
            // Trạng thái daemon là nguồn sự thật DUY NHẤT cho nút.
            // Nếu đang "pending" (vừa bấm Dừng): chỉ rời pending khi daemon đã dừng hẳn,
            // không đá nút về "Dừng" dù server còn báo running (script chưa kịp thoát).
            const wasRunning = !!state.runningTaskId;
            if (data.running) {
                if (_runBtnMode === 'pending') {
                    // chờ daemon dừng hẳn, giữ nút mờ
                } else {
                    const newName = data.scriptName || null;
                    if (!wasRunning || state.runningFileName !== newName) {
                        state.runningFileName = newName;
                        state.runningTaskId = data.taskId || '__active__';
                        loadScriptFiles();
                    }
                    setRunButtonsState('running');
                    if (typeof window._syncVncOverlayPointer === 'function') {
                        window._syncVncOverlayPointer();
                    }
                }
            } else {
                if (wasRunning || _runBtnMode === 'pending') {
                    state.runningFileName = null;
                    state.runningTaskId = null;
                    loadScriptFiles();
                }
                setRunButtonsState('idle');
                if (typeof window._syncVncOverlayPointer === 'function') {
                    window._syncVncOverlayPointer();
                }
            }
        } catch (_) {
            // The app API and independent screen daemon have separate lifetimes.
            // Keep the last verified script state; the iframe owns stream recovery.
            // Contract: docs/WORKFLOW-ALWAYS-SCREEN-WEB-CONTRACT.md.
        }
        _stateBusy = false;
    }

    function _scheduleState() {
        if (_stateTimer) {
            clearTimeout(_stateTimer);
        }
        const delay = state.runningTaskId ? 400 : 2000;
        _stateTimer = setTimeout(async () => {
            await _pollState();
            _scheduleState();
        }, delay);
    }
    _scheduleState();

    setInterval(() => {
        if (document.visibilityState !== 'visible') {
            return;
        }
        const filesTab = document.querySelector('.tab[data-tab="files"]');
        if (filesTab && filesTab.classList.contains('active')) {
            loadScriptFiles();
        }
    }, 15000);

    const input = document.getElementById('quickCommand');
    const quickRunBtn = document.getElementById('quickRunBtn');

    const runQuick = () => {
        const cmd = input.value.trim();
        if (!cmd) {
            return;
        }
        const isMulti = cmd.includes(';') || cmd.includes('\n');
        const assignMatch = !isMulti && cmd.match(/^[a-zA-Z_][\w\s,]*?\s*=(?!=)\s*(.+)$/);
        const body = assignMatch ? assignMatch[1] : cmd.replace(/;\s*/g, '\n');
        const trimmed = body.trim();
        const isStmt = /^(print|let|if|while|for|fn|return|break|continue|repeat)\b/.test(trimmed);
        const isMultiline = trimmed.includes('\n');
        const wrapped =
            !isStmt && !isMultiline
                ? `let _r = ${trimmed}\nif _r == nil then print("✓ OK") else print("→", _r) end\n`
                : body + '\n';

        _runScriptUnified({
            code: wrapped,
            udid: state.currentDevice || 'local',
            scriptName: '',
        }).then((r) => {
            if (r.ok) {
                appendLog(`⚡ ${cmd}`);
            } else {
                appendLog(`✗ ${cmd} — ${r.detail || r.error || 'fail'}`);
            }
        });
        input.value = '';
    };

    input?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            runQuick();
        }
    });
    quickRunBtn?.addEventListener('click', runQuick);
}

function appendLog(message, type = '') {
    const output = document.getElementById('consoleOutput');

    if (typeof message === 'string' && message.includes('__TOAST__|')) {
        const parts = message.split('__TOAST__|')[1].split('|');
        const toastMsg = parts[0] || 'Toast';
        const toastDelay = parseFloat(parts[1]) || 2.0;
        show_toast(toastMsg, toastDelay * 1000);
        return;
    }

    const welcome = output.querySelector('.console-welcome');
    if (welcome) {
        welcome.remove();
    }

    const line = document.createElement('div');
    line.className = `console-line ${type}`;

    const timestamp = formatTime(new Date());

    if (message.includes('❌') || message.includes('Error')) {
        type = 'error';
    } else if (message.includes('✅')) {
        type = 'success';
    } else if (message.includes('▶️') || message.includes('📋')) {
        type = 'info';
    }

    line.className = `console-line ${type}`;

    line.innerHTML = `<span class="timestamp">${timestamp}</span>${_formatLogMsg(message)}`;

    output.appendChild(line);

    capConsoleDOMLines(output, 500);

    if (typeof lucide !== 'undefined') {
        lucide.createIcons({ attrs: {}, nameAttr: 'data-lucide' });
    }
    output.scrollTop = output.scrollHeight;

    _incrementConsoleBadge(1);
}

function escapeHtml(str) {
    const container = document.createElement('div');
    container.textContent = str;
    return container.innerHTML;
}

function _formatLogMsg(msg) {
    let displayMsg = escapeHtml(msg);
    for (const [emoji, icon] of Object.entries(EMOJI_MAP)) {
        if (displayMsg.includes(emoji)) {
            displayMsg = displayMsg.replace(
                emoji,
                `<i data-lucide="${icon}" style="width:13px;height:13px;display:inline-block;vertical-align:-2px;margin-right:2px;"></i>`,
            );
        }
    }
    return displayMsg;
}

function _incrementConsoleBadge(increment) {
    const panel = document.getElementById('consolePanel');
    if (!panel || panel.dataset.collapsed !== 'true') {
        return;
    }
    const badge = document.getElementById('consoleBadge');
    if (!badge) {
        return;
    }
    const currentCount = Number(badge.textContent);
    const count = (Number.isFinite(currentCount) ? currentCount : 0) + increment;
    badge.textContent = count > 99 ? '99+' : count;
    badge.style.display = 'inline';
}

/** Escape values for generated inline handlers; this is distinct from HTML escaping. */
function escJS(s) {
    return String(s == null ? '' : s).replace(
        /[\\'"<>&\r\n]/g,
        (c) =>
            ({
                '\\': '\\\\',
                "'": "\\'",
                '"': '\\u0022',
                '<': '\\u003c',
                '>': '\\u003e',
                '&': '\\u0026',
                '\r': '\\r',
                '\n': '\\n',
            })[c],
    );
}

// -----------------------------------------------------------------------------
// Keyboard shortcuts and shared modals
// -----------------------------------------------------------------------------

function initKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            if (state.runningTaskId) {
                stopScript();
            } else {
                runScript();
            }
        }

        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            if (state.currentFileName) {
                saveScriptAs(state.currentFileName);
            } else {
                const now = new Date();
                const ts =
                    now.getFullYear().toString() +
                    String(now.getMonth() + 1).padStart(2, '0') +
                    String(now.getDate()).padStart(2, '0') +
                    '_' +
                    String(now.getHours()).padStart(2, '0') +
                    String(now.getMinutes()).padStart(2, '0') +
                    String(now.getSeconds()).padStart(2, '0');
                const autoName = `script_${ts}.a`;
                saveScriptAs(autoName);
            }
        }
    });
}

function initModals() {
    document.getElementById('closeDeviceInfo')?.addEventListener('click', () => {
        document.getElementById('deviceInfoModal').classList.remove('visible');
    });

    document.getElementById('closeSaveModal')?.addEventListener('click', () => {
        document.getElementById('saveModal').classList.remove('visible');
    });
    document.getElementById('confirmSaveBtn')?.addEventListener('click', saveScript);

    document.querySelectorAll('.modal-overlay').forEach((overlay) => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.classList.remove('visible');
            }
        });
    });
}

async function showDeviceInfo() {
    const udid = state.currentDevice || 'local';
    if (!udid) {
        appendLog(_l('⚠️ No device connected', '⚠️ Chưa kết nối thiết bị'), 'error');
        return;
    }

    const modal = document.getElementById('deviceInfoModal');
    const body = document.getElementById('deviceInfoBody');
    body.innerHTML = '<p style="color: var(--text-dim)">Loading...</p>';
    modal.classList.add('visible');

    try {
        const res = await fetch(`${API}/screen_info`);
        const data = await res.json();
        if (data.success) {
            const info = data.info;
            body.innerHTML = `
                <div class="device-info-grid">
                    ${Object.entries(info)
                        .map(
                            ([key, val]) => `
                        <div class="device-info-item">
                            <div class="label">${key}</div>
                            <div class="value">${val || '—'}</div>
                        </div>
                    `,
                        )
                        .join('')}
                </div>
            `;
        }
    } catch (e) {
        body.innerHTML = `<p style="color:var(--red)">Failed to load: ${e.message}</p>`;
    }
}

// -----------------------------------------------------------------------------
// Script saving and destination selection
// -----------------------------------------------------------------------------

async function saveScript() {
    const folder = document.getElementById('saveFolderSelect')?.value || '';
    const baseName = document.getElementById('scriptNameInput').value || 'untitled.a';
    const name = folder ? `${folder}/${baseName}` : baseName;
    if (/\.aios$/i.test(name)) {
        appendLog(
            _l('❌ Cannot save over encrypted .aios', '❌ Không ghi đè file .aios đã mã hoá'),
            'error',
        );
        return;
    }
    const code = getEditorValue();

    try {
        const res = await fetch(`${API}/api/scripts/save`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, code }),
        });
        const data = await res.json();
        if (data.success) {
            state.currentFileName = data.name || name;
            state._dirty = false;
            appendLog(
                _l(`💾 Saved: ${state.currentFileName}`, `💾 Đã lưu: ${state.currentFileName}`),
                'success',
            );
            document.getElementById('saveModal').classList.remove('visible');
            loadScriptFiles();
            if (state._runAfterSave) {
                state._runAfterSave = false;
                runScript();
            }
        } else {
            state._runAfterSave = false;
            appendLog(
                _l(
                    `❌ Save failed: ${data.error || 'unknown'}`,
                    `❌ Lưu thất bại: ${data.error || 'không rõ lý do'}`,
                ),
                'error',
            );
        }
    } catch (e) {
        state._runAfterSave = false;
        appendLog('❌ Save failed: ' + e.message, 'error');
    }
}

function populateFolderPicker() {
    const sel = document.getElementById('saveFolderSelect');
    if (!sel) {
        return;
    }
    const folders = state._folders || [];
    sel.innerHTML =
        '<option value="">/ (root)</option>' +
        folders.map((f) => `<option value="${f}">${f}</option>`).join('');
    if (state.currentFileName && state.currentFileName.includes('/')) {
        const folder = state.currentFileName.substring(0, state.currentFileName.lastIndexOf('/'));
        sel.value = folder;
        document.getElementById('scriptNameInput').value = state.currentFileName.split('/').pop();
    }
}

const _saveModalEl = document.getElementById('saveModal');
if (_saveModalEl) {
    const _saveMo = new MutationObserver(() => {
        if (_saveModalEl.classList.contains('visible')) {
            populateFolderPicker();
        }
    });
    _saveMo.observe(_saveModalEl, { attributes: true, attributeFilter: ['class'] });
}

async function saveScriptAs(fileName) {
    if (/\.aios$/i.test(fileName || '')) {
        appendLog(
            _l('❌ Cannot save over encrypted .aios', '❌ Không ghi đè file .aios đã mã hoá'),
            'error',
        );
        return;
    }
    const code = getEditorValue();
    try {
        const res = await fetch(`${API}/api/scripts/save`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: fileName, code }),
        });
        const data = await res.json();
        if (data.success) {
            state.currentFileName = data.name || fileName;
            state._dirty = false;
            document.getElementById('scriptNameInput').value = state.currentFileName;
            appendLog(
                _l(`💾 Saved: ${state.currentFileName}`, `💾 Đã lưu: ${state.currentFileName}`),
                'success',
            );
            showToast(`💾 ${state.currentFileName}`, 'success');
        } else {
            showToast(`❌ ${data.error || 'Save failed'}`, 'error');
        }
    } catch (e) {
        appendLog('❌ Save failed: ' + e.message, 'error');
        showToast(`❌ ${e.message}`, 'error');
    }
}

// -----------------------------------------------------------------------------
// File notifications and folder navigation
// -----------------------------------------------------------------------------

function showToast(text, kind) {
    const id = 'zx-toast-' + Date.now();
    const el = document.createElement('div');
    el.id = id;
    const bg = kind === 'error' ? '#ef4444' : kind === 'warning' ? '#f59e0b' : '#10b981';
    el.style.cssText = `position:fixed;bottom:20px;right:20px;background:${bg};color:#fff;padding:10px 16px;border-radius:8px;font-size:13px;font-weight:500;box-shadow:0 4px 16px rgba(0,0,0,0.3);z-index:99999;opacity:0;transform:translateY(10px);transition:opacity 0.2s, transform 0.2s;`;
    el.textContent = text;
    document.body.appendChild(el);
    requestAnimationFrame(() => {
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
    });
    setTimeout(() => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(10px)';
        setTimeout(() => el.remove(), 250);
    }, 2000);
}
window.showToast = showToast;

if (!window._expandedFolders) {
    window._expandedFolders = new Set();
}

function renderFolderItem(f, indent = 0) {
    const expanded = window._expandedFolders.has(f.path);
    const childrenHtml = expanded
        ? f.children
              .sort((a, b) => {
                  if (a.type !== b.type) {
                      return a.type === 'folder' ? -1 : 1;
                  }
                  return (b.modified || 0) - (a.modified || 0);
              })
              .map((c) => renderFileItem(c, indent + 1))
              .join('')
        : '';
    const childWrapper =
        expanded && childrenHtml
            ? `
      <div class="folder-children" style="margin-left:${12 + indent * 12}px; padding-left:12px; border-left:2px solid rgba(96,165,250,0.25); margin-bottom:6px;">
        ${childrenHtml}
      </div>`
            : '';
    return `
      <div class="folder-item" style="margin-left:${indent * 12}px" onclick="toggleFolder('${f.path}')">
        <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0;">
          <i data-lucide="${expanded ? 'folder-open' : 'folder'}" style="width:16px;height:16px;flex-shrink:0;color:#60a5fa;"></i>
          <div style="min-width:0;">
            <div class="file-name" style="font-weight:600;">${f.name}</div>
            <div class="file-meta">${f.count || 0} ${_l('items', 'mục')}</div>
          </div>
        </div>
        <div class="file-actions">
          <i data-lucide="${expanded ? 'chevron-down' : 'chevron-right'}" style="width:14px;height:14px;opacity:0.4;"></i>
          <button class="file-action-btn file-delete-btn" onclick="event.stopPropagation(); delete_file('${f.path}')" title="Delete Folder"><i data-lucide="trash-2" style="width:14px;height:14px;"></i></button>
        </div>
      </div>
      ${childWrapper}`;
}

function renderFileItem(f, indent = 0) {
    if (f.type === 'folder') {
        return renderFolderItem(f, indent);
    }
    const date = new Date(f.modified * 1000);
    const dateStr = date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    const isRunning = state.runningFileName === f.path;
    const isTxt = f.name.endsWith('.txt');
    const isPy = f.name.endsWith('.a');
    const isEnc = f.name.endsWith('.aios') || f.encrypted;
    const fileIcon = isEnc ? 'lock' : isTxt ? 'file-text' : isRunning ? 'flame' : 'file-code';
    const iconStyle = isEnc
        ? 'color:#f59e0b;'
        : isRunning
          ? 'color:#f97316;'
          : isTxt
            ? 'color:#94a3b8;'
            : 'opacity:0.5;';
    const pathJS = escJS(f.path);
    const playStopBtn = isTxt
        ? ''
        : isRunning
          ? `<button class="file-action-btn file-stop-btn" onclick="event.stopPropagation(); stopScript()" title="Stop"><i data-lucide="square" style="width:14px;height:14px;"></i></button>`
          : `<button class="file-action-btn file-play-btn" onclick="event.stopPropagation(); runFileScript('${pathJS}')" title="Run"><i data-lucide="play" style="width:14px;height:14px;"></i></button>`;
    const moveBtn = `<button class="file-action-btn" onclick="event.stopPropagation(); moveFileToFolder('${pathJS}')" title="Move" style="color:#60a5fa;"><i data-lucide="folder-input" style="width:14px;height:14px;"></i></button>`;
    return `
    <div class="file-item ${isRunning ? 'file-running' : ''}" onclick="loadFile('${pathJS}')">
      <div style="display:flex;align-items:center;gap:8px;flex:1;min-width:0;">
        <i data-lucide="${fileIcon}" style="width:16px;height:16px;flex-shrink:0;${iconStyle}"></i>
        <div style="min-width:0;">
          <div class="file-name">${escapeHtml(f.name)}</div>
          <div class="file-meta">${dateStr} · ${(f.size / 1024).toFixed(1)}KB${isRunning ? ` · <span style="color:#22c55e;font-weight:600;">${_l('Running', 'Đang chạy')}</span>` : ''}</div>
        </div>
      </div>
      <div class="file-actions">
        ${playStopBtn}
        ${moveBtn}
        ${isPy ? `<button class="file-action-btn" onclick="event.stopPropagation(); encrypt_script('${pathJS}')" title="Encrypt" style="color:#f59e0b;"><i data-lucide="lock" style="width:14px;height:14px;"></i></button>` : ''}
        <button class="file-action-btn" onclick="event.stopPropagation(); downloadFile('${pathJS}')" title="Download"><i data-lucide="download" style="width:14px;height:14px;"></i></button>
        ${!isEnc ? `<button class="file-action-btn file-rename-btn" onclick="event.stopPropagation(); renameFile('${pathJS}')" title="Rename"><i data-lucide="pencil" style="width:14px;height:14px;"></i></button>` : ''}
        <button class="file-action-btn file-delete-btn" onclick="event.stopPropagation(); delete_file('${pathJS}')" title="Delete"><i data-lucide="trash-2" style="width:14px;height:14px;"></i></button>
      </div>
    </div>`;
}

function toggleFolder(path) {
    if (window._expandedFolders.has(path)) {
        window._expandedFolders.delete(path);
    } else {
        window._expandedFolders.add(path);
    }
    loadScriptFiles();
}
window.toggleFolder = toggleFolder;

async function createFolder() {
    const name = prompt('Folder name:');
    if (!name || !name.trim()) {
        return;
    }
    try {
        const res = await fetch(`${API}/api/scripts/mkdir`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: name.trim() }),
        });
        const data = await res.json();
        if (data.success) {
            appendLog(
                _l(`📁 Created folder: ${data.path}`, `📁 Đã tạo thư mục: ${data.path}`),
                'success',
            );
            loadScriptFiles();
        } else {
            appendLog(`❌ ${data.error}`, 'error');
        }
    } catch (e) {
        appendLog('❌ Create folder failed: ' + e.message, 'error');
    }
}
window.createFolder = createFolder;

async function moveScriptPath(from, to) {
    const res = await fetch(`${API}/api/scripts/move`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ from, to }),
    });
    const data = await res.json();
    if (!data.success && !data.ok) {
        throw new Error(data.error || 'move fail');
    }
    return data;
}

async function moveFileToFolder(filePath) {
    const folders = state._folders || [];
    const current = filePath.includes('/') ? filePath.substring(0, filePath.lastIndexOf('/')) : '';
    const label = _l(
        `Move to folder (empty = root):\nAvailable: ${folders.join(', ') || '(none)'}`,
        `Chuyển vào thư mục (trống = root):\nCó: ${folders.join(', ') || '(không có)'}`,
    );
    const choice = prompt(label, current);
    if (choice === null) {
        return;
    }
    const targetFolder = choice.trim();
    const fileName = filePath.split('/').pop();
    const newPath = targetFolder ? `${targetFolder}/${fileName}` : fileName;
    if (newPath === filePath) {
        return;
    }
    try {
        await moveScriptPath(filePath, newPath);
        appendLog(`📁 Moved: ${filePath} → ${newPath}`, 'success');
        if (state.currentFileName === filePath) {
            state.currentFileName = newPath;
            document.getElementById('scriptNameInput').value = newPath;
        }
        loadScriptFiles();
    } catch (e) {
        appendLog('❌ Move failed: ' + e.message, 'error');
    }
}
window.moveFileToFolder = moveFileToFolder;

// -----------------------------------------------------------------------------
// Image library uploads and actions
// -----------------------------------------------------------------------------

async function loadImagesTab() {
    const list = document.getElementById('imagesList');
    const count = document.getElementById('imagesCount');
    if (!list) {
        return;
    }
    try {
        const r = await fetch(`${API}/api/images`);
        const d = await r.json();
        const imgs = d.images || [];
        if (count) {
            count.textContent = imgs.length + ' ' + _t('imgCountLabel');
        }
        if (!imgs.length) {
            list.innerHTML = `<div style="grid-column:1/-1; text-align:center; color:#888; padding:30px;">${_t('imgEmpty')}</div>`;
            return;
        }
        list.innerHTML = imgs
            .map((img) => {
                const sz = (img.size / 1024).toFixed(1) + ' KB';
                const nameJS = escJS(img.name);
                const nameHTML = escapeHtml(img.name);
                return `<div style="background:var(--bg-secondary); border:1px solid var(--border-color); border-radius:8px; padding:8px; display:flex; flex-direction:column; gap:6px;">
        <img src="${API}/api/images/${encodeURIComponent(img.name)}?t=${Date.now()}" style="width:100%; height:90px; object-fit:contain; background:#1a1a2e; border-radius:4px;" loading="lazy" />
        <div style="font-size:11px; color:#ddd; word-break:break-all; line-height:1.2;">${nameHTML}</div>
        <div style="font-size:10px; color:#888;">${sz}</div>
        <div class="hm-row-btns">
          <button type="button" class="hm-btn-copy" onclick="copyImageName('${nameJS}')">${_t('hmBtnCopy')}</button>
          <button type="button" class="btn-danger btn-sm image-delete-button" aria-label="${escapeHtml(_t('imgDeleteLabel'))}" title="${escapeHtml(_t('imgDeleteLabel'))}" onclick="deleteImage('${nameJS}')"><i data-lucide="trash-2" aria-hidden="true"></i></button>
        </div>
      </div>`;
            })
            .join('');
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    } catch (e) {
        list.innerHTML = `<div style="grid-column:1/-1; color:#f44;">${_t('imgLoadErr')}${e.message}</div>`;
    }
}

function copyImageName(name) {
    _hmDoCopy(name.replace(/\.(png|jpg|jpeg)$/i, ''));
}

async function deleteImage(name) {
    if (!confirm(_t('imgDeleteConfirm') + name + '?')) {
        return;
    }
    try {
        const r = await fetch(`${API}/api/images/${encodeURIComponent(name)}`, {
            method: 'DELETE',
        });
        const d = await r.json().catch(() => ({}));
        if (!r.ok || !d.ok) {
            appendLog(_t('imgDeleteFail') + (d.error || 'HTTP ' + r.status), 'error');
            return;
        }
        loadImagesTab();
    } catch (e) {
        appendLog(_t('imgDeleteFail') + e.message, 'error');
    }
}

async function uploadImagesFiles(files, dest) {
    const toAlbum = dest === 'album';
    const toVcam = dest === 'vcam';
    let ok = 0;
    const total = files.length;
    const q = toVcam ? '&dest=vcam' : toAlbum ? '&dest=album' : '';
    for (const f of files) {
        try {
            const buf = await f.arrayBuffer();
            const r = await fetch(`${API}/api/images?name=${encodeURIComponent(f.name)}${q}`, {
                method: 'POST',
                body: buf,
            });
            const d = await r.json();
            if (d.ok) {
                ok++;
                const msg = toVcam
                    ? _t('vcamImportOk') + (d.name || f.name)
                    : toAlbum
                      ? _t('albumImportOk') + (d.name || f.name) + ` (${ok}/${total})`
                      : _t('imgUploadOk') + d.name;
                appendLog(msg);
            } else {
                appendLog(
                    (toVcam
                        ? _t('vcamImportFail')
                        : toAlbum
                          ? _t('albumImportFail')
                          : _t('imgUploadFail')) + (d.raw || d.error || ''),
                    'error',
                );
            }
        } catch (e) {
            appendLog(
                (toVcam
                    ? _t('vcamImportFail')
                    : toAlbum
                      ? _t('albumImportFail')
                      : _t('imgUploadFail')) + e.message,
                'error',
            );
        }
    }
    if (toAlbum) {
        if (total > 1) {
            appendLog(_t('albumImportDone') + `${ok}/${total}`);
        }
    } else if (!toVcam) {
        loadImagesTab();
    }
}

window.copyImageName = copyImageName;
window.deleteImage = deleteImage;
window.loadImagesTab = loadImagesTab;

document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('imageUploadInput');
    if (!input) {
        return;
    }
    let dest = 'script';
    document.getElementById('uploadImageBtn')?.addEventListener('click', () => {
        dest = 'script';
        input.accept = 'image/*';
        input.multiple = true;
        input.click();
    });
    document.getElementById('importAlbumBtn')?.addEventListener('click', () => {
        dest = 'album';
        input.accept = 'image/*,video/mp4,video/quicktime,.mp4,.mov';
        input.multiple = true;
        input.click();
    });
    document.getElementById('importVcamBtn')?.addEventListener('click', () => {
        dest = 'vcam';
        input.accept =
            'image/png,image/jpeg,image/heic,video/mp4,video/quicktime,.mp4,.mov,.png,.jpg,.jpeg,.heic';
        input.multiple = false;
        input.click();
    });
    input.addEventListener('change', (e) => {
        const files = e.target.files?.length ? Array.from(e.target.files) : [];
        e.target.value = '';
        if (files.length) {
            uploadImagesFiles(files, dest);
        }
    });
});

// -----------------------------------------------------------------------------
// Script file listing and lifecycle
// -----------------------------------------------------------------------------

async function loadScriptFiles() {
    try {
        const res = await fetch(`${API}/api/scripts/files`);
        const data = await res.json();
        const container = document.getElementById('filesList');

        state._folders = data.folders || [];

        const KEEP_EXT = /\.(a|aios|txt)$/i;
        function keepFile(f) {
            if (f.type === 'folder') {
                return true;
            }
            return KEEP_EXT.test(f.name);
        }
        function filterTree(arr) {
            return arr.filter(keepFile).map((f) => {
                if (f.type === 'folder' && Array.isArray(f.children)) {
                    const kids = filterTree(f.children);
                    return { ...f, children: kids, count: kids.length };
                }
                return f;
            });
        }
        const visible = filterTree(data.files || []);

        if (!data.success || visible.length === 0) {
            container.innerHTML =
                '<div class="files-empty">' +
                _l(
                    'No saved scripts yet.<br>Press 💾 to save your first script.',
                    'Chưa có script nào.<br>Bấm 💾 để lưu script đầu tiên.',
                ) +
                '</div>';
            return;
        }

        const sorted = visible.sort((a, b) => {
            if (a.type !== b.type) {
                return a.type === 'folder' ? -1 : 1;
            }
            return (b.modified || 0) - (a.modified || 0);
        });

        container.innerHTML = sorted.map((f) => renderFileItem(f)).join('');
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    } catch (e) {
        console.error('Load files failed:', e);
    }
}

async function delete_file(name) {
    try {
        const res = await fetch(`${API}/api/scripts/delete?name=${encodeURIComponent(name)}`, {
            method: 'POST',
        });
        const data = await res.json();
        if (data.success) {
            appendLog(_l(`🗑️ Deleted: ${name}`, `🗑️ Đã xoá: ${name}`));
            loadScriptFiles();
        } else {
            appendLog(`❌ Delete failed`, 'error');
        }
    } catch (e) {
        appendLog('❌ Delete failed: ' + e.message, 'error');
    }
}

async function loadFile(name) {
    try {
        const res = await fetch(`${API}/api/scripts/load?name=${encodeURIComponent(name)}`);
        const data = await res.json();
        if (data.success) {
            const isEncrypted = data.encrypted || false;
            if (!openTab(name, data.code, isEncrypted)) {
                return;
            }
            const nameInput = document.getElementById('scriptNameInput');
            if (nameInput) {
                nameInput.value = name;
            }
            document.querySelector('.tab[data-tab="editor"]')?.click();
            appendLog(
                _l(
                    `📂 Loaded: ${name}${isEncrypted ? ' 🔒' : ''}`,
                    `📂 Đã mở: ${name}${isEncrypted ? ' 🔒' : ''}`,
                ),
            );
        } else {
            appendLog(
                _l(
                    `❌ Load failed: ${data.error || name}`,
                    `❌ Mở file thất bại: ${data.error || name}`,
                ),
                'error',
            );
        }
    } catch (e) {
        appendLog('❌ Load failed: ' + e.message, 'error');
    }
}

async function renameFile(oldName) {
    const fileRows = document.querySelectorAll('.file-item');
    let targetRow = null;
    for (const row of fileRows) {
        if (row.textContent.includes(oldName)) {
            targetRow = row;
            break;
        }
    }

    if (!targetRow) {
        const newName = window.prompt('Rename file:', oldName.replace(/\.a$/, ''));
        if (!newName || newName === oldName.replace(/\.a$/, '')) {
            return;
        }
        await doRename(oldName, newName);
        return;
    }

    const nameEl = targetRow.querySelector('.file-name');
    if (!nameEl) {
        return;
    }
    const origText = nameEl.textContent;
    const input = document.createElement('input');
    input.type = 'text';
    input.value = oldName.replace(/\.a$/, '');
    input.className = 'rename-input';
    input.style.cssText =
        'padding:2px 6px; font-size:12px; border-radius:4px; border:1px solid var(--accent); background:var(--bg-primary); color:var(--text-primary); width:120px; outline:none;';
    nameEl.textContent = '';
    nameEl.appendChild(input);
    input.focus();
    input.select();

    const finish = async (confirmed) => {
        if (confirmed) {
            const val = input.value.trim();
            if (val && val !== oldName.replace(/\.a$/, '')) {
                await doRename(oldName, val);
                return;
            }
        }
        nameEl.textContent = origText;
    };

    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            finish(true);
        }
        if (e.key === 'Escape') {
            e.preventDefault();
            finish(false);
        }
    });
    input.addEventListener('blur', () => finish(false));
}

async function doRename(oldName, newName) {
    const ext = oldName.match(/\.[^.]+$/);
    const origExt = ext ? ext[0] : '.a';
    const finalName = newName.match(/\.[^.]+$/) ? newName : newName + origExt;
    try {
        await moveScriptPath(oldName, finalName);
        if (state.currentFileName === oldName) {
            state.currentFileName = finalName;
            document.getElementById('scriptNameInput').value = finalName;
        }
        appendLog(
            _l(`✏️ Renamed: ${oldName} → ${finalName}`, `✏️ Đã đổi tên: ${oldName} → ${finalName}`),
        );
        loadScriptFiles();
    } catch (e) {
        appendLog('❌ Rename failed: ' + e.message, 'error');
    }
}
window.renameFile = renameFile;

window.loadFile = loadFile;
window.delete_file = delete_file;
window.downloadFile = downloadFile;

// -----------------------------------------------------------------------------
// Downloads and backup import/export
// -----------------------------------------------------------------------------

function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

async function downloadFile(name) {
    try {
        const ext = name.split('.').pop().toLowerCase();
        const href = `${API}/api/scripts/download?name=${encodeURIComponent(name)}`;

        if (ext === 'aios') {
            const a = document.createElement('a');
            a.href = href;
            a.download = name;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            appendLog(`⬇️ Downloaded: ${name} 🔒`, 'success');
        } else {
            const res = await fetch(href);
            if (res.ok) {
                const blob = await res.blob();
                triggerDownload(blob, name);
                appendLog(`⬇️ Downloaded: ${name}`, 'success');
            } else {
                appendLog(`❌ Download failed`, 'error');
            }
        }
    } catch (e) {
        appendLog('❌ Download failed: ' + e.message, 'error');
    }
}

async function exportBackup() {
    const btn = document.getElementById('exportBackupBtn');
    const origHTML = btn.innerHTML;
    btn.innerHTML =
        '<i data-lucide="loader" style="width:12px;height:12px;animation:spin 1s linear infinite;"></i> Exporting...';
    btn.disabled = true;
    try {
        const res = await fetch(`${API}/api/backup/export`, { method: 'POST' });
        const data = await res.json();
        if (!data.success) {
            throw new Error('Export failed');
        }
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const now = new Date();
        const ts =
            now.getFullYear().toString() +
            String(now.getMonth() + 1).padStart(2, '0') +
            String(now.getDate()).padStart(2, '0') +
            '_' +
            String(now.getHours()).padStart(2, '0') +
            String(now.getMinutes()).padStart(2, '0');
        a.href = url;
        a.download = `na_backup_${ts}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        appendLog(
            `✅ Exported: ${data.script_count} scripts, ${data.image_count} images`,
            'success',
        );
    } catch (e) {
        appendLog('❌ Export failed: ' + e.message, 'error');
    } finally {
        btn.innerHTML = origHTML;
        btn.disabled = false;
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }
}

async function importBackup(file) {
    const btn = document.getElementById('importBackupBtn');
    const origHTML = btn.innerHTML;
    btn.innerHTML =
        '<i data-lucide="loader" style="width:12px;height:12px;animation:spin 1s linear infinite;"></i> Importing...';
    btn.disabled = true;
    try {
        const text = await file.text();
        const backup = JSON.parse(text);
        if (!backup.scripts && !backup.images) {
            throw new Error('Invalid backup file');
        }
        const res = await fetch(`${API}/api/backup/import`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: text,
        });
        const data = await res.json();
        if (data.success) {
            appendLog(
                `✅ Imported: ${data.scripts_imported} scripts, ${data.images_imported} images`,
                'success',
            );
            loadScriptFiles();
        } else {
            throw new Error(data.error || 'Import failed');
        }
    } catch (e) {
        appendLog('❌ Import failed: ' + e.message, 'error');
    } finally {
        btn.innerHTML = origHTML;
        btn.disabled = false;
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    }
}

document.getElementById('exportBackupBtn')?.addEventListener('click', exportBackup);
document.getElementById('importBackupBtn')?.addEventListener('click', () => {
    document.getElementById('importFileInput').click();
});
document.getElementById('importFileInput')?.addEventListener('change', async (e) => {
    if (!e.target.files[0]) {
        return;
    }
    const file = e.target.files[0];
    const ext = file.name.split('.').pop().toLowerCase();

    if (ext === 'json') {
        try {
            const text = await file.text();
            const parsed = JSON.parse(text);
            if (parsed && (parsed.scripts || parsed.images)) {
                importBackup(file);
                e.target.value = '';
                return;
            }
        } catch (_) {}
    }
    if (ext === 'aios') {
        try {
            const buf = await file.arrayBuffer();
            const b64 = btoa(String.fromCharCode(...new Uint8Array(buf)));
            const res = await fetch(`${API}/api/scripts/upload`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: file.name, data: b64 }),
            });
            const data = await res.json();
            if (data.success) {
                appendLog(`✅ Imported encrypted script: ${file.name} 🔒`, 'success');
                showToast(`🔒 Imported ${file.name}`, 'success');
                loadScriptFiles();
            } else {
                appendLog(`❌ Import failed: ${data.error}`, 'error');
                showToast(`❌ ${data.error}`, 'error');
            }
        } catch (err) {
            appendLog(`❌ Import error: ${err.message}`, 'error');
        }
    } else if (!ext || ['dylib', 'so', 'bin', 'plist', 'deb', 'ipa', 'exe'].includes(ext)) {
        appendLog(`❌ Unsupported file type: .${ext}`, 'error');
    } else {
        try {
            const code = await file.text();
            const res = await fetch(`${API}/api/scripts/upload`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: file.name, code }),
            });
            const data = await res.json();
            if (data.success) {
                appendLog(`✅ Imported: ${file.name}`, 'success');
                showToast(`✅ Imported ${file.name}`, 'success');
                loadScriptFiles();
            } else {
                appendLog(`❌ Import failed: ${data.error}`, 'error');
                showToast(`❌ ${data.error}`, 'error');
            }
        } catch (err) {
            appendLog(`❌ Import error: ${err.message}`, 'error');
        }
    }
    e.target.value = '';
});

/** Create a fresh SDK category table for each catalog initialization. */
// -----------------------------------------------------------------------------
// SDK categories and localized method descriptions
// Factories retain fresh per-initialization tables; method names and text stay unchanged.
// -----------------------------------------------------------------------------

function createSdkCategories() {
    return {
        Touch: {
            names: [
                'tap',
                'swipe',
                'long_press',
                'tap_down',
                'tap_move',
                'tap_up',
                'pinch',
                'rotate',
                'tap_release',
                'tap_sequence',
                'show_tap_dots',
                'ax_tap',
            ],
        },
        Keyboard: {
            names: [
                'type_keys',
                'insert_text',
                'paste_text',
                'press_key',
                'home',
                'delete_backward',
                'ax_type',
            ],
        },
        Clipboard: { names: ['set_clipboard', 'get_clipboard', 'paste', 'clear_clipboard'] },
        Color: {
            names: [
                'pick_color',
                'find_color',
                'get_colors',
                'wait_for_color',
                'int_to_rgb',
                'rgb_to_int',
            ],
        },
        Image: {
            names: [
                'screenshot',
                'image_match',
                'tap_image',
                'wait_for_image',
                'swipe_until_image',
                'save_to_album',
                'clear_album',
            ],
        },
        VCam: {
            names: [
                'set_vcam',
                'clear_vcam',
                'vcam_zoom',
                'vcam_zoom_in',
                'vcam_zoom_out',
                'vcam_left',
                'vcam_right',
                'vcam_up',
                'vcam_down',
                'vcam_pause',
                'vcam_resume',
                'vcam_restart',
            ],
        },
        OCR: {
            names: [
                'ocr',
                'find_text',
                'tap_text',
                'wait_for_text',
                'wait_and_tap_text',
                'swipe_until_text',
                'ocr_languages',
                'ax',
                'ax_find',
                'ax_exists',
                'ax_wait',
                'ax_inc',
                'ax_dec',
                'ax_adjust_to',
            ],
        },
        System: {
            names: [
                'restart',
                'get_screen_size',
                'get_screen_scale',
                'get_screen_orientation',
                'screen_size_invalidate',
                'get_device_info',
                'get_battery_info',
                'get_wifi_info',
                'get_front_app',
                'current_dir',
                'root_dir',
                'spoof_reload',
                'hud_status',
                'hud_show',
                'hud_hide',
                'get_ip',
                'get_sn',
            ],
        },
        App: {
            names: [
                'app_state',
                'kill_app',
                'switch_to_app',
                'open_url',
                'open_settings',
                'change_app',
                'reset_app_data',
                'clear_app_data',
                'backup_app',
                'restore_app',
                'clone_app',
            ],
        },
        File: {
            names: [
                'run_shell',
                'run_shell_json',
                'read_file',
                'write_file',
                'append_file',
                'delete_file',
                'file_exists',
            ],
        },
        Network: {
            names: [
                'set_airplane_mode',
                'set_cellular_data',
                'http_get',
                'http_post',
                'set_proxy',
                'clear_proxy',
                'proxy_status',
                'shadowrocket_on',
                'shadowrocket_off',
                'clean_vpn_state',
                'vpn_status',
            ],
        },
        Sleep: { names: ['sleep', 'usleep', 'random_sleep'] },
        UI: {
            names: [
                'show_toast',
                'show_toast_ex',
                'show_alert_box',
                'vibrate',
                'dialog_input',
                'dialog_choice',
                'show_overlay',
                'update_overlay',
                'hide_overlay',
            ],
        },
        Recording: { names: ['record_start', 'record_stop'] },
        Script: { names: ['play_script', 'stop_script', 'daemon_ping', 'encrypt_script'] },
        Safari: {
            names: [
                'web_fill',
                'web_click',
                'web_long_press',
                'web_wait',
                'web_text',
                'web_exists',
                'web_back',
                'web_reload',
                'web_url',
                'web_title',
                'web_js',
                'get_cookies',
                'safari_import_cookies',
            ],
        },
        Lang: {
            names: [
                'print',
                'str',
                'string.upper',
                'string.lower',
                'string.trim',
                'string.split',
                'string.join',
                'string.replace',
                'string.contains',
                'string.starts_with',
                'string.ends_with',
                'string.len',
                'math.abs',
                'math.floor',
                'math.ceil',
                'math.round',
                'math.sqrt',
                'math.pow',
                'math.min',
                'math.max',
                'math.random',
                'random_int',
                'random_float',
                'random_pick',
                'random_string',
                'push',
                'pop',
                'keys',
                'has',
                'now',
                'time_ms',
                'base64_encode',
                'base64_decode',
                'md5',
                'sha256',
                'json_encode',
                'json_decode',
            ],
        },
    };
}

/** Create a fresh SDK description table for each catalog initialization. */
function createSdkVietnameseDescriptions() {
    return {
        tap: 'Chạm 1 lần (±0–1px, hold 40–90ms random)',
        swipe: 'Vuốt A→B (cong nhẹ + chậm đầu/cuối; dur giữ đúng script)',
        long_press: 'Nhấn giữ tại toạ độ',
        home: 'Bấm nút Home',
        restart:
            'Khởi động lại userspace; mở khóa máy không passcode, đợi 60 giây rồi tiếp tục script tại điểm đã lưu',
        press_key: 'Bấm phím vật lý (home/power/volume)',
        insert_text: 'Gõ chữ vào ô đang nhập (~70–130ms/ký tự; thêm delay_sec để chỉnh)',
        show_tap_dots: 'Hiện chấm xanh khi chạm (xem cho dễ)',
        paste_text: 'Dán chữ tức thời',
        set_clipboard: 'Lưu chữ vào bộ nhớ tạm',
        get_clipboard: 'Lấy chữ từ bộ nhớ tạm',
        paste: 'Dán bộ nhớ tạm vào ô đang nhập',
        clear_clipboard: 'Xoá bộ nhớ tạm',
        pinch: 'Chụm 2 ngón để phóng to/thu nhỏ',
        rotate: 'Xoay 2 ngón quanh tâm',
        tap_down: 'Nhấn ngón tay xuống',
        tap_move: 'Di chuyển ngón tay',
        tap_up: 'Nhấc ngón tay lên',
        tap_sequence: 'Chuỗi nhiều thao tác chạm',
        tap_release: 'Nhả hết ngón đang giữ',
        type_keys: 'Bấm liên tiếp nhiều phím (delay_sec mặc định 0.08)',
        screenshot: 'Chụp màn hình, lưu vào ảnh',
        image_match: 'Tìm ảnh có trên màn hình không',
        tap_image: 'Tìm ảnh rồi chạm vào ảnh đó',
        wait_for_image: 'Đợi tới khi ảnh xuất hiện',
        swipe_until_image: 'Vuốt liên tục đến khi thấy ảnh',
        save_to_album: 'Lưu ảnh vào Photos',
        clear_album: 'Xoá hết ảnh trong Photos',
        ocr: 'Đọc chữ trong 1 vùng màn hình',
        find_text: 'Tìm chữ (match=0.9 — tỉ lệ khớp)',
        tap_text: 'Tìm chữ rồi chạm (match cuối)',
        wait_for_text: 'Đợi chữ xuất hiện (match cuối)',
        wait_and_tap_text: 'Đợi chữ rồi chạm (match cuối)',
        swipe_until_text: 'Vuốt đến khi thấy chữ (match cuối)',
        ocr_languages: 'Danh sách ngôn ngữ OCR',
        pick_color: 'Lấy màu tại 1 điểm',
        find_color: 'Tìm điểm có màu chỉ định',
        wait_for_color: 'Đợi 1 điểm chuyển sang màu',
        get_colors: 'Lấy màu tại nhiều điểm cùng lúc',
        int_to_rgb: 'Đổi số nguyên thành màu RGB',
        rgb_to_int: 'Đổi màu RGB thành số nguyên',
        get_screen_size: 'Kích thước màn hình (pixel)',
        get_screen_orientation: 'Hướng màn hình (1=dọc, 3/4=ngang)',
        get_device_info: 'Thông tin thật của máy (tên, iOS, model)',
        get_battery_info: '% pin và trạng thái sạc',
        get_wifi_info: 'IP + SSID WiFi đang kết nối',
        get_front_app: 'App nào đang mở trên màn hình',
        get_ip: 'IP của máy',
        hud_status: 'Icon nổi đang bật hay tắt',
        hud_show: 'Hiện icon nổi (chạm để play/stop script)',
        hud_hide: 'Tắt icon nổi',
        app_state: 'App có đang ở màn hình trước hay không',
        kill_app: 'Đóng app',
        switch_to_app: 'Mở app lên',
        open_url: 'Mở 1 đường link',
        open_settings: 'Mở app Cài đặt',
        change_app: 'Fake App (NChanger)',
        reset_app_data: 'Xoá data app + đổi danh tính (NAuto)',
        clear_app_data: 'Chỉ xoá data app (NAuto)',
        backup_app: 'Sao lưu app (NAuto)',
        restore_app: 'Khôi phục app (NAuto)',
        clone_app: 'Nhân bản app (NAuto)',
        spoof_reload: 'Áp dụng spoof (NAuto)',
        get_screen_scale: 'Tỉ lệ Retina (2x/3x)',
        get_sn: 'Số serial máy',
        current_dir: 'Thư mục scripts',
        root_dir: 'Thư mục gốc NAuto',
        safari_import_cookies: 'Copy cookie jar app → Safari',
        screen_size_invalidate: 'Xóa cache kích thước màn hình',
        sleep: 'Chờ N giây',
        random_sleep: 'Chờ ngẫu nhiên (giả người dùng)',
        usleep: 'Chờ chính xác bằng micro giây',
        http_get: 'Tải dữ liệu từ URL (GET)',
        http_post: 'Gửi dữ liệu lên URL (POST)',
        set_proxy: 'Đặt HTTP proxy Wi‑Fi (không phải Shadowrocket)',
        clear_proxy: 'Xoá HTTP proxy Wi‑Fi',
        set_vcam: 'Bật camera ảo (ảnh/video) — cần DEB zxvcam',
        clear_vcam: 'Tắt camera ảo',
        vcam_zoom: 'Zoom camera ảo (1=vừa khung, >1 phóng)',
        vcam_zoom_in: 'Phóng to camera ảo (+0.25)',
        vcam_zoom_out: 'Thu nhỏ camera ảo (−0.25)',
        vcam_pause: 'Dừng/chạy video ảo (không arg = ấn đổi)',
        vcam_resume: 'Chạy tiếp video ảo',
        vcam_restart: 'Phát lại video ảo từ đầu, giữ zoom và vị trí',
        proxy_status: 'Trạng thái HTTP proxy Wi‑Fi (set_proxy): 1=tắt 3=bật',
        shadowrocket_on: 'Bật Shadowrocket VPN',
        shadowrocket_off: 'Tắt Shadowrocket VPN',
        set_airplane_mode: 'Bật/tắt chế độ máy bay',
        set_cellular_data: 'Bật/tắt 4G/5G',
        clean_vpn_state: 'Xoá cấu hình Shadowrocket',
        vpn_status: 'Trạng thái tunnel: ưu tiên Shadowrocket, không thì Wi‑Fi proxy',
        show_toast: 'Hiện popup nhỏ rồi tự đóng',
        show_toast_ex: 'Hiện popup với màu tuỳ chỉnh (bg_color, fg_color)',
        show_alert_box: 'Hộp thoại tự đóng — có thể chọn màu nền/chữ',
        dialog_input_styled: 'Hộp nhập chữ có màu',
        dialog_choice_styled: 'Hộp chọn nút có màu',
        vibrate: 'Rung điện thoại',
        show_overlay: 'Hiện chữ nổi trên màn hình',
        update_overlay: 'Cập nhật chữ nổi',
        hide_overlay: 'Tắt chữ nổi',
        dialog_input: 'Hộp thoại nhập chữ (chờ user gõ)',
        dialog_choice: 'Hộp thoại chọn 1 trong nhiều (chờ user)',
        run_shell: 'Chạy lệnh hệ thống',
        read_file: 'Đọc tệp',
        write_file: 'Ghi đè tệp',
        append_file: 'Ghi thêm vào cuối tệp',
        delete_file: 'Xoá tệp',
        run_shell_json: 'Chạy lệnh + đọc kết quả JSON',
        record_start: 'Bắt đầu ghi thao tác chạm',
        record_stop: 'Dừng ghi thao tác',
        play_script: 'Chạy 1 tệp script khác',
        stop_script: 'Dừng script đang chạy',
        daemon_ping: 'Test daemon còn sống không',
        encrypt_script: 'Mã hoá script .a thành .aios',
        ax: 'Liệt kê nút/ô trên app đang mở (label/id/value/hint/x/y)',
        ax_find: 'Tìm 1 nút/ô → {text,label,id,value,x,y,…}',
        ax_exists: 'Có nút/ô khớp không (by=any|label|id|value)',
        ax_wait: 'Đợi nút/chữ hiện',
        ax_tap: 'Tìm nút (by=button) rồi ấn',
        ax_type: 'Tìm ô (by=field) rồi gõ',
        ax_inc: 'Tăng nút chỉnh',
        ax_dec: 'Giảm nút chỉnh',
        ax_adjust_to: 'Đặt nút chỉnh tới giá trị',
        web_fill: 'Safari — điền ô theo nhãn',
        web_click: 'Safari — bấm nút/link theo nhãn',
        web_long_press:
            'Safari — giữ theo số giây, hoặc dùng gone để giữ đến khi nút biến mất; timeout do người dùng đặt',
        web_wait: 'Safari — chờ chữ/nút',
        web_text: 'Safari — đọc nhãn',
        web_exists: 'Safari — có phần tử không',
        web_back: 'Quay lại trang',
        web_reload: 'Tải lại trang',
        web_url: 'URL hiện tại',
        web_title: 'Tiêu đề trang',
        web_js: 'Chạy JS trên trang',
        get_cookies: 'Cookie header Safari/WebKit (binarycookies, gồm HttpOnly)',
        random_int: 'Số nguyên ngẫu nhiên',
        random_float: 'Số thực ngẫu nhiên',
        md5: 'Tính mã băm MD5',
        sha256: 'Tính mã băm SHA256',
        base64_encode: 'Mã hoá Base64',
        base64_decode: 'Giải mã Base64',
        json_encode: 'Chuyển dữ liệu sang chuỗi JSON',
        json_decode: 'Chuyển chuỗi JSON sang dữ liệu',
        print: 'In ra màn hình log',
        file_exists: 'Tệp có tồn tại không',
        delete_backward: 'Xoá lùi 1 ký tự',
        vpn_status: '1=tắt 2=đang kết nối 3=bật (Shadowrocket ưu tiên, không thì proxy WiFi)',
        proxy_status: 'Chỉ proxy WiFi (set_proxy): 1=tắt 3=bật',
        now: 'Giờ hiện tại (giây)',
        time_ms: 'Giờ hiện tại (mili giây)',
        abs: 'Trị tuyệt đối',
        ceil: 'Làm tròn lên',
        floor: 'Làm tròn xuống',
        round: 'Làm tròn',
        sqrt: 'Căn bậc 2',
        pow: 'Mũ (a mũ b)',
        min: 'Số nhỏ nhất',
        max: 'Số lớn nhất',
        random: 'Số ngẫu nhiên 0 → 1',
        random_pick: 'Chọn ngẫu nhiên 1 phần tử',
        random_string: 'Sinh chuỗi ngẫu nhiên từ bộ ký tự (vd email/password)',
        str: 'Đổi số/bool/nil thành chuỗi',
        len: 'Độ dài chuỗi/list',
        upper: 'Đổi thành CHỮ HOA',
        lower: 'Đổi thành chữ thường',
        trim: 'Bỏ khoảng trắng đầu/cuối',
        split: 'Tách chuỗi',
        join: 'Nối list thành chuỗi',
        replace: 'Thay chuỗi',
        contains: 'Có chứa chuỗi này không',
        starts_with: 'Bắt đầu bằng chuỗi này',
        ends_with: 'Kết thúc bằng chuỗi này',
        push: 'Thêm vào cuối list',
        pop: 'Lấy ra phần tử cuối',
        keys: 'Lấy tất cả key',
        has: 'Có key này không',
    };
}

/** Create a fresh SDK description table for each catalog initialization. */
function createSdkEnglishDescriptions() {
    return {
        tap: 'Tap with ±0–1px jitter and 40–90ms hold',
        swipe: 'Swipe with slight curve and ease-in/out',
        long_press: 'Touch and hold at a point',
        tap_down: 'Press finger down (start)',
        tap_move: 'Move finger to new point',
        tap_up: 'Lift finger (release)',
        tap_sequence: 'Perform a sequence of touch events',
        tap_release: 'Release all active touches',
        show_tap_dots: 'Toggle tap indicator dots (debug overlay)',
        pinch: 'Pinch zoom in/out',
        rotate: 'Rotate two-finger gesture',
        home: 'Press the Home button',
        restart:
            'Restart userspace; unlock a no-passcode device, wait 60 seconds, then resume the script checkpoint',
        press_key: 'Press hardware key',
        type_keys: 'Press keys in sequence (delay_sec default 0.08)',
        insert_text: 'Type text at cursor (~70–130ms/char; optional delay_sec)',
        paste_text: 'Paste text',
        set_clipboard: 'Write text to clipboard',
        get_clipboard: 'Read text from clipboard',
        paste: 'Paste clipboard into active field',
        clear_clipboard: 'Clear clipboard',
        pick_color: 'Get color at a pixel',
        find_color: 'Find pixel by color (with tolerance)',
        get_colors: 'Get colors at multiple pixels',
        wait_for_color: 'Wait until a pixel becomes a given color',
        int_to_rgb: 'Convert integer to RGB tuple',
        rgb_to_int: 'Convert RGB tuple to integer',
        screenshot: 'Capture screen, return image path',
        image_match: 'Find a small image inside the screen',
        tap_image: 'Find image and tap its center',
        wait_for_image: 'Wait for an image to appear',
        swipe_until_image: 'Swipe until an image is visible',
        save_to_album: 'Save image to Photos album',
        clear_album: 'Delete all photos from Photos',
        ocr: 'OCR a region, return list of results',
        find_text: 'Find text (optional match=0.9)',
        tap_text: 'Find text and tap (match last arg)',
        wait_for_text: 'Wait for text (match last arg)',
        wait_and_tap_text: 'Wait then tap text (match last arg)',
        swipe_until_text: 'Swipe until text (match last arg)',
        ocr_languages: 'List supported OCR languages',
        get_screen_size: 'Get screen dimensions',
        get_screen_scale: 'Get screen scale factor',
        get_screen_orientation: 'Get screen orientation',
        get_device_info: 'Real device info',
        get_battery_info: 'Battery percentage and charging state',
        get_wifi_info: 'Current WiFi IP + SSID',
        get_front_app: 'Bundle ID of frontmost app',
        current_dir: 'Scripts folder',
        root_dir: 'NAuto root directory',
        hud_status: 'Floating HUD status',
        hud_show: 'Show floating HUD',
        hud_hide: 'Hide floating HUD',
        get_ip: 'Get device IP',
        get_sn: 'Get serial number',
        app_state: 'Check if the app is in front',
        kill_app: 'Close app and remove from App Switcher',
        switch_to_app: 'Bring app to foreground',
        open_url: 'Open a URL',
        open_settings: 'Open Settings app',
        change_app: 'Fake App (NChanger)',
        reset_app_data: 'Wipe app data + new identity (NAuto)',
        clear_app_data: 'Wipe app data only (NAuto)',
        backup_app: 'Backup app (NAuto)',
        restore_app: 'Restore app (NAuto)',
        clone_app: 'Clone app (NAuto)',
        spoof_reload: 'Apply spoof (NAuto)',
        safari_import_cookies: 'Copy app cookie jar into Safari',
        screen_size_invalidate: 'Invalidate cached screen size',
        run_shell: 'Run shell command with root privileges',
        run_shell_json: 'Run shell and parse JSON output',
        read_file: 'Read file',
        write_file: 'Overwrite file',
        append_file: 'Append to file',
        delete_file: 'Delete file',
        http_get: 'HTTP GET request',
        http_post: 'HTTP POST request',
        set_proxy: 'Set Wi‑Fi HTTP proxy (not Shadowrocket)',
        clear_proxy: 'Clear Wi‑Fi HTTP proxy',
        set_vcam: 'Enable virtual camera (needs zxvcam DEB)',
        clear_vcam: 'Disable virtual camera',
        vcam_zoom: 'Virtual camera zoom (1=fit)',
        vcam_zoom_in: 'Zoom in (+0.25)',
        vcam_zoom_out: 'Zoom out (−0.25)',
        vcam_pause: 'Pause/resume fake video (no arg = toggle)',
        vcam_resume: 'Resume fake video',
        vcam_restart: 'Restart virtual video from the beginning, keeping zoom and position',
        shadowrocket_on: 'Start Shadowrocket',
        shadowrocket_off: 'Stop Shadowrocket',
        clean_vpn_state: 'Reset VPN state',
        set_airplane_mode: 'Toggle Airplane Mode (True/False)',
        set_cellular_data: 'Toggle Cellular Data (True/False)',
        dialog_input: 'Show text input dialog — returns user string',
        dialog_choice: 'Show multi-choice dialog — returns selected name',
        show_overlay: 'Show floating HUD text on screen (top-right)',
        update_overlay: 'Update floating HUD text',
        hide_overlay: 'Hide floating HUD',
        sleep: 'Sleep for N seconds (supports float, e.g. 0.001)',
        usleep: 'Sleep precisely in microseconds (daemon-side)',
        random_sleep: 'Sleep random duration in range',
        show_toast: 'Show quick toast notification',
        show_toast_ex: 'Show toast with custom colors (position, bg_color, fg_color)',
        show_alert_box: 'Alert that auto-closes — optional bg/fg colors',
        dialog_input_styled: 'Input dialog with colors',
        dialog_choice_styled: 'Choice dialog with colored buttons',
        vibrate: 'Vibrate once',
        record_start: 'Start recording touch events',
        record_stop: 'Stop recording',
        play_script: 'Run another script file',
        stop_script: 'Stop running script',
        daemon_ping: "Ping daemon to check it's alive",
        encrypt_script: 'Encrypt a script',
        ax: 'List on-screen controls in the foreground app (label/id/value/hint/x/y)',
        ax_find: 'Find one control → {text,label,id,value,x,y,…}',
        ax_exists: 'Whether a control matches (by=any|label|id|value)',
        ax_wait: 'Wait until control appears',
        ax_tap: 'Find button then tap at center',
        ax_type: 'Type into a field in the app (not insert_text)',
        ax_inc: 'Increase adjustable control',
        ax_dec: 'Decrease adjustable control',
        ax_adjust_to: 'Set adjustable control to a value',
        web_fill: 'Safari — fill by label',
        web_click: 'Safari — click by label',
        web_long_press:
            'Safari — hold for N seconds, or use gone to hold until the button disappears; timeout is configurable',
        web_wait: 'Safari — wait for label',
        web_text: 'Safari — read label',
        web_exists: 'Safari — label exists',
        web_back: 'Go back',
        web_reload: 'Reload page',
        web_url: 'Current URL',
        web_title: 'Page title',
        web_js: 'Run raw JS',
        get_cookies: 'Safari/WebKit Cookie header (binarycookies, includes HttpOnly)',
        base64_encode: 'Base64 encode',
        base64_decode: 'Base64 decode',
        md5: 'Compute MD5 hash',
        sha256: 'Compute SHA256 hash',
        json_encode: 'Encode value to JSON string',
        json_decode: 'Decode JSON string to value',
        random_int: 'Random integer in range',
        random_float: 'Random float in range',
        print: 'Print to log/console',
        file_exists: 'Check if file exists',
        delete_backward: 'Delete character before cursor (backspace)',
        vpn_status: '1=off 2=connecting 3=on (Shadowrocket first, else WiFi HTTP proxy)',
        proxy_status: 'WiFi HTTP proxy only: 1=off 3=on',
        now: 'Current time (seconds since epoch)',
        time_ms: 'Current time in milliseconds',
        abs: 'Absolute value',
        ceil: 'Round up',
        floor: 'Round down',
        round: 'Round to nearest integer',
        sqrt: 'Square root',
        pow: 'Power (a^b)',
        min: 'Minimum value in list',
        max: 'Maximum value in list',
        random: 'Random float between 0..1',
        random_pick: 'Pick random element from list',
        random_string: 'Generate random string from charset (e.g. email/password)',
        str: 'Convert number/bool/nil to string',
        len: 'Length of string or list',
        upper: 'Convert to UPPERCASE',
        lower: 'Convert to lowercase',
        trim: 'Trim whitespace from both ends',
        split: 'Split string by separator',
        join: 'Join list elements with separator',
        replace: 'Replace substring',
        contains: 'Check if string contains substring',
        starts_with: 'Check if string starts with',
        ends_with: 'Check if string ends with',
        push: 'Push element to end of list',
        pop: 'Pop last element from list',
        keys: 'Get all dict keys',
        has: 'Check if dict has key',
    };
}

/** Create a fresh SDK description table for each catalog initialization. */
function createSdkChineseDescriptions() {
    return {
        tap: '点击一次（±0–1px，按住 40–90ms 随机）',
        swipe: '从 A 滑到 B（轻微弧线；时长按脚本）',
        long_press: '在坐标长按',
        home: '按下 Home 键',
        restart: '重启用户空间；解锁无密码设备，等待60秒后从检查点继续脚本',
        press_key: '硬件按键（home/power/音量）',
        insert_text: '向当前输入框打字（约 70–130ms/字；可用 delay_sec）',
        show_tap_dots: '显示点击绿点（便于查看）',
        paste_text: '立即粘贴文字',
        set_clipboard: '写入剪贴板',
        get_clipboard: '读取剪贴板',
        paste: '把剪贴板粘贴到当前输入框',
        clear_clipboard: '清空剪贴板',
        pinch: '双指捏合缩放',
        rotate: '双指绕中心旋转',
        tap_down: '手指按下',
        tap_move: '移动手指',
        tap_up: '抬起手指',
        tap_sequence: '多步触摸序列',
        tap_release: '松开所有按住的手指',
        type_keys: '连续按键（delay_sec 默认 0.08）',
        screenshot: '截屏并保存',
        image_match: '在屏幕上查找图片',
        tap_image: '找到图片后点击',
        wait_for_image: '等待图片出现',
        swipe_until_image: '滑动直到看见图片',
        save_to_album: '保存图片到相册',
        clear_album: '删除相册全部照片',
        ocr: '识别屏幕某区域文字',
        find_text: '查找文字（match=0.9 匹配度）',
        tap_text: '找到文字后点击',
        wait_for_text: '等待文字出现',
        wait_and_tap_text: '等到文字后点击',
        swipe_until_text: '滑动直到看见文字',
        ocr_languages: 'OCR 语言列表',
        pick_color: '取某点颜色',
        find_color: '按颜色找点',
        wait_for_color: '等待某点变成指定颜色',
        get_colors: '同时取多个点的颜色',
        int_to_rgb: '整数转 RGB',
        rgb_to_int: 'RGB 转整数',
        get_screen_size: '屏幕尺寸（像素）',
        get_screen_orientation: '屏幕方向（1=竖，3/4=横）',
        get_device_info: '真实设备信息（名称、iOS、型号）',
        get_battery_info: '电量与充电状态',
        get_wifi_info: '当前 WiFi 的 IP + SSID',
        get_front_app: '前台应用 Bundle ID',
        get_ip: '本机 IP',
        hud_status: '悬浮图标是否开启',
        hud_show: '显示悬浮图标（点按运行/停止脚本）',
        hud_hide: '隐藏悬浮图标',
        app_state: '应用是否在前台',
        kill_app: '关闭应用',
        switch_to_app: '打开并切到应用',
        open_url: '打开链接',
        open_settings: '打开设置',
        change_app: '伪装应用（NChanger）',
        reset_app_data: '清除应用数据并换身份（NAuto）',
        clear_app_data: '只清应用数据（NAuto）',
        backup_app: '备份应用（NAuto）',
        restore_app: '恢复应用（NAuto）',
        clone_app: '克隆应用（NAuto）',
        spoof_reload: '应用伪装（NAuto）',
        get_screen_scale: 'Retina 倍率（2x/3x）',
        get_sn: '设备序列号',
        current_dir: 'scripts 目录',
        root_dir: 'NAuto 根目录',
        safari_import_cookies: '把应用 Cookie 复制到 Safari',
        screen_size_invalidate: '清除屏幕尺寸缓存',
        sleep: '等待 N 秒',
        random_sleep: '随机等待（模拟真人）',
        usleep: '微秒级等待',
        http_get: 'HTTP GET',
        http_post: 'HTTP POST',
        set_proxy: '设置 Wi‑Fi HTTP 代理（不是 Shadowrocket）',
        clear_proxy: '清除 Wi‑Fi HTTP 代理',
        set_vcam: '开启虚拟摄像头（需 zxvcam DEB）',
        clear_vcam: '关闭虚拟摄像头',
        vcam_zoom: '虚拟摄像头缩放（1=铺满）',
        vcam_zoom_in: '放大',
        vcam_zoom_out: '缩小',
        vcam_pause: '暂停/继续虚拟视频',
        vcam_resume: '继续播放',
        vcam_restart: '从头重新播放虚拟视频，保留缩放和位置',
        shadowrocket_on: '打开 Shadowrocket VPN',
        shadowrocket_off: '关闭 Shadowrocket VPN',
        set_airplane_mode: '开关飞行模式',
        set_cellular_data: '开关蜂窝数据',
        clean_vpn_state: '清除 Shadowrocket 配置',
        show_toast: '显示短提示后自动关闭',
        show_toast_ex: '自定义颜色的提示',
        show_alert_box: '对话框，可自定义背景/文字色',
        dialog_input_styled: '带颜色的输入框',
        dialog_choice_styled: '带颜色按钮的选择框',
        vibrate: '振动',
        show_overlay: '显示屏幕浮字',
        update_overlay: '更新浮字',
        hide_overlay: '关闭浮字',
        dialog_input: '输入对话框（等用户输入）',
        dialog_choice: '选择对话框（等用户选择）',
        run_shell: '运行系统命令',
        read_file: '读文件',
        write_file: '覆盖写文件',
        append_file: '追加到文件末尾',
        delete_file: '删除文件',
        run_shell_json: '运行命令并解析 JSON',
        record_start: '开始录制触摸',
        record_stop: '停止录制触摸',
        play_script: '运行另一个脚本文件',
        stop_script: '停止当前脚本',
        daemon_ping: '检测守护进程是否存活',
        encrypt_script: '把 .a 加密成 .aios',
        ax: '列出前台应用控件（label/id/value/hint/x/y）',
        ax_find: '查找一个控件 → {text,label,id,value,x,y,…}',
        ax_exists: '是否有匹配控件（by=any|label|id|value）',
        ax_wait: '等待控件出现',
        ax_tap: '找到按钮后点击',
        ax_type: '找到输入框后输入',
        ax_inc: '增加调节控件',
        ax_dec: '减少调节控件',
        ax_adjust_to: '把调节控件设到指定值',
        web_fill: 'Safari — 按标签填入',
        web_click: 'Safari — 按标签点击',
        web_long_press: 'Safari — 长按N秒，或用gone保持到按钮消失；超时时间可设置',
        web_wait: 'Safari — 等待文字/按钮',
        web_text: 'Safari — 读取标签',
        web_exists: 'Safari — 元素是否存在',
        web_back: '返回上一页',
        web_reload: '刷新页面',
        web_url: '当前 URL',
        web_title: '页面标题',
        web_js: '在页面执行 JS',
        get_cookies: 'Safari/WebKit Cookie 头（含 HttpOnly）',
        random_int: '随机整数',
        random_float: '随机小数',
        md5: 'MD5',
        sha256: 'SHA256',
        base64_encode: 'Base64 编码',
        base64_decode: 'Base64 解码',
        json_encode: '转为 JSON 字符串',
        json_decode: '解析 JSON',
        print: '打印到日志',
        file_exists: '文件是否存在',
        delete_backward: '退格删除一字',
        vpn_status: '1=关 2=连接中 3=开（优先 Shadowrocket，否则 WiFi 代理）',
        proxy_status: '仅 WiFi HTTP 代理：1=关 3=开',
        now: '当前时间（秒）',
        time_ms: '当前时间（毫秒）',
        abs: '绝对值',
        ceil: '向上取整',
        floor: '向下取整',
        round: '四舍五入',
        sqrt: '平方根',
        pow: '乘方',
        min: '最小值',
        max: '最大值',
        random: '0～1 随机数',
        random_pick: '从列表随机取一项',
        random_string: '按字符集生成随机串（如邮箱/密码）',
        str: '把数字/布尔/空值转成字符串',
        len: '字符串或列表长度',
        upper: '转大写',
        lower: '转小写',
        trim: '去掉首尾空格',
        split: '按分隔符拆分',
        join: '用分隔符拼接列表',
        replace: '替换子串',
        contains: '是否包含子串',
        starts_with: '是否以某串开头',
        ends_with: '是否以某串结尾',
        push: '追加到列表末尾',
        pop: '取出列表最后一项',
        keys: '取全部 key',
        has: '是否有该 key',
    };
}

// -----------------------------------------------------------------------------
// SDK catalog loading
// Only publish method metadata after the existing methods request succeeds.
// -----------------------------------------------------------------------------

let sdkCatalogRequest = null;

function initSdkCatalog() {
    if (sdkCatalogRequest) {
        return sdkCatalogRequest;
    }
    const categories = createSdkCategories();
    const vietnameseDescriptions = createSdkVietnameseDescriptions();
    const englishDescriptions = createSdkEnglishDescriptions();
    const chineseDescriptions = createSdkChineseDescriptions();

    sdkCatalogRequest = fetch('/api/methods', { cache: 'no-store' })
        .then((r) => {
            if (!r.ok) {
                throw new Error('SDK catalog HTTP ' + r.status);
            }
            return r.json();
        })
        .then((data) => {
            if (!data || !Array.isArray(data.methods)) {
                return;
            }
            window._sdkMethods = data.methods;
            window._sdkVIDoc = vietnameseDescriptions;
            window._sdkENDoc = englishDescriptions;
            window._sdkZHDoc = chineseDescriptions;
            window._helperCATMAP = categories;
            if (typeof window._buildHelperAccordion === 'function') {
                window._buildHelperAccordion();
            }
        })
        .catch(() => {})
        .finally(() => {
            sdkCatalogRequest = null;
        });
    return sdkCatalogRequest;
}

// -----------------------------------------------------------------------------
// Console panel layout and resizing
// -----------------------------------------------------------------------------

function toggleConsolePanel(forceOpen) {
    const panel = document.getElementById('consolePanel');
    const icon = document.getElementById('consoleToggleIcon');
    if (!panel) {
        return;
    }

    const isCollapsed = panel.dataset.collapsed === 'true';
    const shouldOpen = forceOpen !== undefined ? forceOpen : isCollapsed;

    panel.style.transition = 'height 0.3s cubic-bezier(0.4, 0, 0.2, 1)';

    if (shouldOpen) {
        panel.style.height = panel.dataset.prevHeight || '180px';
        panel.dataset.collapsed = 'false';
        if (icon) {
            icon.style.transform = 'rotate(180deg)';
        }
    } else {
        const h = panel.offsetHeight;
        if (h > 40) {
            panel.dataset.prevHeight = h + 'px';
        }
        panel.style.height = '32px';
        panel.dataset.collapsed = 'true';
        if (icon) {
            icon.style.transform = 'rotate(0deg)';
        }
    }
    setTimeout(() => {
        if (state.editor) {
            state.editor.layout();
        }
    }, 350);
}
window.toggleConsolePanel = toggleConsolePanel;

(function initConsoleDrag() {
    const cPanel = document.getElementById('consolePanel');
    const cHeader = document.querySelector('#consolePanel .console-tab-header');
    if (!cPanel || !cHeader) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initConsoleDrag);
        }
        return;
    }

    let cStartY;
    let cStartH;
    let hasDragged;
    let dragOverlay;

    cHeader.addEventListener('mousedown', (e) => {
        if (e.target.closest('button')) {
            return;
        }

        cStartY = e.clientY;
        cStartH = cPanel.offsetHeight;
        hasDragged = false;

        cPanel.style.transition = 'none';

        dragOverlay = document.createElement('div');
        dragOverlay.style.cssText =
            'position:fixed;top:0;left:0;right:0;bottom:0;z-index:9999;cursor:row-resize;';
        document.body.appendChild(dragOverlay);

        document.addEventListener('mousemove', onDrag);
        document.addEventListener('mouseup', onDragEnd);
        e.preventDefault();
    });

    function onDrag(e) {
        const delta = Math.abs(e.clientY - cStartY);
        if (delta < 5) {
            return;
        }

        hasDragged = true;
        const newH = cStartH - (e.clientY - cStartY);
        if (newH >= 32 && newH <= 400) {
            cPanel.style.height = newH + 'px';
            cPanel.dataset.collapsed = newH <= 36 ? 'true' : 'false';
            const icon = document.getElementById('consoleToggleIcon');
            if (icon) {
                icon.style.transform = newH <= 36 ? 'rotate(0deg)' : 'rotate(180deg)';
            }
            if (state.editor) {
                state.editor.layout();
            }
        }
    }

    function onDragEnd() {
        document.removeEventListener('mousemove', onDrag);
        document.removeEventListener('mouseup', onDragEnd);

        if (dragOverlay && dragOverlay.parentNode) {
            dragOverlay.parentNode.removeChild(dragOverlay);
            dragOverlay = null;
        }

        cPanel.style.transition = 'height 0.3s cubic-bezier(0.4, 0, 0.2, 1)';

        if (!hasDragged) {
            toggleConsolePanel();
        }
    }
})();

// -----------------------------------------------------------------------------
// Device setup status and actions
// -----------------------------------------------------------------------------

async function checkSystemSetup() {
    try {
        const res = await fetch(`${API}/api/setup/check`);
        const data = await res.json();

        if (data.ok || data.success) {
            if (data.issues && data.issues.length > 0) {
                appendLog(`⚠️ Setup issues: ${data.issues.join(', ')}`, 'error');
            }
            if (data.pymobiledevice3 === false) {
                appendLog('📦 pymobiledevice3 not installed — using mock mode');
            }
            if (data.os === 'Windows' && !data.apple_drivers) {
                appendLog('⚠️ Install iTunes for iPhone USB support', 'error');
            }
        }
    } catch (e) {}
}

async function setupDDI(udid) {
    appendLog('📀 Setting up Developer Disk Image...');
    try {
        const res = await fetch(`${API}/api/setup/ddi/${udid}`);
        const data = await res.json();
        if (data.success) {
            appendLog(`✅ DDI ready for iOS ${data.ios_version}`, 'success');
        } else {
            appendLog(`❌ DDI setup failed: ${data.error || 'Unknown error'}`, 'error');
        }
    } catch (e) {
        appendLog(`❌ DDI setup error: ${e.message}`, 'error');
    }
}

async function setupWDA(udid) {
    appendLog('🔧 Setting up WebDriverAgent...');
    try {
        const res = await fetch(`${API}/api/setup/wda/${udid}`);
        const data = await res.json();
        if (data.success) {
            appendLog(
                `✅ WDA ready${data.session_id ? ' (session: ' + data.session_id + ')' : ''}`,
                'success',
            );
        } else {
            appendLog(`⚠️ WDA: ${data.error || 'Not available'}`, 'error');
            const guideRes = await fetch(`${API}/api/setup/wda/guide`);
            const guide = await guideRes.json();
            if (guide.methods) {
                appendLog('📖 WDA Installation Guide:');
                guide.methods.forEach((m) => {
                    appendLog(`  ${m.name}`);
                });
            }
        }
    } catch (e) {
        appendLog(`❌ WDA setup error: ${e.message}`, 'error');
    }
}

window.setupDDI = setupDDI;
window.setupWDA = setupWDA;

// -----------------------------------------------------------------------------
// Helper screenshot capture and coordinate picking
// -----------------------------------------------------------------------------

function _initHelperScreenCapture(ctx) {
    const { overlay, screenImg, screenCanvas, loadingEl } = ctx;

    ctx.captureScreen = async function captureScreen() {
        const hadPrev = screenImg && screenImg.naturalWidth > 0;
        if (!hadPrev && loadingEl) {
            loadingEl.style.display = 'block';
        }

        try {
            const url = `${API}/screenshot?format=png&t=${Date.now()}`;
            const png = new Image();
            png.crossOrigin = 'anonymous';
            await new Promise((resolve, reject) => {
                png.onload = resolve;
                png.onerror = reject;
                png.src = url;
            });
            screenImg.src = png.src;
            screenImg.style.display = 'block';
            if (loadingEl) {
                loadingEl.style.display = 'none';
            }
            screenCanvas.width = png.naturalWidth;
            screenCanvas.height = png.naturalHeight;
            ctx.canvasCtx = screenCanvas.getContext('2d', { willReadFrequently: true });
            ctx.canvasCtx.drawImage(png, 0, 0);
            state.screenSize = { w: png.naturalWidth, h: png.naturalHeight };
            appendLog(`📸 Screenshot: ${screenCanvas.width}x${screenCanvas.height}`, 'info');
        } catch (e) {
            if (!hadPrev && loadingEl) {
                loadingEl.textContent = '❌ Screenshot failed.';
            }
            appendLog('❌ Screenshot failed: ' + e.message, 'error');
        }
    };

    ctx.overlayToPixel = function overlayToPixel(e) {
        if (!screenImg || screenImg.style.display === 'none') {
            return null;
        }
        const imgRect = screenImg.getBoundingClientRect();
        const relX = e.clientX - imgRect.left;
        const relY = e.clientY - imgRect.top;
        if (relX < 0 || relX > imgRect.width || relY < 0 || relY > imgRect.height) {
            return null;
        }
        const pixelX = Math.round((relX / imgRect.width) * screenImg.naturalWidth);
        const pixelY = Math.round((relY / imgRect.height) * screenImg.naturalHeight);
        const px = Math.max(0, Math.min(pixelX, screenImg.naturalWidth - 1));
        const py = Math.max(0, Math.min(pixelY, screenImg.naturalHeight - 1));
        const pt = _pxToPt(px, py);
        return { x: px, y: py, ptX: pt.x, ptY: pt.y };
    };

    ctx.getColorAtPixel = function getColorAtPixel(x, y) {
        if (!ctx.canvasCtx) {
            return null;
        }
        const pixel = ctx.canvasCtx.getImageData(x, y, 1, 1).data;
        const r = pixel[0];
        const g = pixel[1];
        const b = pixel[2];
        const intColor = (r << 16) | (g << 8) | b;
        return {
            r,
            g,
            b,
            hex: `#${r.toString(16).padStart(2, '0').toUpperCase()}${g.toString(16).padStart(2, '0').toUpperCase()}${b.toString(16).padStart(2, '0').toUpperCase()}`,
            intHex: `0x${intColor.toString(16).padStart(6, '0').toUpperCase()}`,
            int: intColor,
        };
    };

    const _readoutEl = document.getElementById('helperReadout');
    const _scContainer = document.getElementById('helperScreenContainer');
    if (_readoutEl && _scContainer) {
        _scContainer.addEventListener('mouseenter', () => {
            _readoutEl.style.opacity = '1';
        });
        _scContainer.addEventListener('mouseleave', () => {
            _readoutEl.style.opacity = '0';
        });
    }

    overlay?.addEventListener('mousemove', (e) => {
        const pos = ctx.overlayToPixel(e);
        if (!pos) {
            return;
        }

        const ct = document.getElementById('helperCoordText');
        if (ct) {
            ct.textContent = `x: ${pos.ptX}  y: ${pos.ptY}  (pt)`;
        }

        const color = ctx.getColorAtPixel(pos.x, pos.y);
        if (color) {
            const sw = document.getElementById('helperColorSwatch');
            const it = document.getElementById('helperColorInt');
            if (sw) {
                sw.style.background = color.hex;
            }
            if (it) {
                it.textContent = color.int;
            }
        }

        if (state.helperMode === 'region' && state.regionStart && screenImg) {
            const regionRect = document.getElementById('helperRegionRect');
            if (regionRect) {
                const imgRect = screenImg.getBoundingClientRect();
                const container = document.getElementById('helperScreenContainer');
                const containerRect = container ? container.getBoundingClientRect() : imgRect;

                const scaleX = imgRect.width / screenImg.naturalWidth;
                const scaleY = imgRect.height / screenImg.naturalHeight;
                const offsetX = imgRect.left - containerRect.left;
                const offsetY = imgRect.top - containerRect.top;

                const startDispX = state.regionStart.x * scaleX + offsetX;
                const startDispY = state.regionStart.y * scaleY + offsetY;
                const curDispX = pos.x * scaleX + offsetX;
                const curDispY = pos.y * scaleY + offsetY;

                const rx = Math.min(startDispX, curDispX);
                const ry = Math.min(startDispY, curDispY);
                const rw = Math.abs(curDispX - startDispX);
                const rh = Math.abs(curDispY - startDispY);

                regionRect.style.left = rx + 'px';
                regionRect.style.top = ry + 'px';
                regionRect.style.width = rw + 'px';
                regionRect.style.height = rh + 'px';
                regionRect.style.display = 'block';
            }
        }
    });

    overlay?.addEventListener('click', async (e) => {
        const pos = ctx.overlayToPixel(e);
        if (!pos) {
            return;
        }
        e.preventDefault();
        e.stopPropagation();

        // Overlay/canvas = pixel; Alang fields = points
        const px = Math.round(pos.x);
        const py = Math.round(pos.y);
        const ptX = pos.ptX;
        const ptY = pos.ptY;

        let colorInt = 0;
        let hex = '#000000';
        const c = ctx.getColorAtPixel(pos.x, pos.y);
        if (c) {
            colorInt = c.int;
            hex = c.hex;
        }

        const sw = document.getElementById('helperColorSwatch');
        const it = document.getElementById('helperColorInt');
        if (sw) {
            sw.style.background = hex;
        }
        if (it) {
            it.textContent = colorInt;
        }

        const colorInfo = {
            x: ptX,
            y: ptY,
            hex: hex,
            int: colorInt,
        };

        if (state.helperMode === 'single') {
            state.pickedColors = [colorInfo];
        } else if (state.helperMode === 'multi') {
            state.pickedColors.push(colorInfo);
        } else if (state.helperMode === 'region' || state.helperMode === 'multiregion') {
            if (!state.regionStart) {
                state.regionStart = { x: px, y: py };
                let regionRect = document.getElementById('helperRegionRect');
                if (!regionRect) {
                    regionRect = document.createElement('div');
                    regionRect.id = 'helperRegionRect';
                    regionRect.style.cssText =
                        'position:absolute; border:2px dashed #6366f1; background:rgba(99,102,241,0.15); pointer-events:none; z-index:10; display:none; border-radius:3px;';
                    const container = document.getElementById('helperScreenContainer');
                    if (container) {
                        container.appendChild(regionRect);
                    }
                }
                appendLog(
                    _l(`Region start: (${ptX}, ${ptY}) pt`, `Bắt đầu vùng: (${ptX}, ${ptY}) pt`),
                );
                renderModalResults();
                return;
            } else {
                const rx = Math.min(state.regionStart.x, px);
                const ry = Math.min(state.regionStart.y, py);
                const rw = Math.abs(px - state.regionStart.x);
                const rh = Math.abs(py - state.regionStart.y);
                state.regionStart = null;
                const regionRect = document.getElementById('helperRegionRect');
                if (regionRect) {
                    regionRect.style.display = 'none';
                }
                // Giữ pixel trong region (image_crop); Alang fill dùng _pxRectToPt
                const entry = { region: [rx, ry, rw, rh], regionPt: _pxRectToPt(rx, ry, rw, rh) };
                if (state.helperMode === 'region') {
                    state.pickedColors = [entry];
                } else {
                    state.pickedColors.push(entry);
                }
                const pr = entry.regionPt;
                appendLog(
                    _l(
                        `Region #${state.pickedColors.length}: {${pr.join(', ')}} pt`,
                        `Vùng #${state.pickedColors.length}: {${pr.join(', ')}} pt`,
                    ),
                );
            }
        }

        appendLog(
            _l(
                `Color at (${ptX}, ${ptY}) pt: ${colorInt}`,
                `Màu tại (${ptX}, ${ptY}) pt: ${colorInt}`,
            ),
            'success',
        );
        renderModalResults();

        const tgt = state._helperPickTarget;
        if (tgt && state._helperOpenMethod) {
            const hideHint = () => {
                const h = document.getElementById('hm_act_hint');
                if (h) {
                    h.style.display = 'none';
                }
            };
            if (tgt.type === 'point') {
                tgt.input.value = String(ptX);
                tgt.fields[tgt.input.dataset.arg] = String(ptX);
                if (tgt.partner) {
                    tgt.partner.value = String(ptY);
                    tgt.fields[tgt.partner.dataset.arg] = String(ptY);
                }
                state._helperOpenMethod.updateCode?.();
                state._helperPickTarget = null;
                hideHint();
            } else if (tgt.type === 'color' && c) {
                if (tgt.rInput) {
                    tgt.rInput.value = String(c.r);
                    tgt.fields['red'] = String(c.r);
                }
                if (tgt.gInput) {
                    tgt.gInput.value = String(c.g);
                    tgt.fields['green'] = String(c.g);
                }
                if (tgt.bInput) {
                    tgt.bInput.value = String(c.b);
                    tgt.fields['blue'] = String(c.b);
                }
                if (tgt.xInput) {
                    tgt.xInput.value = String(ptX);
                    tgt.fields['x'] = String(ptX);
                }
                if (tgt.yInput) {
                    tgt.yInput.value = String(ptY);
                    tgt.fields['y'] = String(ptY);
                }
                state._helperOpenMethod.updateCode?.();
                state._helperPickTarget = null;
                hideHint();
            } else if (tgt.type === 'region') {
                const pc = state.pickedColors;
                const lastReg = pc[pc.length - 1];
                if (lastReg?.region) {
                    const [rx, ry, rw, rh] = lastReg.regionPt || _pxRectToPt(...lastReg.region);
                    tgt.input.value = `(${rx}, ${ry}, ${rw}, ${rh})`;
                    tgt.fields[tgt.input.dataset.arg] = tgt.input.value;
                    state._helperOpenMethod.updateCode?.();
                    state._helperPickTarget = null;
                    hideHint();
                }
            } else if (tgt.type === 'region_4inputs') {
                const pc = state.pickedColors;
                const lastReg = pc[pc.length - 1];
                if (lastReg?.region) {
                    const [rx, ry, rw, rh] = lastReg.regionPt || _pxRectToPt(...lastReg.region);
                    const fill = (inp, name, v) => {
                        if (!inp) {
                            return;
                        }
                        inp.value = String(v);
                        tgt.fields[name] = String(v);
                    };
                    fill(tgt.xInput, tgt.xInput?.dataset.arg, rx);
                    fill(tgt.yInput, tgt.yInput?.dataset.arg, ry);
                    fill(tgt.wInput, tgt.wInput?.dataset.arg, rw);
                    fill(tgt.hInput, tgt.hInput?.dataset.arg, rh);
                    state._helperOpenMethod.updateCode?.();
                    state._helperPickTarget = null;
                    hideHint();
                }
            } else if (tgt.type === 'image_crop') {
                const pc = state.pickedColors;
                const lastReg = pc[pc.length - 1];
                if (lastReg?.region && screenCanvas) {
                    const [rx, ry, rw, rh] = lastReg.region;
                    const buf = document.createElement('canvas');
                    buf.width = rw;
                    buf.height = rh;
                    buf.getContext('2d').drawImage(screenCanvas, rx, ry, rw, rh, 0, 0, rw, rh);
                    buf.toBlob(async (blob) => {
                        const name = 'auto_' + Date.now() + '.png';
                        try {
                            const res = await fetch(
                                `${API}/api/images?name=${encodeURIComponent(name)}`,
                                { method: 'POST', body: blob },
                            );
                            const ok = res.ok;
                            if (ok) {
                                tgt.input.value = `"${name}"`;
                                tgt.fields[tgt.input.dataset.arg] = tgt.input.value;
                                state._helperOpenMethod.updateCode?.();
                                appendLog(`💾 Saved crop: ${name}`, 'success');
                            } else {
                                appendLog('❌ Upload crop failed', 'error');
                            }
                        } catch (e) {
                            appendLog('❌ ' + e.message, 'error');
                        }
                        state._helperPickTarget = null;
                        hideHint();
                    }, 'image/png');
                }
            }
        }
    });
}

// -----------------------------------------------------------------------------
// Helper panel navigation
// -----------------------------------------------------------------------------

function _initHelperPanel(ctx) {
    const { modal } = ctx;
    const screenView = document.getElementById('screenView');
    const helperScreenSection = document.getElementById('helperScreenSection');
    const helperInner = modal.querySelector('.helper-inner');

    function closeHelper() {
        state.helperActive = false;
        if (helperScreenSection) {
            helperScreenSection.style.opacity = '0';
            helperScreenSection.style.transition = 'opacity 0.15s ease';
        }
        modal.classList.remove('helper-open');
        setTimeout(() => {
            if (helperScreenSection && helperInner) {
                helperScreenSection.classList.remove('overlaying-vnc');
                helperScreenSection.style.opacity = '';
                helperScreenSection.style.transition = '';
                helperInner.insertBefore(helperScreenSection, helperInner.firstChild);
            }
            if (state.editor) {
                state.editor.layout();
            }
        }, 380);
    }

    function openHelper() {
        initSdkCatalog();
        state.helperActive = true;
        if (helperScreenSection && screenView) {
            screenView.appendChild(helperScreenSection);
            helperScreenSection.classList.add('overlaying-vnc');
        }
        modal.classList.add('helper-open');
        ctx.captureScreen();
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
        if (typeof window._buildHelperAccordion === 'function') {
            window._buildHelperAccordion();
        }
        setTimeout(() => {
            if (state.editor) {
                state.editor.layout();
            }
        }, 380);
    }

    // Expose for mode switcher buttons (Điều khiển / Viết lệnh)
    window._openHelperPanel = openHelper;
    window._closeHelperPanel = closeHelper;

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modal.classList.contains('helper-open')) {
            closeHelper();
        }
    });

    document.querySelectorAll('.helper-tab-btn').forEach((btn) => {
        btn.addEventListener('click', () => {
            const tab = btn.dataset.htab;
            document
                .querySelectorAll('.helper-tab-btn')
                .forEach((b) => b.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.helper-tab-content').forEach((tc) => {
                tc.style.display = 'none';
            });
            const target = document.getElementById(
                'htab' + tab.charAt(0).toUpperCase() + tab.slice(1),
            );
            if (target) {
                target.style.display = 'flex';
            }
            if (tab === 'apps') {
                ctx.hmLoadApps();
            } else if (tab === 'color') {
                initSdkCatalog();
            }
            const overlay = document.getElementById('helperScreenOverlay');
            if (overlay) {
                overlay.style.cursor = 'default';
            }
        });
    });
}

// -----------------------------------------------------------------------------
// Helper argument parsing, hints and defaults
// -----------------------------------------------------------------------------

/** Parse only the first parenthesized argument list and retain the existing defaults. */
function _helperParseArgs(sig) {
    // Chỉ lấy trong (...) đầu — bỏ phần "→ {...}" / "— mô tả" (tránh ax() hiện ô rác)
    const signature = (sig || '()').trim();
    const openingParenIndex = signature.indexOf('(');
    const closingParenIndex =
        openingParenIndex >= 0 ? signature.indexOf(')', openingParenIndex) : -1;
    const parameterList =
        openingParenIndex >= 0 && closingParenIndex > openingParenIndex
            ? signature.substring(openingParenIndex + 1, closingParenIndex).trim()
            : '';
    if (!parameterList) {
        return [];
    }
    return parameterList
        .split(',')
        .map((argument) => argument.trim())
        .filter((argument) => argument && argument !== 'self')
        .map((argument) => {
            const equalsIndex = argument.indexOf('=');
            const colonIndex = argument.indexOf(':');
            let name = argument;
            let def = '';
            if (equalsIndex >= 0) {
                name = argument.substring(0, equalsIndex).trim();
                def = argument.substring(equalsIndex + 1).trim();
            } else if (colonIndex >= 0) {
                name = argument.substring(0, colonIndex).trim();
            }
            if (name.includes(':')) {
                name = name.split(':')[0].trim();
            }
            return { name, def };
        });
}

function _helperHintFor(argName) {
    const normalizedName = (argName || '').toLowerCase();
    const key = {
        x: 'hintX',
        y: 'hintY',
        x1: 'hintX',
        y1: 'hintY',
        x2: 'hintX',
        y2: 'hintY',
        cx: 'hintX',
        cy: 'hintY',
        duration: 'hintDuration',
        swipe_duration: 'hintDuration',
        seconds: 'hintSeconds',
        timeout: 'hintTimeout',
        interval: 'hintInterval',
        delay_sec: 'hintDelaySec',
        delay: 'hintDelaySec',
        type: 'hintType',
        text: 'hintText',
        content: 'hintText',
        title: 'hintTitle',
        message: 'hintMessage',
        url: 'hintUrl',
        path: 'hintPath',
        file_path: 'hintPath',
        bundle_id: 'hintBundle',
        bundle_identifier: 'hintBundle',
        bundle: 'hintBundle',
        label: 'hintLabel',
        value: 'hintValue',
        command: 'hintCommand',
        width: 'hintSize',
        height: 'hintSize',
        finger: 'hintFinger',
        finger_index: 'hintFinger',
        match: 'hintMatch',
        accept: 'hintMatch',
    }[normalizedName];
    return key ? _t(key, '') : '';
}

/** Keep method-specific defaults before the general argument fallback. */
function _helperDefaultFor(method, argName, def) {
    if (def) {
        return def;
    }
    const n = argName.toLowerCase();
    if (
        n === 'x' ||
        n === 'y' ||
        n === 'x1' ||
        n === 'y1' ||
        n === 'x2' ||
        n === 'y2' ||
        n === 'cx' ||
        n === 'cy'
    ) {
        return '0';
    }
    if (n === 'width' || n === 'height') {
        return '100';
    }
    if (n === 'duration' || n === 'swipe_duration') {
        return method.name === 'web_long_press' ? '10' : '0.3';
    }
    if (n === 'timeout') {
        return '10';
    }
    if (n === 'tolerance') {
        return '5';
    }
    if (n === 'scale' || n === 'scale_ratio') {
        return '0.8';
    }
    if (n === 'acceptable_value' || n === 'match' || n === 'accept') {
        return '0.9';
    }
    if (n === 'by' && method.name && method.name.indexOf('ax_') === 0) {
        return '"any"';
    }
    if (n === 'interval') {
        return '0.5';
    }
    if (n === 'delay_sec' || n === 'delay') {
        return '0.1';
    }
    if (n === 'max_swipes' || n === 'max_try_times' || n === 'max_tries') {
        return '10';
    }
    if (n === 'max_seconds') {
        return '2.0';
    }
    if (n === 'min_seconds') {
        return '0.5';
    }
    if (n === 'seconds') {
        return '1';
    }
    if (n === 'microseconds') {
        return '500000';
    }
    if (n === 'degrees') {
        return '90';
    }
    if (n === 'steps') {
        return '10';
    }
    if (n === 'distance') {
        return '200';
    }
    if (n === 'radius') {
        return '120';
    }
    if (n === 'finger_index' || n === 'finger') {
        return '1';
    }
    if (n === 'type') {
        return '1';
    }
    if (n === 'direction') {
        return '"up"';
    }
    if (n === 'recognition_level') {
        return '1';
    }
    if (n === 'contains' || n === 'word_match' || n === 'auto_correct') {
        return 'false';
    }
    if (n === 'languages') {
        return 'nil';
    }
    if (n === 'custom_words') {
        return '[]';
    }
    if (
        n === 'text' ||
        n === 'content' ||
        n === 'title' ||
        n === 'message' ||
        n === 'command' ||
        n === 'script_name'
    ) {
        if (method.name === 'safari_auto_click') {
            return '"Sign in"';
        }
        if (method.name && method.name.indexOf('ax_') === 0) {
            return '"Continue"';
        }
        return '""';
    }
    if (n === 'default') {
        return '""';
    }
    if (n === 'bundle_identifier' || n === 'bundle' || n === 'bundle_id') {
        return '"com.apple.mobilesafari"';
    }
    if (n === 'payload') {
        return '""';
    }
    if (n === 'url') {
        return '"https://example.com"';
    }
    if (
        n === 'path' ||
        n === 'script_path' ||
        n === 'script_absolute_path' ||
        n === 'file_path' ||
        n === 'in_path' ||
        n === 'out_path' ||
        n === 'save_path' ||
        n === 'image_path' ||
        n === 'debug_image_path'
    ) {
        return '"/tmp/file.txt"';
    }
    if (n === 'template_path') {
        return '"button"';
    }
    if (n === 'image_name') {
        return '"button"';
    }
    if (n === 'name' || n === 'version_dir') {
        return '""';
    }
    if (n === 'name_or_path' || n === 'name_or_index') {
        return '""';
    }
    if (n === 'region') {
        return '(0, 0, 750, 1334)';
    }
    if (n === 'region_or_path') {
        return 'nil';
    }
    if (n === 'min' || n === 'min_value') {
        return '0';
    }
    if (n === 'max' || n === 'max_value') {
        return '100';
    }
    if (n === 'red' || n === 'r') {
        return '255';
    }
    if (n === 'green' || n === 'g') {
        return '0';
    }
    if (n === 'blue' || n === 'b') {
        return '0';
    }
    if (n === 'host') {
        return '"127.0.0.1"';
    }
    if (n === 'port') {
        return '8080';
    }
    if (n === 'data') {
        return method.name === 'safari_auto_fill'
            ? '{"email": "user@example.com", "password": "Pass123"}'
            : '""';
    }
    if (n === 'value') {
        return method.name === 'web_fill' ? '"abc@gmail.com"' : '""';
    }
    if (n === 'label') {
        if (method.name === 'web_click') {
            return '"Next"';
        }
        if (method.name === 'web_long_press') {
            return '"Press and hold"';
        }
        if (
            method.name === 'web_wait' ||
            method.name === 'web_exists' ||
            method.name === 'web_text'
        ) {
            return '"Email"';
        }
        return '"Email"';
    }
    if (n === 'email') {
        return '"user@example.com"';
    }
    if (n === 'password') {
        return '"Pass123"';
    }
    if (n === 'username') {
        return '"myuser"';
    }
    if (n === 'selector') {
        return '"input[name=email]"';
    }
    if (n === 'form_selector') {
        return '"form"';
    }
    if (n === 'frame_selector') {
        return '"iframe"';
    }
    if (n === 'code') {
        return '"document.title"';
    }
    if (n === 'attr') {
        return '"href"';
    }
    if (n === 'pattern') {
        return '"dashboard"';
    }
    if (n === 'event_name') {
        return '"change"';
    }
    if (n === 'method') {
        return '"GET"';
    }
    if (n === 'body') {
        return 'nil';
    }
    if (n === 'days') {
        return '30';
    }
    if (n === 'key') {
        return '""';
    }
    if (n === 'params' || n === 'headers' || n === 'json') {
        return 'nil';
    }
    if (n === 'interval_seconds') {
        return '60';
    }
    if (n === 'fn') {
        return 'nil';
    }
    if (n === 'enable' || n === 'on') {
        return 'true';
    }
    if (n === 'options') {
        return '["A", "B", "C"]';
    }
    if (n === 'default') {
        return '""';
    }
    if (n === 'items') {
        return '{"Count": "0"}';
    }
    return '0';
}

function _helperIsCoordArg(name) {
    const n = name.toLowerCase();
    return ['x', 'y', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy'].includes(n);
}

function _helperIsRegionArg(name) {
    return name.toLowerCase() === 'region';
}

function _helperIsTextArg(name) {
    return name.toLowerCase() === 'text';
}

function _helperIsColorHexArg(name) {
    const n = name.toLowerCase();
    return n === 'bg' || n === 'fg' || n === 'color' || n === 'bg_color' || n === 'fg_color';
}

function _helperGenCodeFromForm(method, fields) {
    const args = _helperParseArgs(method.sig);
    const vals = args.map((a) => {
        const userVal = fields[a.name];
        const hasUserVal = userVal !== undefined && userVal !== '';
        if (a.def) {
            return hasUserVal && userVal !== a.def ? userVal : a.def;
        }
        return hasUserVal ? userVal : _helperDefaultFor(method, a.name, '');
    });
    let lastNonDefault = -1;
    for (let i = 0; i < args.length; i++) {
        const a = args[i];
        if (!a.def || vals[i] !== a.def) {
            lastNonDefault = i;
        }
    }
    const parts = vals.slice(0, lastNonDefault + 1);
    return `${method.name}(${parts.join(', ')})`;
}

// -----------------------------------------------------------------------------
// Helper method cards and form controls
// -----------------------------------------------------------------------------

function _renderHelperMethodCard(method, container, ctx) {
    const rawDesc = (method.doc || '').split('\n')[0].slice(0, 80);
    const desc = _sdkDoc(method.name, rawDesc);

    const card = document.createElement('div');
    card.dataset.method = method.name;
    card.style.cssText = 'display:flex; flex-direction:column;';

    const btn = document.createElement('button');
    btn.className = 'hm-act';
    btn.innerHTML = `<b>${method.name}</b><span style="color:#888;font-size:10px;"> ${_displaySig(method.sig)}</span>`;
    if (desc) {
        btn.title = desc;
    }
    card.appendChild(btn);

    const panel = document.createElement('div');
    panel.style.cssText = 'display:none;';
    card.appendChild(panel);

    btn.addEventListener('click', () => {
        const isOpen = panel.style.display === 'block';
        container.querySelectorAll('.hm-act.active').forEach((b) => b.classList.remove('active'));
        container
            .querySelectorAll('[data-method] > div')
            .forEach((p) => (p.style.display = 'none'));
        if (isOpen) {
            state._helperOpenMethod = null;
            state._helperPickTarget = null;
            if (ctx.hint) {
                ctx.hint.style.display = 'none';
            }
            return;
        }
        btn.classList.add('active');
        panel.style.display = 'block';
        state._helperOpenMethod = { method, panel, fields: {} };
        _renderHelperMethodForm(method, panel, ctx);
    });

    container.appendChild(card);
}

/** Escape generated Alang string content without changing empty-value coercion. */
function _hmEsc(value) {
    return String(value || '')
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"');
}

function _hmAlangStr(value) {
    return `"${_hmEsc(value)}"`;
}

function _hmPickBtn(text, title) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'hm-pick';
    button.textContent = text;
    if (title) {
        button.title = title;
    }
    return button;
}

function _hmTextRow(label, ph, onVal) {
    const row = document.createElement('div');
    row.className = 'hm-row';
    const lbl = document.createElement('label');
    lbl.textContent = label;
    const inp = document.createElement('input');
    inp.type = 'text';
    inp.placeholder = ph;
    inp.addEventListener('input', () => onVal(inp.value));
    row.appendChild(lbl);
    row.appendChild(inp);
    return row;
}

function _hmColorRow(label, defHex, onHex) {
    const row = document.createElement('div');
    row.className = 'hm-row';
    const lbl = document.createElement('label');
    lbl.textContent = label;
    const picker = document.createElement('input');
    picker.type = 'color';
    picker.className = 'hm-swatch';
    picker.value = defHex;
    const text = document.createElement('input');
    text.type = 'text';
    text.placeholder = '#RRGGBB';
    const clear = document.createElement('button');
    clear.type = 'button';
    clear.className = 'hm-clear';
    clear.textContent = '✕';
    clear.title = 'Xóa màu';
    picker.addEventListener('input', () => {
        text.value = picker.value.toUpperCase();
        onHex(text.value);
    });
    text.addEventListener('input', () => {
        onHex(text.value);
        if (/^#[0-9A-Fa-f]{6}$/.test(text.value)) {
            picker.value = text.value;
        }
    });
    clear.addEventListener('click', () => {
        text.value = '';
        onHex('');
    });
    row.appendChild(lbl);
    row.appendChild(picker);
    row.appendChild(text);
    row.appendChild(clear);
    return row;
}

function _hmColorBlock(title) {
    const box = document.createElement('div');
    box.className = 'hm-colors';
    const h = document.createElement('div');
    h.className = 'hm-colors-title';
    h.textContent = title;
    box.appendChild(h);
    return box;
}

function _hmCodeFooter(panel, ctx, updateCode) {
    const codeWrap = document.createElement('div');
    codeWrap.className = 'hm-code';
    const codeEl = document.createElement('code');
    ctx.codeEl = codeEl;
    codeWrap.appendChild(codeEl);
    panel.appendChild(codeWrap);
    const btnRow = document.createElement('div');
    btnRow.className = 'hm-row-btns';
    const copyBtn = document.createElement('button');
    copyBtn.className = 'hm-btn-copy';
    copyBtn.textContent = _t('hmBtnCopy');
    copyBtn.addEventListener('click', () => {
        updateCode();
        _hmDoCopy(ctx.codeEl.textContent);
    });
    const insertBtn = document.createElement('button');
    insertBtn.className = 'hm-btn-insert';
    insertBtn.textContent = _t('hmBtnInsert');
    insertBtn.addEventListener('click', () => {
        updateCode();
        insertEditorText(ctx.codeEl.textContent);
    });
    btnRow.appendChild(copyBtn);
    btnRow.appendChild(insertBtn);
    panel.appendChild(btnRow);
    updateCode();
}

// -----------------------------------------------------------------------------
// Specialized dialog and Safari forms
// -----------------------------------------------------------------------------

function _renderShowAlertBoxForm(panel, ctx) {
    const state = { title: '', content: '', duration: 5, bg: '', fg: '' };
    function updateCode() {
        const t = _hmEsc(state.title);
        const c = _hmEsc(state.content);
        let code = `show_alert_box("${t}", "${c}", ${state.duration}`;
        if (state.bg || state.fg) {
            code += `, "${_hmEsc(state.bg)}", "${_hmEsc(state.fg)}"`;
        }
        code += ')';
        if (ctx.codeEl) {
            ctx.codeEl.textContent = code;
        }
    }
    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form hm-run-frame';
    form.appendChild(
        _hmTextRow(_t('hmTitle') || 'Tiêu đề', 'hello', (v) => {
            state.title = v;
            updateCode();
        }),
    );
    form.appendChild(
        _hmTextRow(_t('hmContent'), 'hi', (v) => {
            state.content = v;
            updateCode();
        }),
    );
    const durRow = _hmTextRow(_t('hmDuration'), '5', (v) => {
        state.duration = parseFloat(v) || 5;
        updateCode();
    });
    durRow.querySelector('input').type = 'number';
    durRow.querySelector('input').value = '5';
    form.appendChild(durRow);
    const colors = _hmColorBlock(_t('hmColor'));
    colors.appendChild(
        _hmColorRow(_t('hmBg'), '#262626', (v) => {
            state.bg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmFg'), '#ffffff', (v) => {
            state.fg = v;
            updateCode();
        }),
    );
    form.appendChild(colors);
    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
}

function _renderDialogInputForm(panel, ctx) {
    const state = { title: '', message: '', defaultText: '', bg: '', fg: '', btnBg: '', btnFg: '' };
    function updateCode() {
        let code;
        if (state.bg || state.fg || state.btnBg || state.btnFg) {
            const obj = { title: state.title };
            if (state.message) {
                obj.message = state.message;
            }
            if (state.defaultText) {
                obj.default = state.defaultText;
            }
            if (state.bg) {
                obj.bg = state.bg;
            }
            if (state.fg) {
                obj.fg = state.fg;
            }
            if (state.btnBg) {
                obj.btn_bg = state.btnBg;
            }
            if (state.btnFg) {
                obj.btn_fg = state.btnFg;
            }
            code = `dialog_input_styled(${_hmAlangStr(JSON.stringify(obj))})`;
        } else {
            code = `dialog_input("${_hmEsc(state.title)}", "${_hmEsc(state.message)}", "${_hmEsc(state.defaultText)}")`;
        }
        if (ctx.codeEl) {
            ctx.codeEl.textContent = code;
        }
    }
    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form hm-run-frame';
    form.appendChild(
        _hmTextRow(_t('hmTitle') || 'Tiêu đề', 'Tiêu đề', (v) => {
            state.title = v;
            updateCode();
        }),
    );
    form.appendChild(
        _hmTextRow(_t('hmContent'), 'Mô tả', (v) => {
            state.message = v;
            updateCode();
        }),
    );
    form.appendChild(
        _hmTextRow(_t('hmDefault') || 'Mặc định', '', (v) => {
            state.defaultText = v;
            updateCode();
        }),
    );
    const colors = _hmColorBlock(_t('hmColor'));
    colors.appendChild(
        _hmColorRow(_t('hmBg'), '#262626', (v) => {
            state.bg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmFg'), '#ffffff', (v) => {
            state.fg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmBtnBg') || 'Nút nền', '#3498db', (v) => {
            state.btnBg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmBtnFg') || 'Nút chữ', '#ffffff', (v) => {
            state.btnFg = v;
            updateCode();
        }),
    );
    form.appendChild(colors);
    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
}

function _renderDialogChoiceForm(panel, ctx) {
    const state = { title: '', options: 'Có, Không', bg: '', fg: '', btnBg: '', btnFg: '' };
    function opts() {
        return state.options
            .split(/[,|\n]/)
            .map((s) => s.trim())
            .filter(Boolean);
    }
    function updateCode() {
        const list = opts();
        let code;
        if (state.bg || state.fg || state.btnBg || state.btnFg) {
            const buttons = list.map((label) => ({
                label,
                value: label,
                bg: state.btnBg || '#3498db',
                fg: state.btnFg || '#ffffff',
            }));
            const obj = { title: state.title, buttons };
            if (state.bg) {
                obj.bg = state.bg;
            }
            if (state.fg) {
                obj.fg = state.fg;
            }
            code = `dialog_choice_styled(${_hmAlangStr(JSON.stringify(obj))})`;
        } else {
            code = `dialog_choice("${_hmEsc(state.title)}", [${list.map((o) => `"${_hmEsc(o)}"`).join(', ')}])`;
        }
        if (ctx.codeEl) {
            ctx.codeEl.textContent = code;
        }
    }
    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form hm-run-frame';
    form.appendChild(
        _hmTextRow(_t('hmTitle') || 'Tiêu đề', 'Chọn', (v) => {
            state.title = v;
            updateCode();
        }),
    );
    form.appendChild(
        _hmTextRow(_t('hmButtons') || 'Nút', 'Có, Không', (v) => {
            state.options = v;
            updateCode();
        }),
    );
    const colors = _hmColorBlock(_t('hmColor'));
    colors.appendChild(
        _hmColorRow(_t('hmBg'), '#262626', (v) => {
            state.bg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmFg'), '#ffffff', (v) => {
            state.fg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmBtnBg') || 'Nút nền', '#3498db', (v) => {
            state.btnBg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmBtnFg') || 'Nút chữ', '#ffffff', (v) => {
            state.btnFg = v;
            updateCode();
        }),
    );
    form.appendChild(colors);
    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
}

function _renderShowToastForm(panel, ctx) {
    const state = { content: '', duration: 2, bg: '', fg: '' };
    function updateCode() {
        const c = _hmEsc(state.content);
        let code;
        if (state.bg || state.fg) {
            code = `show_toast_ex("${c}", ${state.duration}, 3, 0, "${_hmEsc(state.bg)}", "${_hmEsc(state.fg)}")`;
        } else {
            code = `show_toast("${c}", ${state.duration})`;
        }
        if (ctx.codeEl) {
            ctx.codeEl.textContent = code;
        }
    }
    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form hm-run-frame';
    form.appendChild(
        _hmTextRow(_t('hmContent'), _t('hmToastPh'), (v) => {
            state.content = v;
            updateCode();
        }),
    );
    const durRow = _hmTextRow(_t('hmDuration'), '2', (v) => {
        state.duration = parseFloat(v) || 2;
        updateCode();
    });
    durRow.querySelector('input').type = 'number';
    durRow.querySelector('input').value = '2';
    form.appendChild(durRow);
    const colors = _hmColorBlock(_t('hmColor'));
    colors.appendChild(
        _hmColorRow(_t('hmBg'), '#3498db', (v) => {
            state.bg = v;
            updateCode();
        }),
    );
    colors.appendChild(
        _hmColorRow(_t('hmFg'), '#ffffff', (v) => {
            state.fg = v;
            updateCode();
        }),
    );
    form.appendChild(colors);
    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
}

function _renderWebLongPressForm(panel, ctx) {
    const fields = { label: '"Press and hold"', duration_or_gone: '10', timeout: '20' };
    panel.innerHTML = '';
    const form = document.createElement('div');
    form.className = 'hm-form';

    const labelRow = document.createElement('div');
    labelRow.className = 'hm-row';
    const labelTitle = document.createElement('label');
    labelTitle.textContent = 'label';
    const labelInput = document.createElement('input');
    labelInput.type = 'text';
    labelInput.value = fields.label;
    labelInput.addEventListener('input', () => {
        fields.label = labelInput.value;
        updateCode();
    });
    const scanButton = _hmPickBtn(_t('hmBtnDom'), _t('hmBtnDomTip'));
    scanButton.addEventListener('click', () =>
        helperPickFromSafariDOM(labelInput, fields, 'label', updateCode, 'text'),
    );
    labelRow.appendChild(labelTitle);
    labelRow.appendChild(labelInput);
    labelRow.appendChild(scanButton);
    form.appendChild(labelRow);

    const modeRow = document.createElement('div');
    modeRow.className = 'hm-row';
    const modeTitle = document.createElement('label');
    modeTitle.textContent = _l('Hold mode', 'Chế độ giữ', '长按方式');
    const modeSelect = document.createElement('select');
    [
        ['seconds', _l('Hold for seconds', 'Giữ theo số giây', '按指定秒数')],
        ['gone', _l('Hold until button disappears', 'Giữ đến khi nút biến mất', '按到按钮消失')],
    ].forEach(([value, text]) => {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = text;
        modeSelect.appendChild(option);
    });
    modeRow.appendChild(modeTitle);
    modeRow.appendChild(modeSelect);
    form.appendChild(modeRow);

    const secondsRow = _hmTextRow(_l('Seconds', 'Số giây', '秒数'), '10', (value) => {
        fields.duration_or_gone = value || '10';
        updateCode();
    });
    const secondsInput = secondsRow.querySelector('input');
    secondsInput.type = 'number';
    secondsInput.min = '0.1';
    secondsInput.step = '0.1';
    secondsInput.value = '10';
    form.appendChild(secondsRow);

    const timeoutRow = _hmTextRow(_l('Max wait', 'Chờ tối đa', '最长等待'), '20', (value) => {
        fields.timeout = value || '20';
        updateCode();
    });
    const timeoutInput = timeoutRow.querySelector('input');
    timeoutInput.type = 'number';
    timeoutInput.min = '0.1';
    timeoutInput.step = '0.1';
    timeoutInput.value = '20';
    timeoutRow.style.display = 'none';
    form.appendChild(timeoutRow);

    modeSelect.addEventListener('change', () => {
        const gone = modeSelect.value === 'gone';
        secondsRow.style.display = gone ? 'none' : 'flex';
        timeoutRow.style.display = gone ? 'flex' : 'none';
        fields.duration_or_gone = gone ? '"gone"' : secondsInput.value || '10';
        updateCode();
    });

    function updateCode() {
        if (!ctx.codeEl) {
            return;
        }
        ctx.codeEl.textContent =
            modeSelect.value === 'gone'
                ? `web_long_press(${fields.label || '""'}, "gone", ${fields.timeout || '20'})`
                : `web_long_press(${fields.label || '""'}, ${fields.duration_or_gone || '10'})`;
    }

    panel.appendChild(form);
    _hmCodeFooter(panel, ctx, updateCode);
    if (state._helperOpenMethod) {
        state._helperOpenMethod.fields = fields;
        state._helperOpenMethod.updateCode = updateCode;
    }
}

// -----------------------------------------------------------------------------
// Generic helper method form
// -----------------------------------------------------------------------------

/** Keep specialized form dispatch before generic argument construction. */
function _renderHelperMethodForm(method, panel, ctx) {
    const hint = ctx.hint;
    const args = _helperParseArgs(method.sig);
    const argNames = args.map((a) => a.name);
    const fields = {};
    panel.innerHTML = '';

    if (method.name === 'show_toast' || method.name === 'show_toast_ex') {
        _renderShowToastForm(panel, ctx);
        return;
    }
    if (method.name === 'web_long_press') {
        _renderWebLongPressForm(panel, ctx);
        return;
    }
    if (method.name === 'show_alert_box') {
        _renderShowAlertBoxForm(panel, ctx);
        return;
    }
    if (method.name === 'dialog_input' || method.name === 'dialog_input_styled') {
        _renderDialogInputForm(panel, ctx);
        return;
    }
    if (method.name === 'dialog_choice' || method.name === 'dialog_choice_styled') {
        _renderDialogChoiceForm(panel, ctx);
        return;
    }

    let firstXInput = null;
    let firstXArgName = null;

    const hasColorArgs =
        argNames.includes('red') && argNames.includes('green') && argNames.includes('blue');
    const isImgFn = method.name && /image/i.test(method.name);
    const imageArgName =
        ['template_path', 'image', 'template'].find((n) => argNames.includes(n)) ||
        (isImgFn && argNames.includes('path') ? 'path' : null);
    const regionGroup =
        argNames.includes('x') &&
        argNames.includes('y') &&
        argNames.includes('w') &&
        argNames.includes('h')
            ? { x: 'x', y: 'y', w: 'w', h: 'h' }
            : argNames.includes('rx') &&
                argNames.includes('ry') &&
                argNames.includes('rw') &&
                argNames.includes('rh')
              ? { x: 'rx', y: 'ry', w: 'rw', h: 'rh' }
              : null;
    const inputByName = {};

    if (args.length) {
        const form = document.createElement('div');
        form.className = 'hm-form';
        const advanced = document.createElement('div');
        advanced.style.cssText =
            'display:none; margin-top:6px; padding-top:6px; border-top:1px dashed rgba(255,255,255,0.08);';
        let pendingCoordWrap = null;
        args.forEach((a) => {
            const row = document.createElement('div');
            row.className = 'hm-row';
            const lbl = document.createElement('label');
            lbl.textContent = a.name;
            const inp = document.createElement('input');
            inp.type = 'text';
            inp.value = a.def || _helperDefaultFor(method, a.name, '');
            const _hint = _helperHintFor(a.name);
            if (_hint) {
                inp.placeholder = _hint;
            }
            fields[a.name] = inp.value;
            inp.addEventListener('input', () => {
                fields[a.name] = inp.value;
                updateCode();
            });
            row.appendChild(lbl);
            row.appendChild(inp);
            if (_helperIsColorHexArg(a.name)) {
                const picker = document.createElement('input');
                picker.type = 'color';
                picker.value = '#6366f1';
                picker.className = 'hm-swatch';
                picker.title = 'Chọn màu (xoá ô text để bỏ về mặc định)';
                picker.addEventListener('input', () => {
                    const hex = picker.value.toUpperCase();
                    const quoted = '"' + hex + '"';
                    inp.value = quoted;
                    fields[a.name] = quoted;
                    updateCode();
                });
                row.appendChild(picker);
            }
            // Toast type color buttons
            if (method.name === 'show_toast' && a.name === 'type') {
                const colorRow = document.createElement('div');
                colorRow.style.cssText = 'display:flex; gap:4px; margin-top:4px; margin-left:94px;';
                const colors = [
                    { type: 1, color: '#e74c3c', label: 'Đỏ' },
                    { type: 2, color: '#f1c40f', label: 'Vàng' },
                    { type: 3, color: '#ffffff', label: 'Trắng' },
                    { type: 4, color: '#2ecc71', label: 'Xanh' },
                ];
                colors.forEach((c) => {
                    const btn = document.createElement('button');
                    btn.style.cssText = `width:28px; height:28px; background:${c.color}; border:2px solid ${c.type === 3 ? '#666' : c.color}; border-radius:6px; cursor:pointer;`;
                    btn.title = c.label + ' (type=' + c.type + ')';
                    btn.addEventListener('click', () => {
                        inp.value = c.type;
                        fields[a.name] = c.type;
                        updateCode();
                    });
                    colorRow.appendChild(btn);
                });
                row.appendChild(colorRow);
            }
            inp.dataset.arg = a.name;
            inputByName[a.name] = inp;

            if (pendingCoordWrap && a.name === pendingCoordWrap._expectY) {
                pendingCoordWrap._stack.appendChild(row);
                pendingCoordWrap = null;
                return;
            }

            const isXCoord = ['x', 'x1', 'x2', 'cx'].includes(a.name);
            const isRegionAnchor = regionGroup && regionGroup.x === a.name;
            if (isXCoord && _helperIsCoordArg(a.name) && !hasColorArgs && !isRegionAnchor) {
                const wrap = document.createElement('div');
                wrap.className = 'hm-coord';
                const stack = document.createElement('div');
                stack.className = 'hm-coord-stack';
                stack.appendChild(row);
                wrap.appendChild(stack);
                const pickBtn = _hmPickBtn('📍', _t('hmPickPointTooltip'));
                pickBtn.classList.add('hm-pick-icon');
                const startPick = () => {
                    state._helperPickTarget = { type: 'point', input: inp, fields, partner: null };
                    const partnerName = a.name.replace('x', 'y');
                    const partnerInput = inputByName[partnerName];
                    if (partnerInput) {
                        state._helperPickTarget.partner = partnerInput;
                    }
                    setHelperMode('single');
                    if (hint) {
                        hint.style.display = 'block';
                        hint.textContent = _t('hmPickPoint');
                    }
                };
                pickBtn.addEventListener('click', startPick);
                wrap.appendChild(pickBtn);
                wrap._stack = stack;
                wrap._expectY = a.name.replace('x', 'y');
                if ((a.name === 'x' || a.name === 'x1' || a.name === 'cx') && !firstXInput) {
                    firstXInput = inp;
                    firstXArgName = a.name;
                    wrap._autoStartPick = startPick;
                }
                pendingCoordWrap = wrap;
                (a.def !== '' && a.def != null ? advanced : form).appendChild(wrap);
                return;
            }

            if (_helperIsRegionArg(a.name)) {
                const pickBtn = _hmPickBtn(_t('hmBtnPickRegion'), _t('hmPickRegionTooltip'));
                const startRegionPick = () => {
                    state._helperPickTarget = { type: 'region', input: inp, fields };
                    setHelperMode('region');
                    state.regionStart = null;
                    if (hint) {
                        hint.style.display = 'block';
                        hint.textContent = _t('hmPickRegion');
                    }
                };
                pickBtn.addEventListener('click', startRegionPick);
                row.appendChild(pickBtn);
                if (!firstXInput) {
                    row._autoStartPick = startRegionPick;
                }
            }
            if (_helperIsTextArg(a.name)) {
                const KB_FNS = new Set(['type_keys', 'insert_text', 'paste_text', 'set_clipboard']);
                const isKeyboard = KB_FNS.has(method.name);
                const isSafariFn =
                    method.name &&
                    (method.name.indexOf('safari_') === 0 || method.name.indexOf('web_') === 0);
                const isAxFn = method.name && method.name.indexOf('ax_') === 0;
                const pickBtn = _hmPickBtn('', '');
                if (isKeyboard) {
                    pickBtn.textContent = _t('hmBtnRandom');
                    pickBtn.title = _t('hmBtnRandomTip');
                } else if (isSafariFn) {
                    pickBtn.textContent = _t('hmBtnDom');
                    pickBtn.title = _t('hmBtnDomTip');
                } else if (isAxFn) {
                    pickBtn.textContent = _t('hmBtnAx');
                    pickBtn.title = _t('hmBtnAxTip');
                } else {
                    pickBtn.textContent = _t('hmBtnOcr');
                    pickBtn.title = _t('hmBtnOcrTip');
                }
                pickBtn.addEventListener('click', () => {
                    if (isKeyboard) {
                        helperPickRandomList(inp, fields, a.name, updateCode);
                    } else if (isSafariFn) {
                        helperPickFromSafariDOM(inp, fields, a.name, updateCode, 'text');
                    } else if (isAxFn) {
                        helperPickFromAX(inp, fields, a.name, updateCode, inputByName.by);
                    } else {
                        helperPickTextFromOcr(inp, fields, a.name, updateCode);
                    }
                });
                row.appendChild(pickBtn);
            }
            if (a.name === 'match' && method.name && method.name.indexOf('ax_') === 0) {
                // catalog cũ còn tên match — vẫn gắn Quét UI
                const pickBtn = _hmPickBtn(_t('hmBtnAx'), _t('hmBtnAxTip'));
                pickBtn.addEventListener('click', () =>
                    helperPickFromAX(inp, fields, a.name, updateCode, inputByName.by),
                );
                row.appendChild(pickBtn);
            }
            if (a.name === 'selector' || a.name === 'form_selector') {
                const pickBtn = _hmPickBtn(_t('hmBtnDom'), _t('hmBtnDomTip'));
                pickBtn.addEventListener('click', () =>
                    helperPickFromSafariDOM(inp, fields, a.name, updateCode, 'sel'),
                );
                row.appendChild(pickBtn);
            }
            if (a.name === 'value' && method.name === 'web_fill') {
                const pickBtn = _hmPickBtn(_t('hmBtnRandom'), _t('hmBtnRandomTip'));
                pickBtn.addEventListener('click', () =>
                    helperPickRandomList(inp, fields, a.name, updateCode),
                );
                row.appendChild(pickBtn);
            }
            if (a.name === 'label' && method.name && method.name.indexOf('web_') === 0) {
                const pickBtn = _hmPickBtn(_t('hmBtnDom'), _t('hmBtnDomTip'));
                pickBtn.addEventListener('click', () =>
                    helperPickFromSafariDOM(inp, fields, a.name, updateCode, 'text'),
                );
                row.appendChild(pickBtn);
            }
            if (imageArgName && a.name === imageArgName) {
                const cropBtn = _hmPickBtn(_t('hmBtnCrop'), _t('hmBtnCropTip'));
                const startImageCrop = () => {
                    state._helperPickTarget = { type: 'image_crop', input: inp, fields };
                    setHelperMode('region');
                    state.regionStart = null;
                    if (hint) {
                        hint.style.display = 'block';
                        hint.textContent = '✂️ Kéo chọn vùng ảnh — sẽ lưu PNG vào thư mục images';
                    }
                };
                cropBtn.addEventListener('click', startImageCrop);
                row.appendChild(cropBtn);
            }
            if (regionGroup && a.name === regionGroup.x) {
                const regBtn = _hmPickBtn(_t('hmBtnPickRegion'), _t('hmPickRegionTooltip'));
                const startRegionPick4 = () => {
                    state._helperPickTarget = {
                        type: 'region_4inputs',
                        fields,
                        xInput: inputByName[regionGroup.x],
                        yInput: inputByName[regionGroup.y],
                        wInput: inputByName[regionGroup.w],
                        hInput: inputByName[regionGroup.h],
                    };
                    setHelperMode('region');
                    state.regionStart = null;
                    if (hint) {
                        hint.style.display = 'block';
                        hint.textContent = '📍 Kéo chọn vùng trên màn hình';
                    }
                };
                regBtn.addEventListener('click', startRegionPick4);
                row.appendChild(regBtn);
            }
            const forceMain = regionGroup && a.name === regionGroup.x;
            (!forceMain && a.def !== '' && a.def != null ? advanced : form).appendChild(row);
        });

        let priorityAuto = null;

        if (hasColorArgs) {
            const startColorPick = () => {
                state._helperPickTarget = {
                    type: 'color',
                    fields,
                    rInput: inputByName['red'],
                    gInput: inputByName['green'],
                    bInput: inputByName['blue'],
                    xInput: inputByName['x'],
                    yInput: inputByName['y'],
                };
                setHelperMode('single');
                if (hint) {
                    hint.style.display = 'block';
                    hint.textContent = '🎨 Click 1 điểm trên ảnh để lấy màu';
                }
            };
            const colorRow = document.createElement('div');
            const colorBtn = _hmPickBtn(_t('hmBtnPickColor'));
            colorBtn.classList.add('hm-pick-block');
            colorBtn.addEventListener('click', startColorPick);
            colorRow.appendChild(colorBtn);
            form.appendChild(colorRow);
            if (!priorityAuto) {
                priorityAuto = startColorPick;
            }
        }

        panel.appendChild(form);

        if (advanced.children.length) {
            const toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.className = 'hm-adv-toggle';
            toggle.innerHTML = `<span class="hm-adv-arrow">▸</span> Tuỳ chọn nâng cao (${advanced.children.length})`;
            toggle.addEventListener('click', () => {
                const open = advanced.style.display !== 'none';
                advanced.style.display = open ? 'none' : 'block';
                toggle.querySelector('.hm-adv-arrow').textContent = open ? '▸' : '▾';
            });
            panel.appendChild(toggle);
            panel.appendChild(advanced);
        }

        const autoTrigger =
            priorityAuto ||
            (Array.from(form.children).find((r) => r._autoStartPick) || {})._autoStartPick;
        if (autoTrigger) {
            setTimeout(autoTrigger, 50);
        }
    }

    function updateCode() {
        if (ctx.codeEl) {
            ctx.codeEl.textContent = _helperGenCodeFromForm(method, fields);
        }
    }
    _hmCodeFooter(panel, ctx, updateCode);

    if (state._helperOpenMethod) {
        state._helperOpenMethod.fields = fields;
        state._helperOpenMethod.updateCode = updateCode;
    }
}

// -----------------------------------------------------------------------------
// Helper catalog and app selection
// -----------------------------------------------------------------------------

function _initHelperAccordion(ctx) {
    function buildHelperAccordion() {
        const container = document.getElementById('hm_actions');
        if (!container) {
            return;
        }
        const methods = window._sdkMethods || [];
        if (!methods.length) {
            container.innerHTML = `<div style="color:#888;text-align:center;padding:20px;">${_t('hmLoadingSdk')}</div>`;
            setTimeout(buildHelperAccordion, 500);
            return;
        }
        const CAT_LABELS = {
            Touch: _t('catTouch'),
            Keyboard: _t('catKeyboard'),
            Clipboard: _t('catClipboard'),
            Color: _t('catColor'),
            Image: _t('catImage'),
            VCam: _t('catVCam'),
            OCR: _t('catOCR'),
            System: _t('catSystem'),
            App: _t('catApp'),
            File: _t('catFile'),
            Network: _t('catNetwork'),
            Sleep: _t('catSleep'),
            UI: _t('catUI'),
            Recording: _t('catRecording'),
            Script: _t('catScript'),
            Safari: _t('catSafari'),
            Lang: _t('catLang'),
        };
        const cats = window._helperCATS || [];
        container.innerHTML = '';
        const methodMap = {};
        methods.forEach((m) => (methodMap[m.name] = m));

        Object.entries(window._helperCATMAP || {}).forEach(([key, def]) => {
            const cat = document.createElement('div');
            cat.className = 'hm-cat';
            const header = document.createElement('div');
            header.className = 'hm-cat-h';
            const list = (def.names || []).filter((n) => methodMap[n]);
            if (!list.length) {
                return;
            }
            header.innerHTML = `<span>${CAT_LABELS[key] || key} <span style="color:#666;font-weight:normal;">(${list.length})</span></span><span class="chev">▸</span>`;
            header.addEventListener('click', () => cat.classList.toggle('open'));
            cat.appendChild(header);
            const listDiv = document.createElement('div');
            listDiv.className = 'hm-cat-list';
            list.forEach((n) => _renderHelperMethodCard(methodMap[n], listDiv, ctx));
            cat.appendChild(listDiv);
            container.appendChild(cat);
        });

        const search = document.getElementById('hm_search');
        if (search) {
            search.placeholder = _t('hmSearchPlaceholder');
            search.addEventListener('input', () => {
                const q = search.value.toLowerCase().trim();
                container.querySelectorAll('.hm-cat').forEach((cat) => {
                    let any = false;
                    cat.querySelectorAll('[data-method]').forEach((card) => {
                        const match = !q || card.dataset.method.toLowerCase().includes(q);
                        card.style.display = match ? '' : 'none';
                        if (match) {
                            any = true;
                        }
                    });
                    cat.style.display = any ? '' : 'none';
                    if (q && any) {
                        cat.classList.add('open');
                    }
                });
            });
        }
    }

    window._buildHelperAccordion = buildHelperAccordion;
}

function _initHelperAppsTab(ctx) {
    async function hmLoadApps() {
        const list = document.getElementById('hmAppList');
        if (!list) {
            return;
        }
        list.innerHTML =
            '<div style="color:#555; text-align:center; padding:20px 0; font-size:11px;">Loading...</div>';
        try {
            const [fgRes, appsRes] = await Promise.all([
                fetch(`${API}/foreground_app`)
                    .then((r) => r.json())
                    .catch(() => ({})),
                fetch(`${API}/apps`).then((r) => r.json()),
            ]);
            const fgBid = fgRes.bundleId || fgRes.bundle_id || '';
            const apps = appsRes.apps || [];
            let html = '';
            apps.forEach((app) => {
                const isFg = app.bundleId === fgBid;
                const bg = isFg ? 'rgba(99,102,241,0.2)' : 'rgba(255,255,255,0.04)';
                const iconUrl = `${API}/app_icon?bid=${encodeURIComponent(app.bundleId)}`;
                html += `<div class="hm-app-item" data-bid="${app.bundleId}" data-name="${(app.name || '').toLowerCase()}" style="display:flex; align-items:center; gap:8px; padding:8px 10px; border-radius:6px; cursor:pointer; background:${bg}; transition:background 0.15s; margin-bottom:2px;" onclick="hmCopyBid('${app.bundleId}')" onmouseenter="this.style.background='rgba(129,140,248,0.16)'" onmouseleave="this.style.background='${bg}'">
          <img src="${iconUrl}" style="width:32px; height:32px; border-radius:7px; flex-shrink:0; background:rgba(255,255,255,0.06);" onerror="this.style.visibility='hidden'">
          <div style="min-width:0; flex:1;">
            <div style="font-size:13px; color:var(--text-primary); font-weight:${isFg ? '700' : '500'}; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; line-height:1.3;">${isFg ? '▶ ' : ''}${app.name || app.bundleId}</div>
            <div style="font-size:11px; color:var(--text-secondary); font-family:var(--font-mono); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin-top:2px;">${app.bundleId}</div>
          </div>
        </div>`;
            });
            list.innerHTML = html;
        } catch (e) {
            list.innerHTML = `<div style="color:var(--red); text-align:center; padding:16px; font-size:13px;">Failed</div>`;
        }
    }

    ctx.hmLoadApps = hmLoadApps;

    window.hmCopyBid = copyBundleId;

    document.getElementById('hmAppSearch')?.addEventListener('input', (e) => {
        const q = e.target.value.toLowerCase();
        document.querySelectorAll('.hm-app-item').forEach((el) => {
            const name = el.dataset.name || '';
            const bid = el.dataset.bid || '';
            el.style.display = name.includes(q) || bid.includes(q) ? 'block' : 'none';
        });
    });

    document.getElementById('hmRefreshApps')?.addEventListener('click', () => hmLoadApps());
}

function initHelper() {
    const modal = document.getElementById('helperModal');
    if (!modal) {
        return;
    }

    const ctx = {
        modal,
        overlay: document.getElementById('helperScreenOverlay'),
        screenImg: document.getElementById('helperScreenImg'),
        screenCanvas: document.getElementById('helperScreenCanvas'),
        loadingEl: document.getElementById('helperScreenLoading'),
        canvasCtx: null,
        hint: null,
    };

    _initHelperScreenCapture(ctx);
    _initHelperAppsTab(ctx);
    _initHelperPanel(ctx);

    setHelperMode('region');
    state.helperAction = null;
    ctx.hint = document.getElementById('hm_act_hint');
    state._helperOpenMethod = null;
    state._helperPickTarget = null;

    _initHelperAccordion(ctx);
}

function setHelperMode(mode) {
    state.helperMode = mode;
}

// -----------------------------------------------------------------------------
// Picked colors and result presentation
// -----------------------------------------------------------------------------

function renderModalResults() {
    const container = document.getElementById('helperModalResults');
    if (!container) {
        return;
    }

    if (state.pickedColors.length === 0) {
        container.innerHTML =
            '<div style="color:#555; text-align:center; padding:16px 0;">Click on screen to pick colors</div>';
        return;
    }

    let html = '';
    state.pickedColors.forEach((c, i) => {
        if (c.region) {
            html += `<div class="hm-result-item">
        <span style="color:#818cf8;">#${i + 1}</span>
        <span>⬜</span>
        <span class="hm-result-coords">region {${c.region.join(', ')}}</span>
      </div>`;
        } else {
            html += `<div class="hm-result-item">
        <span style="color:#666;">#${i + 1}</span>
        <span class="hm-result-swatch" style="background:${c.hex}"></span>
        <span class="hm-result-coords">(${c.x}, ${c.y})</span>
        <span class="hm-result-int" style="color:#f0a030; cursor:pointer;" title="${_t('hmBtnCopy')}" onclick="_hmDoCopy('${c.int}')">${c.int}</span>
      </div>`;
        }
    });
    container.innerHTML = html;
}

async function helperPickColor(x, y, event) {
    if (!state.currentDevice) {
        return;
    }

    try {
        // Caller có thể gửi pixel — /color + handleLocalColorPicker kỳ vọng points
        const pt = _pxToPt(x, y);
        const pixX = pt.x;
        const pixY = pt.y;

        const sampleSize = 1;
        const half = 0;

        let sumR = 0;
        let sumG = 0;
        let sumB = 0;
        let count = 0;
        if (sampleSize <= 1) {
            const res = await fetch(`${API}/color?x=${pixX}&y=${pixY}`);
            const data = await res.json();
            if (!data.success && data.ok !== true) {
                appendLog(`⚠️ Color pick failed`, 'error');
                return;
            }
            sumR = data.r;
            sumG = data.g;
            sumB = data.b;
            count = 1;
        } else {
            const step = sampleSize >= 9 ? 2 : 1;
            const promises = [];
            for (let dy = -half; dy <= half; dy += step) {
                for (let dx = -half; dx <= half; dx += step) {
                    const sx = Math.max(0, pixX + dx);
                    const sy = Math.max(0, pixY + dy);
                    promises.push(
                        fetch(`${API}/color?x=${sx}&y=${sy}`)
                            .then((r) => r.json())
                            .catch(() => null),
                    );
                }
            }
            const results = await Promise.all(promises);
            for (const d of results) {
                if (d && (d.success || d.ok)) {
                    sumR += d.r;
                    sumG += d.g;
                    sumB += d.b;
                    count++;
                }
            }
            if (count === 0) {
                appendLog(`⚠️ Color pick failed (no samples)`, 'error');
                return;
            }
        }

        const avgR = Math.round(sumR / count);
        const avgG = Math.round(sumG / count);
        const avgB = Math.round(sumB / count);
        const hex = `#${[avgR, avgG, avgB].map((v) => v.toString(16).padStart(2, '0')).join('')}`;
        const intColor = (avgR << 16) | (avgG << 8) | avgB;
        const intHex = `0x${intColor.toString(16).padStart(6, '0').toUpperCase()}`;

        const colorInfo = {
            x: pixX,
            y: pixY,
            r: avgR,
            g: avgG,
            b: avgB,
            hex,
            int: intColor,
            intHex,
            sampleSize,
            clientX: event.clientX,
            clientY: event.clientY,
        };

        if (state.helperMode === 'single') {
            state.pickedColors = [colorInfo];
        } else if (state.helperMode === 'multi') {
            state.pickedColors.push(colorInfo);
        } else if (state.helperMode === 'region') {
            if (!state.regionStart) {
                state.regionStart = { x: pixX, y: pixY };
                appendLog(
                    _l(
                        `⬜ Region start: (${pixX}, ${pixY})`,
                        `⬜ Bắt đầu vùng: (${pixX}, ${pixY})`,
                    ),
                );
                return;
            } else {
                const rx = Math.min(state.regionStart.x, pixX);
                const ry = Math.min(state.regionStart.y, pixY);
                const rw = Math.abs(pixX - state.regionStart.x);
                const rh = Math.abs(pixY - state.regionStart.y);
                state.pickedColors = [{ region: [rx, ry, rw, rh] }];
                state.regionStart = null;
                appendLog(
                    _l(
                        `⬜ Region: {${rx}, ${ry}, ${rw}, ${rh}}`,
                        `⬜ Vùng: {${rx}, ${ry}, ${rw}, ${rh}}`,
                    ),
                );
            }
        }

        addPickMarker(event, hex);

        ['', 'zoom'].forEach((prefix) => {
            const sid = prefix ? 'zoomColorSwatch' : 'liveColorSwatch';
            const pid = prefix ? 'zoomPixelColor' : 'pixelColor';
            const swatch = document.getElementById(sid);
            if (swatch) {
                swatch.style.display = 'inline-block';
                swatch.style.backgroundColor = hex;
            }
            const pc = document.getElementById(pid);
            if (pc) {
                pc.textContent = intHex;
                pc.style.color = hex;
            }
        });

        appendLog(
            `🎨 (${pixX},${pixY}) avg ${sampleSize}×${sampleSize}: ${intHex} ${hex} RGB(${avgR},${avgG},${avgB})`,
        );

        renderPickedColors();
    } catch (err) {
        appendLog(`⚠️ Color pick error: ${err.message}`, 'error');
    }
}

function addPickMarker(event, color) {
    const screenView = document.getElementById('screenView');
    const viewRect = screenView.getBoundingClientRect();

    if (state.helperMode === 'single') {
        screenView.querySelectorAll('.pick-marker').forEach((m) => m.remove());
    }

    const marker = document.createElement('div');
    marker.className = 'pick-marker';
    marker.style.left = event.clientX - viewRect.left + 'px';
    marker.style.top = event.clientY - viewRect.top + 'px';
    marker.style.borderColor = color;
    marker.style.boxShadow = `0 0 6px ${color}`;

    if (state.helperMode === 'multi') {
        marker.textContent = state.pickedColors.length;
        marker.style.width = '16px';
        marker.style.height = '16px';
        marker.style.fontSize = '9px';
        marker.style.display = 'flex';
        marker.style.alignItems = 'center';
        marker.style.justifyContent = 'center';
        marker.style.color = '#fff';
        marker.style.fontWeight = 'bold';
        marker.style.textShadow = '0 0 3px #000';
    }

    screenView.appendChild(marker);
}

function renderPickedColors() {
    const containers = [
        document.getElementById('helperResults'),
        document.getElementById('zoomHelperResults'),
    ];

    const emptyHtml = '<div class="helper-empty">Click on screen to pick colors</div>';
    if (state.pickedColors.length === 0) {
        containers.forEach((c) => {
            if (c) {
                c.innerHTML = emptyHtml;
            }
        });
        return;
    }

    let html = '';
    state.pickedColors.forEach((c, i) => {
        if (c.region) {
            html += `<div class="helper-color-item">
                <span class="index">#${i + 1}</span>
                <span>⬜</span>
                <span class="coords">region {${c.region.join(', ')}}</span>
                <span class="remove-pick" onclick="removePickedColor(${i})">✕</span>
            </div>`;
        } else {
            html += `<div class="helper-color-item">
                <span class="index">#${i + 1}</span>
                <span class="swatch" style="background:${c.hex}"></span>
                <span class="coords">(${c.x}, ${c.y})</span>
                <span class="color-hex">${c.intHex}</span>
                <span class="color-int">RGB(${c.r},${c.g},${c.b})</span>
                <span class="remove-pick" onclick="removePickedColor(${i})">✕</span>
            </div>`;
        }
    });
    containers.forEach((c) => {
        if (c) {
            c.innerHTML = html;
        }
    });
}

function removePickedColor(index) {
    state.pickedColors.splice(index, 1);
    renderPickedColors();
}
window.removePickedColor = removePickedColor;

document.addEventListener('DOMContentLoaded', initHelper);

// -----------------------------------------------------------------------------
// Application browser modal
// -----------------------------------------------------------------------------

async function showAppsModal() {
    const modal = document.getElementById('appsModal');
    const list = document.getElementById('appsList');
    if (!modal || !list) {
        return;
    }
    modal.style.display = 'flex';
    list.innerHTML = '<div class="helper-empty">Loading apps...</div>';

    try {
        const appsRes = await fetch(`${API}/apps`).then((r) => r.json());
        const apps = (appsRes.apps || [])
            .map((a) => ({
                name: a.name || a.bundleId || a.bundle_id,
                bundle_id: a.bundleId || a.bundle_id,
            }))
            .filter((a) => a.bundle_id);
        renderApps(apps);
    } catch (e) {
        list.innerHTML = `<div class="helper-empty">⚠️ ${e.message || 'Failed'}</div>`;
    }
}

function renderApps(apps) {
    const list = document.getElementById('appsList');
    if (!apps.length) {
        list.innerHTML = '<div class="helper-empty">No apps found</div>';
        return;
    }

    apps.sort((a, b) => (a.name || '').localeCompare(b.name || ''));

    list.innerHTML = apps
        .map((app) => {
            const name = app.name || app.bundle_id;
            const bid = app.bundle_id;
            const icon = getAppEmoji(bid);
            return `<div class="app-item" title="${bid}">
            <div class="app-icon">${icon}</div>
            <div class="app-details">
                <div class="app-name">${escapeHtml(name)}</div>
                <div class="app-bundle">${escapeHtml(bid)}</div>
            </div>
            <div class="app-actions hm-row-btns">
                <button type="button" class="hm-btn-copy" onclick="event.stopPropagation();copyBundleId('${bid}')">${_t('hmBtnCopy')}</button>
                <button type="button" class="hm-btn-insert" onclick="event.stopPropagation();insertAppRun('${bid}')">${_t('hmBtnInsert')}</button>
            </div>
        </div>`;
        })
        .join('');
}

function getAppEmoji(bundleId) {
    const map = {
        'com.apple.Preferences': '⚙️',
        'com.apple.mobilesafari': '🧭',
        'com.apple.MobileSMS': '💬',
        'com.apple.mobilephone': '📞',
        'com.apple.camera': '📷',
        'com.apple.mobileslideshow': '🖼️',
        'com.apple.AppStore': '🏪',
        'com.apple.Maps': '🗺️',
        'com.apple.mobiletimer': '⏰',
        'com.apple.mobilenotes': '📝',
        'com.apple.mobilecal': '📅',
        'com.apple.mobilemail': '📧',
        'com.apple.Music': '🎵',
        'com.apple.Health': '❤️',
        'com.apple.weather': '🌤️',
        'com.apple.calculator': '🔢',
        'com.apple.Fitness': '🏃',
        'com.apple.shortcuts': '⚡',
    };
    return map[bundleId] || '📦';
}

function copyBundleId(bundleId) {
    _hmDoCopy(bundleId);
}

function insertAppRun(bundleId) {
    insertEditorText(`switch_to_app(${_hmAlangStr(bundleId)})\n`);
    closeAppsModal();
}

function closeAppsModal() {
    const modal = document.getElementById('appsModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

document.addEventListener('click', (e) => {
    if (e.target.id === 'appsModal') {
        closeAppsModal();
    }
});

document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') {
        return;
    }
    const m = document.getElementById('appsModal');
    if (m && m.style.display !== 'none') {
        closeAppsModal();
        return;
    }
    document
        .querySelectorAll('.modal-overlay.visible')
        .forEach((el) => el.classList.remove('visible'));
});

window.showAppsModal = showAppsModal;
window.closeAppsModal = closeAppsModal;
window.copyBundleId = copyBundleId;
window.insertAppRun = insertAppRun;

// -----------------------------------------------------------------------------
// Live screen connection and resizing
// -----------------------------------------------------------------------------

function _getVncUrl(host, viewOnly) {
    const port = window.NA_SCREEN_PORT || window.IOSAUTO_SCREEN_PORT || 5911;
    return `http://${host}:${port}/?embed=1`;
}

function _getDeviceHost() {
    return window.NA_DEVICE_HOST || window.IOSAUTO_DEVICE_HOST || window.location.hostname;
}

function _syncVncOverlayPointer() {
    const coordOverlay = document.getElementById('vncCoordOverlay');
    if (!coordOverlay || coordOverlay.style.display === 'none') {
        return;
    }
    // Script đang chạy: chặn click xuyên vào VNC. Idle: để VNC nhận điều khiển.
    coordOverlay.style.pointerEvents = state.runningTaskId ? 'auto' : 'none';
}

/** Own the existing connection, overlay and resize listeners without changing their timing. */
function initLiveScreen() {
    const connectBtn = document.getElementById('screenConnectBtn');
    const disconnectBtn = document.getElementById('screenDisconnectBtn');
    const homeBtn = document.getElementById('screenHomeBtn');
    const placeholder = document.getElementById('screenPlaceholder');
    const screenView = document.getElementById('screenView');

    if (!connectBtn) {
        return;
    }

    let screenInfo = {
        width: 1170,
        height: 2532,
        scale: 3,
        pointWidth: 390,
        pointHeight: 844,
    };
    let isStreaming = false;

    (async function () {
        try {
            const res = await fetch(`${API}/screen_info`);
            const data = await res.json();
            if (data.width) {
                screenInfo = {
                    width: data.width,
                    height: data.height,
                    scale: data.scale || 3,
                    pointWidth: data.pointWidth || Math.round(data.width / (data.scale || 3)),
                    pointHeight: data.pointHeight || Math.round(data.height / (data.scale || 3)),
                };
                state.screenSize = { w: data.width, h: data.height };
                state.wdaPoints = { w: screenInfo.pointWidth, h: screenInfo.pointHeight };
                state.deviceScale = data.scale || 3;
                state.screenInfo = screenInfo;
                const bezel = document.getElementById('phoneBezel');
                if (bezel && screenInfo.width > 0 && screenInfo.height > 0) {
                    bezel.style.setProperty('--pw', String(screenInfo.width));
                    bezel.style.setProperty('--ph', String(screenInfo.height));
                }
            }
        } catch (e) {}
    })();

    connectBtn.addEventListener('click', async () => {
        // Each tab owns its viewer; repeated Connect must not reload a live iframe.
        // Contract: docs/WORKFLOW-SCREEN-PERSISTENCE-CONTRACT.md.
        if (isStreaming) {
            return;
        }
        const vncFrame = document.getElementById('vncFrame');
        const host = _getDeviceHost();
        if (!host || !vncFrame) {
            appendLog(_l('Could not connect to iPhone', 'Không kết nối được iPhone'), 'error');
            return;
        }

        placeholder.style.display = 'none';
        isStreaming = true;
        if (homeBtn) {
            homeBtn.style.display = 'flex';
        }
        connectBtn.style.display = 'none';
        if (disconnectBtn) {
            disconnectBtn.style.display = 'flex';
        }

        const vncUrl = _getVncUrl(host, false);
        vncFrame.src = vncUrl;
        vncFrame.style.display = 'block';
        const coordOverlay = document.getElementById('vncCoordOverlay');
        if (coordOverlay) {
            coordOverlay.style.display = 'block';
            _syncVncOverlayPointer();
        }
        appendLog(_l('Connected to iPhone', 'Đã kết nối iPhone'), 'success');
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }
    });

    disconnectBtn.addEventListener('click', () => {
        const vncFrame = document.getElementById('vncFrame');
        if (vncFrame) {
            vncFrame.src = '';
            vncFrame.style.display = 'none';
        }
        const coordOverlay = document.getElementById('vncCoordOverlay');
        if (coordOverlay) {
            coordOverlay.style.display = 'none';
        }
        placeholder.style.display = '';
        if (homeBtn) {
            homeBtn.style.display = 'flex';
        }
        connectBtn.style.display = 'flex';
        if (disconnectBtn) {
            disconnectBtn.style.display = 'none';
        }
        isStreaming = false;
        appendLog(_l('Disconnected from iPhone', 'Đã ngắt kết nối iPhone'), 'info');
    });

    if (homeBtn) {
        homeBtn.style.display = 'flex';
        homeBtn.addEventListener('click', async () => {
            try {
                await fetch(`${API}/key?key=home`);
                appendLog(_l('🏠 Home', '🏠 Home'), 'success');
            } catch (e) {
                appendLog('🏠 ' + e.message, 'error');
            }
        });
    }

    function getStreamBounds() {
        const box = document.getElementById('phoneBezel') || screenView;
        const rect = box.getBoundingClientRect();
        const natW =
            screenInfo.pointWidth || Math.round(screenInfo.width / (screenInfo.scale || 3));
        const natH =
            screenInfo.pointHeight || Math.round(screenInfo.height / (screenInfo.scale || 3));
        const containerRatio = rect.width / rect.height;
        const imageRatio = natW / natH;

        let renderW;
        let renderH;
        let offsetX;
        let offsetY;
        if (imageRatio > containerRatio) {
            renderW = rect.width;
            renderH = rect.width / imageRatio;
            offsetX = 0;
            offsetY = (rect.height - renderH) / 2;
        } else {
            renderH = rect.height;
            renderW = rect.height * imageRatio;
            offsetX = (rect.width - renderW) / 2;
            offsetY = 0;
        }
        return { renderW, renderH, offsetX, offsetY, natW, natH, rect };
    }

    // Double-click overlay (khi script đang chạy / overlay bắt event) → tap points
    const coordOverlayEl = document.getElementById('vncCoordOverlay');
    if (coordOverlayEl) {
        coordOverlayEl.addEventListener('dblclick', async (e) => {
            const bounds = getStreamBounds();
            const relX = e.clientX - bounds.rect.left - bounds.offsetX;
            const relY = e.clientY - bounds.rect.top - bounds.offsetY;
            if (relX < 0 || relX > bounds.renderW || relY < 0 || relY > bounds.renderH) {
                return;
            }
            const x = Math.round((relX / bounds.renderW) * bounds.natW);
            const y = Math.round((relY / bounds.renderH) * bounds.natH);
            try {
                await fetch(`${API}/tap?x=${x}&y=${y}`);
                appendLog(_l(`👆 Tap (${x}, ${y}) pt`, `👆 Chạm (${x}, ${y}) pt`), 'success');
            } catch (err) {
                appendLog('👆 ' + err.message, 'error');
            }
        });
    }

    const resizer = document.getElementById('screenResizer');
    const panel = document.getElementById('liveScreenPanel');
    if (resizer && panel) {
        let startX;
        let startWidth;

        resizer.addEventListener('mousedown', (e) => {
            startX = e.clientX;
            startWidth = panel.offsetWidth;
            document.addEventListener('mousemove', onResize);
            document.addEventListener('mouseup', stopResize);
            e.preventDefault();
        });

        function onResize(e) {
            const newWidth = startWidth + (e.clientX - startX);
            if (newWidth >= 200 && newWidth <= 600) {
                panel.style.width = newWidth + 'px';
                if (state.editor) {
                    state.editor.layout();
                }
            }
        }

        function stopResize() {
            document.removeEventListener('mousemove', onResize);
            document.removeEventListener('mouseup', stopResize);
        }
    }
}
window._syncVncOverlayPointer = _syncVncOverlayPointer;

// -----------------------------------------------------------------------------
// Editor insertion and list selection
// -----------------------------------------------------------------------------

function insertEditorText(text) {
    const s = text == null ? '' : String(text);
    if (!s) {
        return;
    }
    if (!state.editor) {
        _hmDoCopy(s);
        return;
    }
    const pos = state.editor.getPosition();
    state.editor.executeEdits('', [
        {
            range: {
                startLineNumber: pos.lineNumber,
                startColumn: pos.column,
                endLineNumber: pos.lineNumber,
                endColumn: pos.column,
            },
            text: s,
        },
    ]);
    appendLog(_t('insertLog') + s.split('\n')[0], 'success');
}

function helperPickRandomList(input, fields, argName, updateCode) {
    const existing = document.getElementById('zxRandomDropdown');
    if (existing) {
        existing.remove();
    }
    const rect = input.getBoundingClientRect();
    const wrap = document.createElement('div');
    wrap.id = 'zxRandomDropdown';
    wrap.style.cssText = `position:fixed; left:${rect.left}px; top:${rect.bottom + 4}px; min-width:${Math.max(rect.width, 340)}px; max-width:500px; background:rgba(20,23,32,0.97); backdrop-filter:blur(20px); border:1px solid rgba(129,140,248,0.4); border-radius:8px; padding:10px; z-index:99999; box-shadow:0 8px 32px rgba(0,0,0,0.5); display:flex; flex-direction:column; gap:8px;`;
    wrap.innerHTML = `
    <div style="display:flex; gap:4px;">
      <button data-mode="list" class="zxRandTab" style="flex:1; padding:6px; background:var(--accent); color:#fff; border:none; border-radius:5px; font-size:11px; font-weight:600; cursor:pointer;">${_t('randTabList')}</button>
      <button data-mode="email" class="zxRandTab" style="flex:1; padding:6px; background:rgba(255,255,255,0.06); color:#94a3b8; border:none; border-radius:5px; font-size:11px; font-weight:600; cursor:pointer;">${_t('randTabEmail')}</button>
    </div>
    <div id="zxRandPanelList" style="display:flex; flex-direction:column; gap:6px;">
      <div style="font-size:11px; color:#94a3b8;">${_t('randListHint')}</div>
      <textarea id="zxRandomItems" rows="5" placeholder="abc\nxyz\nhello world" style="width:100%; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:8px 10px; color:var(--text-primary); font-family:var(--font-mono); font-size:13px; outline:none; resize:vertical; box-sizing:border-box;"></textarea>
    </div>
    <div id="zxRandPanelEmail" style="display:none; flex-direction:column; gap:6px;">
      <div style="font-size:11px; color:#94a3b8;">${_t('randPrefixHint')}</div>
      <textarea id="zxRandEmailCharset" rows="2" style="width:100%; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:8px 10px; color:var(--text-primary); font-family:var(--font-mono); font-size:13px; outline:none; resize:vertical; box-sizing:border-box;">abcdefghijklmnopqrstuvwxyz0123456789</textarea>
      <div style="display:flex; gap:6px; align-items:center;">
        <span style="font-size:11px; color:#94a3b8;">${_t('randLen')}</span>
        <input id="zxRandEmailLenMin" type="number" value="8" min="1" max="50" style="width:60px; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:6px; color:var(--text-primary); font-size:12px; box-sizing:border-box;">
        <span style="font-size:11px; color:#94a3b8;">→</span>
        <input id="zxRandEmailLenMax" type="number" value="15" min="1" max="50" style="width:60px; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:6px; color:var(--text-primary); font-size:12px; box-sizing:border-box;">
        <span style="font-size:11px; color:#94a3b8;">${_t('randChars')}</span>
      </div>
      <div style="font-size:11px; color:#94a3b8; margin-top:4px;">${_t('randDomainHint')}</div>
      <textarea id="zxRandEmailDom" rows="3" placeholder="gmail.com\nyahoo.com\noutlook.com" style="width:100%; background:var(--bg-primary); border:1px solid var(--border-color); border-radius:6px; padding:8px 10px; color:var(--text-primary); font-family:var(--font-mono); font-size:13px; outline:none; resize:vertical; box-sizing:border-box;">gmail.com\nyahoo.com\noutlook.com</textarea>
    </div>
    <div style="display:flex; gap:6px; justify-content:flex-end;">
      <button id="zxRandomCancel" style="padding:6px 12px; background:transparent; border:1px solid var(--border-color); border-radius:6px; color:#94a3b8; font-size:12px; font-weight:600; cursor:pointer;">${_t('imgCancel')}</button>
      <button type="button" id="zxRandomOk" class="hm-btn-insert">${_t('hmBtnInsert')}</button>
    </div>`;
    document.body.appendChild(wrap);
    document.getElementById('zxRandEmailDom').value = 'gmail.com\nyahoo.com\noutlook.com';
    let mode = 'list';
    const panels = {
        list: document.getElementById('zxRandPanelList'),
        email: document.getElementById('zxRandPanelEmail'),
    };
    wrap.querySelectorAll('.zxRandTab').forEach((btn) => {
        btn.addEventListener('click', () => {
            mode = btn.dataset.mode;
            wrap.querySelectorAll('.zxRandTab').forEach((b) => {
                b.style.background = b === btn ? 'var(--accent)' : 'rgba(255,255,255,0.06)';
                b.style.color = b === btn ? '#fff' : '#94a3b8';
            });
            Object.entries(panels).forEach(
                ([k, p]) => (p.style.display = k === mode ? 'flex' : 'none'),
            );
        });
    });
    const qstr = (s) => '"' + s.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
    const pickExpr = (arr) =>
        arr.length === 1 ? qstr(arr[0]) : `random_pick([${arr.map(qstr).join(', ')}])`;
    const randExpr = (charset, mn, mx) =>
        mn === mx
            ? `random_string(${qstr(charset)}, ${mn})`
            : `random_string(${qstr(charset)}, ${mn}, ${mx})`;
    const close = () => wrap.remove();
    document.getElementById('zxRandomCancel').onclick = close;
    document.getElementById('zxRandomOk').onclick = () => {
        let expr = '';
        if (mode === 'list') {
            const items = document
                .getElementById('zxRandomItems')
                .value.split('\n')
                .map((s) => s.trim())
                .filter(Boolean);
            if (!items.length) {
                close();
                return;
            }
            expr = pickExpr(items);
        } else {
            const cs = document
                .getElementById('zxRandEmailCharset')
                .value.replace(/\n/g, '')
                .trim();
            const mn = parseInt(document.getElementById('zxRandEmailLenMin').value) || 8;
            const mx = parseInt(document.getElementById('zxRandEmailLenMax').value) || mn;
            let doms = document
                .getElementById('zxRandEmailDom')
                .value.split('\n')
                .map((s) => s.trim())
                .filter(Boolean);
            if (!cs || !doms.length) {
                close();
                return;
            }
            const letters = cs.replace(/[^a-zA-Z]/g, '') || cs;
            const lo = Math.min(mn, mx);
            const hi = Math.max(mn, mx);
            const headExpr = `random_string(${qstr(letters)}, 1)`;
            const tailExpr =
                lo === hi
                    ? `random_string(${qstr(cs)}, ${lo - 1})`
                    : `random_string(${qstr(cs)}, ${lo - 1}, ${hi - 1})`;
            expr = headExpr + ' .. ' + tailExpr + ' .. "@" .. ' + pickExpr(doms);
        }
        input.value = expr;
        fields[argName] = expr;
        if (updateCode) {
            updateCode();
        }
        close();
    };
}

// -----------------------------------------------------------------------------
// OCR, Safari DOM and accessibility pickers
// -----------------------------------------------------------------------------

async function helperPickTextFromOcr(input, fields, argName, updateCode) {
    const screenW =
        (state.wdaPoints && state.wdaPoints.w) ||
        (state.screenInfo && state.screenInfo.pointWidth) ||
        390;
    const screenH =
        (state.wdaPoints && state.wdaPoints.h) ||
        (state.screenInfo && state.screenInfo.pointHeight) ||
        844;
    return _helperOcrShowDropdown(input, fields, argName, updateCode, {
        x: 0,
        y: 0,
        w: screenW,
        h: screenH,
    });
}

async function _helperOcrShowDropdown(input, fields, argName, updateCode, region) {
    const existing = document.getElementById('zxOcrDropdown');
    if (existing) {
        existing.remove();
    }
    const dropdown = document.createElement('div');
    dropdown.id = 'zxOcrDropdown';
    const rect = input.getBoundingClientRect();
    dropdown.style.cssText = `position:fixed; left:${rect.left}px; top:${rect.bottom + 4}px; min-width:${rect.width}px; max-width:400px; max-height:280px; overflow:auto; background:rgba(20,23,32,0.95); backdrop-filter:blur(20px); border:1px solid rgba(99,102,241,0.4); border-radius:8px; padding:6px; z-index:99999; box-shadow:0 8px 32px rgba(0,0,0,0.5);`;
    dropdown.innerHTML = `<div style="padding:8px; color:#94a3b8; font-size:12px;">📖 Đang quét vùng ${region.w}x${region.h}…</div>`;
    document.body.appendChild(dropdown);

    const closeDropdown = (e) => {
        if (e && (e.target === input || dropdown.contains(e.target))) {
            return;
        }
        dropdown.remove();
        document.removeEventListener('mousedown', closeDropdown, true);
    };
    setTimeout(() => document.addEventListener('mousedown', closeDropdown, true), 100);

    try {
        const res = await fetch(`${API}/api/ocr`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(region),
        });
        const data = await res.json();
        if (!data.ok) {
            dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${data.error || 'OCR fail'}</div>`;
            return;
        }
        const items = data.items || [];
        if (!items.length) {
            dropdown.innerHTML = `<div style="padding:8px; color:#94a3b8; font-size:12px;">Không thấy chữ nào trên màn hình.</div>`;
            return;
        }
        dropdown.innerHTML = '';
        items.forEach((it) => {
            const opt = document.createElement('div');
            opt.style.cssText =
                'padding:8px 10px; color:#e8eaf0; font-size:13px; cursor:pointer; border-radius:4px; display:flex; justify-content:space-between; align-items:center; gap:8px;';
            opt.innerHTML = `<span style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${it.text.replace(/</g, '&lt;')}</span><span style="color:#6b7280; font-size:10px; font-family:monospace;">${it.x},${it.y}</span>`;
            opt.onmouseenter = () => (opt.style.background = 'rgba(99,102,241,0.2)');
            opt.onmouseleave = () => (opt.style.background = 'transparent');
            opt.onclick = () => {
                const quoted = '"' + it.text.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
                input.value = quoted;
                fields[argName] = quoted;
                if (updateCode) {
                    updateCode();
                }
                dropdown.remove();
            };
            dropdown.appendChild(opt);
        });
    } catch (e) {
        dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${e.message}</div>`;
    }
}

async function helperPickFromSafariDOM(input, fields, argName, updateCode, mode) {
    const existing = document.getElementById('zxDomDropdown');
    if (existing) {
        existing.remove();
    }
    const dropdown = document.createElement('div');
    dropdown.id = 'zxDomDropdown';
    const rect = input.getBoundingClientRect();
    dropdown.style.cssText = `position:fixed; left:${rect.left}px; top:${rect.bottom + 4}px; min-width:${Math.max(rect.width, 280)}px; max-width:480px; max-height:320px; overflow:auto; background:rgba(20,23,32,0.95); backdrop-filter:blur(20px); border:1px solid rgba(99,102,241,0.4); border-radius:8px; padding:6px; z-index:99999; box-shadow:0 8px 32px rgba(0,0,0,0.5);`;
    dropdown.innerHTML = `<div style="padding:8px; color:#94a3b8; font-size:12px;">🌐 Đang quét trang Safari…</div>`;
    document.body.appendChild(dropdown);
    const closeDropdown = (e) => {
        if (e && (e.target === input || dropdown.contains(e.target))) {
            return;
        }
        dropdown.remove();
        document.removeEventListener('mousedown', closeDropdown, true);
    };
    setTimeout(() => document.addEventListener('mousedown', closeDropdown, true), 100);
    try {
        const res = await fetch(`${API}/api/safari/scan`, { method: 'POST' });
        const data = await res.json();
        if (!data.ok) {
            dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${data.error || 'Scan fail'}</div>`;
            return;
        }
        const items = data.items || [];
        if (!items.length) {
            dropdown.innerHTML = `<div style="padding:8px; color:#94a3b8; font-size:12px;">Không thấy ô/nút nào — mở Safari + load 1 trang rồi thử lại.</div>`;
            return;
        }
        dropdown.innerHTML = '';
        const kindIcon = {
            email: '📧',
            password: '🔒',
            text: '📝',
            search: '🔎',
            tel: '📞',
            number: '#',
            checkbox: '☐',
            radio: '○',
            submit: '✅',
            button: '🔘',
            link: '🔗',
            textarea: '📄',
            select: '▾',
        };
        items.forEach((it) => {
            const opt = document.createElement('div');
            opt.style.cssText =
                'padding:8px 10px; color:#e8eaf0; font-size:13px; cursor:pointer; border-radius:4px; display:flex; gap:8px; align-items:center;';
            const ic = kindIcon[it.kind] || '•';
            opt.innerHTML = `<span style="font-size:14px; width:18px;">${ic}</span><span style="flex:1; overflow:hidden;"><div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${(it.label || '(no label)').replace(/</g, '&lt;')}</div><div style="color:#6b7280; font-size:10px; font-family:monospace; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${(it.sel || '').replace(/</g, '&lt;')}</div></span>`;
            opt.onmouseenter = () => (opt.style.background = 'rgba(99,102,241,0.2)');
            opt.onmouseleave = () => (opt.style.background = 'transparent');
            opt.onclick = () => {
                const pick = it.label || '';
                const quoted = '"' + pick.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
                input.value = quoted;
                fields[argName] = quoted;
                if (updateCode) {
                    updateCode();
                }
                dropdown.remove();
            };
            dropdown.appendChild(opt);
        });
    } catch (e) {
        dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${e.message}</div>`;
    }
}

async function helperPickFromAX(input, fields, argName, updateCode, byInput) {
    // Cùng UI dropdown với Quét chữ (OCR) — hiện kind nút/chữ/ô để khỏi nhầm nhãn trùng
    const existing = document.getElementById('zxAxDropdown');
    if (existing) {
        existing.remove();
    }
    const dropdown = document.createElement('div');
    dropdown.id = 'zxAxDropdown';
    const rect = input.getBoundingClientRect();
    dropdown.style.cssText = `position:fixed; left:${rect.left}px; top:${rect.bottom + 4}px; min-width:${Math.max(rect.width, 320)}px; max-width:440px; max-height:320px; overflow:auto; background:rgba(20,23,32,0.95); backdrop-filter:blur(20px); border:1px solid rgba(99,102,241,0.4); border-radius:8px; padding:6px; z-index:99999; box-shadow:0 8px 32px rgba(0,0,0,0.5);`;
    dropdown.innerHTML = `<div style="padding:8px; color:#94a3b8; font-size:12px;">👁 Đang quét UI…</div>`;
    document.body.appendChild(dropdown);
    const closeDropdown = (e) => {
        if (e && (e.target === input || dropdown.contains(e.target))) {
            return;
        }
        dropdown.remove();
        document.removeEventListener('mousedown', closeDropdown, true);
    };
    setTimeout(() => document.addEventListener('mousedown', closeDropdown, true), 100);
    try {
        const res = await fetch(`${API}/api/ax/scan`, { method: 'POST' });
        const data = await res.json();
        if (!data.ok) {
            dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${data.error || 'Scan fail'}</div>`;
            return;
        }
        const items = data.items || [];
        if (!items.length) {
            dropdown.innerHTML = `<div style="padding:8px; color:#94a3b8; font-size:12px;">Không thấy nút/ô trên app đang mở.</div>`;
            return;
        }
        dropdown.innerHTML = '';
        const kindIcon = { button: '🔘', text: '📝', field: '✏️', other: '•' };
        const kindVi = { button: 'nút', text: 'chữ', field: 'ô', other: 'khác' };
        items.forEach((it) => {
            const text = (it.text || it.label || it.id || '').toString();
            if (!text.trim()) {
                return;
            }
            let kind = (it.kind || '').toString();
            if (!kind) {
                if (it.button) {
                    kind = 'button';
                } else if (it.field) {
                    kind = 'field';
                } else {
                    kind = 'other';
                }
            }
            const x = it.x ?? it.cx ?? 0;
            const y = it.y ?? it.cy ?? 0;
            const opt = document.createElement('div');
            opt.style.cssText =
                'padding:8px 10px; color:#e8eaf0; font-size:13px; cursor:pointer; border-radius:4px; display:flex; align-items:center; gap:8px;';
            const ic = kindIcon[kind] || '•';
            const kv = kindVi[kind] || kind;
            opt.innerHTML =
                `<span style="font-size:14px; width:18px; flex-shrink:0;">${ic}</span>` +
                `<span style="flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${text.replace(/</g, '&lt;')}</span>` +
                `<span style="color:#a5b4fc; font-size:10px; flex-shrink:0;">${kv}</span>` +
                `<span style="color:#6b7280; font-size:10px; font-family:monospace; flex-shrink:0;">${x},${y}</span>`;
            opt.onmouseenter = () => {
                opt.style.background = 'rgba(99,102,241,0.2)';
            };
            opt.onmouseleave = () => {
                opt.style.background = 'transparent';
            };
            opt.onclick = () => {
                const pick = (it.label || it.text || it.id || '').toString().trim();
                const quoted = '"' + pick.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
                input.value = quoted;
                fields[argName] = quoted;
                const byTok =
                    kind === 'button' || kind === 'text' || kind === 'field' ? kind : 'any';
                const byQuoted = '"' + byTok + '"';
                fields.by = byQuoted;
                if (byInput) {
                    byInput.value = byQuoted;
                }
                if (updateCode) {
                    updateCode();
                }
                dropdown.remove();
            };
            dropdown.appendChild(opt);
        });
    } catch (e) {
        dropdown.innerHTML = `<div style="padding:8px; color:#f87171; font-size:12px;">❌ ${e.message}</div>`;
    }
}

// -----------------------------------------------------------------------------
// Safari scan modal and action generation
// -----------------------------------------------------------------------------

async function openSafariScanModal() {
    const existing = document.getElementById('zxSafariModal');
    if (existing) {
        existing.remove();
    }
    const overlay = document.createElement('div');
    overlay.id = 'zxSafariModal';
    overlay.style.cssText =
        'position:fixed; inset:0; background:rgba(0,0,0,0.55); z-index:99999; display:flex; align-items:center; justify-content:center; padding:20px;';
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            overlay.remove();
        }
    });
    const box = document.createElement('div');
    box.style.cssText =
        'background:rgba(20,23,32,0.98); border:1px solid rgba(99,102,241,0.4); border-radius:12px; width:min(720px,100%); max-height:80vh; display:flex; flex-direction:column; box-shadow:0 12px 48px rgba(0,0,0,0.6);';
    const head = document.createElement('div');
    head.style.cssText =
        'padding:14px 18px; border-bottom:1px solid rgba(255,255,255,0.08); display:flex; justify-content:space-between; align-items:center;';
    head.innerHTML = `<div style="color:#e8eaf0; font-size:15px; font-weight:600;">🌐 Quét Safari — Chọn ô/nút + hành động</div>`;
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '✕';
    closeBtn.style.cssText =
        'background:transparent; color:#94a3b8; border:none; font-size:18px; cursor:pointer;';
    closeBtn.addEventListener('click', () => overlay.remove());
    head.appendChild(closeBtn);
    box.appendChild(head);
    const toolbar = document.createElement('div');
    toolbar.style.cssText =
        'padding:10px 18px; border-bottom:1px solid rgba(255,255,255,0.06); display:flex; gap:8px; align-items:center;';
    const refreshBtn = document.createElement('button');
    refreshBtn.textContent = '🔄 Quét lại';
    refreshBtn.className = 'hm-pick';
    const filterInput = document.createElement('input');
    filterInput.placeholder = 'Lọc theo tên/selector…';
    filterInput.style.cssText =
        'flex:1; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.12); color:#e8eaf0; border-radius:6px; padding:7px 10px; font-size:12px;';
    const advBtn = document.createElement('button');
    advBtn.textContent = '⚙️ Nâng cao';
    advBtn.title = 'Sinh code dùng selector (chính xác hơn khi có nhiều mục trùng tên)';
    advBtn.style.cssText =
        'background:rgba(255,255,255,0.06); color:#94a3b8; border:1px solid rgba(255,255,255,0.12); border-radius:6px; padding:7px 12px; cursor:pointer; font-size:12px; font-weight:600;';
    advBtn.addEventListener('click', () => {
        advMode = !advMode;
        advBtn.style.background = advMode ? 'var(--accent)' : 'rgba(255,255,255,0.06)';
        advBtn.style.color = advMode ? '#fff' : '#94a3b8';
        if (listBox._items) {
            render(listBox._items);
        }
    });
    toolbar.appendChild(refreshBtn);
    toolbar.appendChild(filterInput);
    toolbar.appendChild(advBtn);
    box.appendChild(toolbar);
    const listBox = document.createElement('div');
    listBox.style.cssText = 'overflow-y:auto; flex:1; padding:6px;';
    box.appendChild(listBox);
    overlay.appendChild(box);
    document.body.appendChild(overlay);

    const escTxt = (s) => (s || '').replace(/"/g, '\\"');
    const escSel = (s) => (s || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    const ACTIONS_INPUT_SIMPLE = [
        {
            label: () => _l('📝 Fill', '📝 Điền', '📝 填入'),
            code: (it) => `web_fill("${escTxt(it.label)}", "TEXT", "field")`,
        },
        {
            label: () => _l('⏳ Wait', '⏳ Chờ hiện', '⏳ 等待'),
            code: (it) => `web_wait("${escTxt(it.label)}", "field")`,
        },
    ];
    const ACTIONS_BUTTON_SIMPLE = [
        {
            label: () => _l('👆 Click', '👆 Bấm', '👆 点击'),
            code: (it) => `web_click("${escTxt(it.label)}", "button")`,
        },
        {
            label: () => _l('✊ Hold 10s', '✊ Giữ 10s', '✊ 长按10秒'),
            code: (it) => `web_long_press("${escTxt(it.label)}", 10)`,
        },
        {
            label: () => _l('✊ Until gone', '✊ Giữ đến mất', '✊ 按到消失'),
            code: (it) => `web_long_press("${escTxt(it.label)}", "gone", 20)`,
        },
        {
            label: () => _l('⏳ Wait', '⏳ Chờ hiện', '⏳ 等待'),
            code: (it) => `web_wait("${escTxt(it.label)}", "button")`,
        },
    ];
    const ACTIONS_INPUT_ADV = [
        {
            label: () => _l('📝 Fill', '📝 Điền', '📝 填入'),
            code: (it) => `web_fill("${escSel(it.sel)}", "TEXT", "field")`,
        },
        {
            label: () => _l('⏳ Wait', '⏳ Chờ hiện', '⏳ 等待'),
            code: (it) => `web_wait("${escSel(it.sel)}", "field")`,
        },
    ];
    const ACTIONS_BUTTON_ADV = [
        {
            label: () => _l('👆 Click', '👆 Bấm', '👆 点击'),
            code: (it) => `web_click("${escSel(it.sel)}", "button")`,
        },
        {
            label: () => _l('✊ Hold 10s', '✊ Giữ 10s', '✊ 长按10秒'),
            code: (it) => `web_long_press("${escSel(it.sel)}", 10)`,
        },
        {
            label: () => _l('✊ Until gone', '✊ Giữ đến mất', '✊ 按到消失'),
            code: (it) => `web_long_press("${escSel(it.sel)}", "gone", 20)`,
        },
        {
            label: () => _l('⏳ Wait', '⏳ Chờ hiện', '⏳ 等待'),
            code: (it) => `web_wait("${escSel(it.sel)}", "button")`,
        },
    ];
    let advMode = false;

    function render(items) {
        listBox.innerHTML = '';
        if (!items.length) {
            listBox.innerHTML = `<div style="padding:16px; color:#94a3b8; font-size:13px; text-align:center;">Không thấy ô/nút nào — mở Safari + load 1 trang rồi bấm Quét lại.</div>`;
            return;
        }
        const kindIcon = {
            email: '📧',
            password: '🔒',
            text: '📝',
            search: '🔎',
            tel: '📞',
            number: '#',
            checkbox: '☐',
            radio: '○',
            submit: '✅',
            button: '🔘',
            link: '🔗',
            textarea: '📄',
            select: '▾',
        };
        items.forEach((it) => {
            const row = document.createElement('div');
            row.style.cssText =
                'padding:10px 12px; border-bottom:1px solid rgba(255,255,255,0.04); display:flex; flex-direction:column; gap:6px;';
            const ic = kindIcon[it.kind] || '•';
            row.innerHTML = `<div style="display:flex; gap:8px; align-items:center;"><span style="font-size:14px; width:18px;">${ic}</span><div style="flex:1; min-width:0;"><div style="color:#e8eaf0; font-size:13px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${(it.label || '(no label)').replace(/</g, '&lt;')}</div><div style="color:#6b7280; font-size:10px; font-family:monospace; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${(it.sel || '').replace(/</g, '&lt;')}</div></div></div>`;
            const btnRow = document.createElement('div');
            btnRow.style.cssText = 'display:flex; flex-wrap:wrap; gap:6px; padding-left:26px;';
            const isInput =
                [
                    'text',
                    'email',
                    'password',
                    'search',
                    'tel',
                    'number',
                    'textarea',
                    'select',
                    'field',
                ].indexOf(it.kind) >= 0;
            const actions = advMode
                ? isInput
                    ? ACTIONS_INPUT_ADV
                    : ACTIONS_BUTTON_ADV
                : isInput
                  ? ACTIONS_INPUT_SIMPLE
                  : ACTIONS_BUTTON_SIMPLE;
            actions.forEach((a) => {
                const b = document.createElement('button');
                b.textContent = typeof a.label === 'function' ? a.label() : a.label;
                b.style.cssText =
                    'background:rgba(99,102,241,0.18); color:#a5b4fc; border:1px solid rgba(99,102,241,0.3); border-radius:5px; padding:5px 9px; cursor:pointer; font-size:11px; font-weight:600;';
                b.addEventListener('click', () => {
                    insertEditorText(a.code(it));
                });
                btnRow.appendChild(b);
            });
            row.appendChild(btnRow);
            listBox.appendChild(row);
        });
    }

    async function loadScan() {
        listBox.innerHTML = `<div style="padding:16px; color:#94a3b8; font-size:13px; text-align:center;">🌐 Đang quét trang Safari…</div>`;
        try {
            const res = await fetch(`${API}/api/safari/scan`, { method: 'POST' });
            const data = await res.json();
            if (!data.ok) {
                listBox.innerHTML = `<div style="padding:16px; color:#f87171; font-size:13px;">❌ ${data.error || 'Scan fail'} — mở Safari + load 1 trang rồi thử lại.</div>`;
                return;
            }
            const items = data.items || [];
            listBox._items = items;
            render(items);
        } catch (e) {
            listBox.innerHTML = `<div style="padding:16px; color:#f87171; font-size:13px;">❌ ${e.message}</div>`;
        }
    }

    refreshBtn.addEventListener('click', loadScan);
    filterInput.addEventListener('input', () => {
        const q = filterInput.value.toLowerCase().trim();
        if (!listBox._items) {
            return;
        }
        render(
            q
                ? listBox._items.filter((it) =>
                      ((it.label || '') + ' ' + (it.sel || '')).toLowerCase().includes(q),
                  )
                : listBox._items,
        );
    });
    loadScan();
}
