;(function () {
  try {
    if (window.__ZXT_SAFARI_DOM__) return;
    window.__ZXT_SAFARI_DOM__ = 1;
    var W = __ZXT_W__, H = __ZXT_H__, S = __ZXT_S__;
    function P(o, k, v) {
      try {
        Object.defineProperty(o, k, { configurable: true, enumerable: true, get: function () { return v; } });
      } catch (e) {}
    }
    function patch(sc) {
      if (!sc) return;
      P(sc, "width", W);
      P(sc, "availWidth", W);
      P(sc, "height", H);
      P(sc, "availHeight", H);
    }
    function zxtMarkSellerUa() {
      try {
        var ua = navigator.userAgent || "";
        if (/tiktokseller/i.test(ua)) return;
        if (!/tiktokglobalshop|fe_seller_onboard/i.test(String(location.href || ""))) return;
        P(navigator, "userAgent", ua + " tiktokseller");
      } catch (eUa) {}
    }
    zxtMarkSellerUa();
    var skipScr = (typeof window !== "undefined" && window.__ZXT_SKIP_SCR);
    if (!skipScr) {
      patch(typeof screen !== "undefined" ? screen : null);
      if (typeof window !== "undefined") {
        P(window, "devicePixelRatio", S);
        if (window.screen) patch(window.screen);
      }
    }
    if (/tiktokglobalshop|fe_seller_onboard/i.test(String(location.href || ""))) {
      var zxtUaIv = setInterval(zxtMarkSellerUa, 50);
      setTimeout(function () { clearInterval(zxtUaIv); }, 15000);
    }
    function zxtWantJsb() {
      return /seller-us\.tiktok|tiktokglobalshop|fe_seller_onboard|pipopay|modular_collector|au10tix|secure-me/i.test(String(location.href || ""));
    }
    function zxtKycTarget(params) {
      var s = "";
      if (params && typeof params === "object")
        s = String(params.url || params.URL || params.schema || params.href || params.link || "");
      else if (typeof params === "string") s = params;
      return /pipopay|modular_collector|au10tix|secure-me/i.test(s);
    }
    function zxtWrapJsb(J) {
      if (!J || typeof J.call !== "function" || J.__zxtOpen) return;
      var orig = J.call;
      J.call = function (name, params, cb) {
        if (name === "open" && zxtKycTarget(params)) name = "x.open";
        return orig.call(this, name, params, cb);
      };
      if (typeof J.asyncCall === "function") {
        var oa = J.asyncCall;
        J.asyncCall = function (name, params, cb) {
          if (name === "open" && zxtKycTarget(params)) name = "x.open";
          return oa.call(this, name, params, cb);
        };
      }
      J.__zxtOpen = 1;
    }
    function zxtInstallJsb() {
      if (!zxtWantJsb()) return;
      try { zxtWrapJsb(window.JSBridge); } catch (eJ) {}
      try { zxtWrapJsb(window.ToutiaoJSBridge); } catch (eT) {}
    }
    if (zxtWantJsb()) {
      zxtInstallJsb();
      var zxtIv = setInterval(zxtInstallJsb, 50);
      setTimeout(function () { clearInterval(zxtIv); }, 60000);
    }
    (function () {
      var Orig = window.RegExp;
      try { new Orig("(?<=a)"); return; } catch (e3) {}
      function stripLB(s) {
        s = String(s);
        var out = "", i = 0;
        while (i < s.length) {
          if (s.charAt(i) === "(" && s.slice(i, i + 3) === "(?<" &&
              (s.charAt(i + 3) === "=" || s.charAt(i + 3) === "!")) {
            var depth = 1, j = i + 4;
            while (j < s.length && depth) {
              var ch = s.charAt(j);
              if (ch === "\\" ) { j += 2; continue; }
              if (ch === "(") depth++;
              else if (ch === ")") depth--;
              j++;
            }
            i = j;
            continue;
          }
          out += s.charAt(i);
          i++;
        }
        return out;
      }
      function ZXTRe(p, f) {
        if (p instanceof Orig) return f === undefined ? new Orig(p) : new Orig(p, f);
        if (typeof p === "string" && p.indexOf("(?<") !== -1) {
          try { return f === undefined ? new Orig(p) : new Orig(p, f); }
          catch (e4) { p = stripLB(p); }
        }
        return f === undefined ? new Orig(p) : new Orig(p, f);
      }
      ZXTRe.prototype = Orig.prototype;
      ZXTRe.__zxtRe = 1;
      try {
        Object.defineProperty(window, "RegExp", {
          configurable: true, writable: true, value: ZXTRe
        });
      } catch (e5) {
        try { window.RegExp = ZXTRe; } catch (e6) {}
      }
    })();
  } catch (e) {}
})();
