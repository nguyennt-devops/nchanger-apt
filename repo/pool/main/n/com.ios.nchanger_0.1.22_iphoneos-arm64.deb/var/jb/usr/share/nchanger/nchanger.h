#ifndef NCHANGER_H
#define NCHANGER_H
#define IOSFAKE_REQUEST_CAPACITY (64 * 1024)
#ifdef __cplusplus
extern "C" {
#endif
char *reset_app_data(const char *bundle_id);
char *clear_app_data(const char *bundle_id);
char *change_data(const char *bundle_id);
char *backup_app(const char *bundle_id);
char *restore_app(const char *bundle_id);
char *clone_app(const char *bundle_id, int nth);
char *remove_clone(const char *clone_id);
char *uninstall_app(const char *bundle_id);
char *spoof_reload(const char *bundle_ids);
char *license_state(void);
char *wipe_safari(void);
char *reset_safari(void);
typedef void (*iosfake_progress_callback)(const char *line, void *context);
char *iosfake_request_progress(int code, const char *payload, int timeout_seconds, iosfake_progress_callback callback, void *context);
char *iosfake_request(int code, const char *payload, int timeout_seconds);
#ifdef __cplusplus
}
#endif
#endif
